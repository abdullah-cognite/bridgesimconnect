using Cognite.Simulator.Utils;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using SimulatorCommon;
using SimulatorCommon.Test;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Xunit;

namespace SimConnect.Test
{
    [Collection(nameof(SequentialTestCollection))]
    public class ConfigurationLibraryTest
    {
        [Fact]
        public async Task TestConfigurationDownloadAndParsing()
        {
            using var tester = new CdfTester(true);
            var config = tester.Provider.GetRequiredService<FullConfig>();
            config.Connector.ConfigurationLibrary.LibraryUpdateInterval = 2;
            var configLib = new ConfigurationLibrary(
                config,
                tester.Destination,
                tester.Provider.GetRequiredService<ILogger<ConfigurationLibrary>>(),
                tester.Provider.GetRequiredService<FileDownloadClient>());

            // Initialize a configuration library and check that the directory containing
            // the files was created and that the in-memory state store contains the CDF file
            await configLib.Init(tester.Source.Token);
            bool dirExists = Directory.Exists(config.Connector.ConfigurationLibrary.FilesDirectory);

            Assert.True(dirExists, "Should have created a directory to hold the files according to configuration");
            Assert.NotEmpty(configLib.State);
            var state = Assert.Contains(
                "PROSPER-SC-IPR_VLP-Connector_Test_Model", // This simulator configuration should exist in CDF
                (IReadOnlyDictionary<string, ConfigurationFileState>)configLib.State);
            Assert.Equal("PROSPER", state.Source);
            Assert.Equal("Connector Test Model", state.ModelName);

            // After starting the library update loop, verify that the configuration file is downloaded,
            // the json content is parsed correctly and the DTO exists
            var linkedTokenSource = CancellationTokenSource.CreateLinkedTokenSource(tester.Source.Token);
            var linkedToken = linkedTokenSource.Token;
            linkedTokenSource.CancelAfter(TimeSpan.FromSeconds(5)); // should be enough time to download the file from CDF and parse it
            var modelLibTasks = configLib.GetRunTasks(linkedToken);
            await modelLibTasks.RunAll(linkedTokenSource);

            Assert.NotEmpty(configLib.SimulationConfigurations);
            var dto = Assert.Contains(
                "PROSPER-SC-IPR_VLP-Connector_Test_Model",
                (IReadOnlyDictionary<string, ConfigurationDTO>)configLib.SimulationConfigurations);
            Assert.Equal("PROSPER", dto.Simulator);
            Assert.Equal(SimulatorCommon.UnitSystem.OilField, dto.UnitSystem);
            Assert.Equal("Connector Test Model", dto.ModelName);
            Assert.Equal("IPR/VLP", dto.CalculationType);
            
            // Check sampling config
            Assert.NotNull(dto.DataSampling);
            Assert.Equal(1, dto.DataSampling.Granularity);
            Assert.Equal(60, dto.DataSampling.SamplingWindow);
            Assert.Equal(1440, dto.DataSampling.ValidationWindow);
            
            // Check input time series
            Assert.NotNull(dto.InputTimeSeries);
            Assert.NotEmpty(dto.InputTimeSeries);
            Assert.Contains(dto.InputTimeSeries, 
                t => SimulationInputConstants.CGR == t.Type
                && t.UnitType == "LiqRate/GasRate");
            Assert.Contains(dto.InputTimeSeries,
                t => SimulationInputConstants.THP == t.Type
                && t.UnitType == "Pressure");

            // Check output time series
            Assert.NotNull(dto.OutputTimeSeries);
            Assert.NotEmpty(dto.OutputTimeSeries);
            var outputTs = dto.OutputTimeSeries.ToArray()[0];
            Assert.Equal(SimulationOutputConstants.GasRate, outputTs.Type);
            Assert.Equal(UnitType.GasRate.ToString(), outputTs.UnitType);

            // Check output sequences
            Assert.NotNull(dto.OutputSequences);
            Assert.NotEmpty(dto.OutputSequences);
            Assert.Contains(dto.OutputSequences, s => s.Type == SimulatorCommon.CalculationTabularOutputType.SystemCurves);

            // Check schedule
            Assert.NotNull(dto.Schedule);
            Assert.False(dto.Schedule.Enabled);
            Assert.Equal(new TimeSpan(1, 0, 0, 0), dto.Schedule.RepeatTimeSpan);
            Assert.Equal(DateTime.Parse("10 Oct 2021 10:00:00 GMT").ToUniversalTime(), dto.Schedule.StartDate);
        }

    }
}

﻿using Cognite.Extensions;
using Cognite.Extractor.Common;
using Cognite.Extractor.Utils;
using Cognite.Simulator.Extensions;
using CogniteSdk;
using Microsoft.Extensions.DependencyInjection;
using SimulatorCommon;
using SimulatorCommon.Test;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Xunit;

namespace SimConnect.Test
{
    [Collection(nameof(SequentialTestCollection))]
    public class SimulationRunnerTest
    {

        [Fact]
        public async Task TestRunCalculation()
        {
            using var tester = new CdfTester(true);
            var token = tester.Source.Token;
            var config = tester.Provider.GetRequiredService<FullConfig>();
            var connector = tester.Provider.GetRequiredService<Connector>();
            var testEventId = $"PROSPER-SR-IPR_VLP-Connector_Test_Model-{DateTime.UtcNow.ToUnixTimeMilliseconds()}";
            var testInputTs = $"Connector_Integration_Tests-Input_TimeSeries-1";
            var testSequences = new List<Identity>() { };
            var testTimeSeries = new List<Identity>() { new Identity(testInputTs) };
            try
            {
                // Create input time series
                await CreateInputTimeSeries(testInputTs, tester.Destination, config.Simulators[0].DataSetId, token);

                // Initialize the connector, this will fetch the model and simulation configuration form CDF.
                await connector.Init(token);

                var linkedSource = CancellationTokenSource.CreateLinkedTokenSource(token);
                var linkedToken = linkedSource.Token;
                linkedSource.CancelAfter(TimeSpan.FromSeconds(12));
                var runTask = connector.Run(linkedToken);
                await Task.Delay(TimeSpan.FromSeconds(3));

                // Verify that the connector downloaded the model
                var modelLib = tester.Provider.GetRequiredService<ModelLibrary>();
                Assert.Contains(modelLib.State.Values, s => s.ModelName == "Connector Test Model");

                // verify that the connector downloaded the calculation config
                var configLib = tester.Provider.GetRequiredService<ConfigurationLibrary>();
                var calcConfig = configLib.GetSimulationConfiguration("PROSPER", "Connector Test Model", "IPR/VLP", null);
                Assert.NotNull(calcConfig);

                // Create an event in CDF to simulate a manual run of a simulation calculation
                await CreateRunEvent(testEventId, tester.Destination, config.Simulators[0].DataSetId, config.Connector.GetConnectorName(), token);
                await runTask;

                // After finding the run event, the connector should have started running it.
                // Verify the event was updated with the run state
                var eventUpdated = await tester.Destination.CogniteClient.Events.RetrieveAsync(
                    new List<string> { testEventId },
                    token: token);
                Assert.NotEmpty(eventUpdated);

                var eventMetadata = eventUpdated.First().Metadata;
                Assert.True(eventMetadata.ContainsKey("calcTime"));
                Assert.True(long.TryParse(eventMetadata["calcTime"], out var eventCalcTime));
                Assert.True(eventMetadata.TryGetValue("status", out var eventStatus));
                Assert.Equal("success", eventStatus);
                Assert.True(eventMetadata.TryGetValue("modelVersion", out var modelVersion));
                Assert.Equal("2", modelVersion);

                // A sequence should have been created in CDF with the run configuration data
                // and one with the simulation results (system curves).
                Assert.True(eventMetadata.TryGetValue("runConfigurationSequence", out var runSequenceId));
                Assert.True(eventMetadata.TryGetValue("runConfigurationRowStart", out var runSequenceRowStart));
                Assert.True(eventMetadata.TryGetValue("runConfigurationRowEnd", out var runSequenceRowEnd));
                Assert.True(eventMetadata.TryGetValue("outputCurvesSequence", out var curvesSequenceId));
                Assert.True(eventMetadata.TryGetValue("outputCurvesRowStart", out var curvesRowStart));
                Assert.True(eventMetadata.TryGetValue("outputCurvesRowEnd", out var curvesSequenceRowEnd));
                testSequences.Add(new Identity(runSequenceId));
                testSequences.Add(new Identity(curvesSequenceId));

                // A time series should have been created with calculation inputs
                // and one with calculation outputs
                var tsResult = await tester.Destination.CogniteClient.TimeSeries.SearchAsync(
                    new TimeSeriesSearch
                    {
                        Filter = new TimeSeriesFilter
                        {
                            ExternalIdPrefix = "PROSPER-",
                            Metadata = new()
                            {
                                { "simulator", "PROSPER" },
                                { "modelName", "Connector Test Model" },
                                { "calcType", "IPR/VLP" }
                            }
                        }
                    },
                    token);
                testTimeSeries.AddRange(tsResult.Select(s => new Identity(s.Id)).ToList());
                Assert.NotEmpty(tsResult);

                // Check sampling results
                var data = await tester.Destination.CogniteClient.Sequences.ListRowsAsync(
                    new SequenceRowQuery
                    {
                        ExternalId = runSequenceId,
                        Start = long.Parse(runSequenceRowStart),
                        End = long.Parse(runSequenceRowEnd) + 1
                    },
                    token);
                var dictResult = ToRowDictionary(data);
                Assert.True(dictResult.ContainsKey("runEventId"));
                Assert.Equal(testEventId, dictResult["runEventId"]);
                Assert.True(dictResult.ContainsKey("calcTime"));
                Assert.Equal(eventCalcTime.ToString(), dictResult["calcTime"]);

                // Verify sampling start, end and calculation time values
                Assert.True(dictResult.ContainsKey("samplingEnd"));
                Assert.True(dictResult.ContainsKey("samplingStart"));
                Assert.True(dictResult.ContainsKey("validationEndOffset"));

                SamplingRange range = new CogniteSdk.TimeRange()
                {
                    Min = long.Parse(dictResult["samplingStart"]),
                    Max = long.Parse(dictResult["samplingEnd"])
                };
                Assert.Equal(eventCalcTime, range.Midpoint);

                // Check system curves
                var curvesQueryResult = await tester.Destination.CogniteClient.Sequences.RetrieveAsync(
                    new [] {new Identity(curvesSequenceId)},
                    true,
                    token);
                Assert.True(curvesQueryResult.Any());
                var curvesSequence = curvesQueryResult.First();
                Assert.Equal(curvesSequenceId, curvesSequence.ExternalId);
                Assert.NotEmpty(curvesSequence.Columns);
                var curveColumnMetadata = curvesSequence.Columns.First().Metadata;
                Assert.NotNull(curveColumnMetadata);
                Assert.NotEmpty(curveColumnMetadata);
                Assert.True(curveColumnMetadata.ContainsKey("name"));
                Assert.True(curveColumnMetadata.ContainsKey("unit"));
                Assert.True(curveColumnMetadata.ContainsKey("unitType"));

                var rows = await tester.Destination.CogniteClient.Sequences.ListRowsAsync(
                    new SequenceRowQuery
                    {
                        ExternalId = curvesSequenceId,
                        Start = long.Parse(curvesRowStart),
                        End = long.Parse(curvesSequenceRowEnd) + 1
                    },
                    token);
                Assert.True(rows.Rows.Count() == 5);
                Assert.True(rows.Columns.Count() == 2);
                Assert.All(rows.Rows, (r) =>
                {
                    double index = r.RowNumber - long.Parse(curvesRowStart);
                    Assert.All(r.Values, (v) => Assert.True(((MultiValue.Double)v).Value == index));
                });

                // Check input and output time series
                var tsToTest = tsResult
                    .Where(t => t.Metadata["dataType"] == SimulatorDataType.SimulationInput.MetadataValue() ||
                        t.Metadata["dataType"] == CdfUtils.SimulationOutputResourceType)
                    .ToList();
                Assert.NotEmpty(tsToTest);
                var dpItems = tsToTest.Select(t => new DataPointsQueryItem
                {
                    ExternalId = t.ExternalId
                });
                var dataPoints = await tester.Destination.CogniteClient.DataPoints.ListAsync(
                    new DataPointsQuery
                    {
                        Start = $"{eventCalcTime}",
                        End = $"{eventCalcTime + 1}",
                        Items = dpItems
                    },
                    token);
                Assert.All(dataPoints.Items, (i) =>
                {
                    Assert.NotNull(i.NumericDatapoints);
                    Assert.NotEmpty(i.NumericDatapoints.Datapoints);
                    Assert.Equal(eventCalcTime, i.NumericDatapoints.Datapoints.First().Timestamp);
                    if (i.ExternalId == "PROSPER-INPUT-IPR_VLP-THP-Connector_Test_Model")
                    {
                        // Input time series unit is BARg. 1500 BARg to psi: 21755.66.
                        // psi is only used internally, we still save it to CDF as BARg
                        Assert.Equal(1500, i.NumericDatapoints.Datapoints.First().Value, 2);
                        var ts = tsToTest
                            .Where(t => t.ExternalId == i.ExternalId)
                            .First();
                        Assert.Equal("BARg", ts.Unit);
                    }
                    else if (i.ExternalId == "PROSPER-OUTPUT-IPR_VLP-GasRate-Connector_Test_Model")
                    {
                        // Default unit for GasRate in OilField system is MMscf/day
                        // 123.4567 MMscf/day to scf/day: 23456700
                        Assert.Equal(123456700, i.NumericDatapoints.Datapoints.First().Value);
                    }
                    else if (i.ExternalId == "PROSPER-INPUT-IPR_VLP-CGR-Connector_Test_Model")
                    {
                        Assert.Equal(tester.SimMock.BcValues[SimulatorConstants.CGR], i.NumericDatapoints.Datapoints.First().Value);
                    }
                    else if (i.ExternalId == "PROSPER-INPUT-IPR_VLP-WGR-Connector_Test_Model")
                    {
                        Assert.Equal(tester.SimMock.BcValues[SimulatorConstants.WGR], i.NumericDatapoints.Datapoints.First().Value);
                    }
                });
            }
            finally
            {
                // Remove created resources
                await tester.Destination.CogniteClient.TimeSeries.DeleteAsync(
                    new TimeSeriesDelete
                    {
                        IgnoreUnknownIds = true,
                        Items = testTimeSeries
                    });
                await tester.Destination.CogniteClient.Events.DeleteAsync(
                    new EventDelete
                    {
                        IgnoreUnknownIds = true,
                        Items = new List<Identity>() { new Identity(testEventId) }
                    });
                if (testSequences.Any())
                {
                    await tester.Destination.CogniteClient.Sequences.DeleteAsync(testSequences);
                }
            }
        }

        private async Task CreateRunEvent(
            string externalId,
            CogniteDestination cdf,
            long dataSetId,
            string connectorName,
            CancellationToken token)
        {
            var eventCreate = new EventCreate
            {
                ExternalId = externalId,
                DataSetId = dataSetId,
                Type = "Simulation calculation",
                Source = "PROSPER",
                Metadata = new()
                {
                    { "simulator", "PROSPER" },
                    { "dataType", SimulatorDataType.SimulationEvent.MetadataValue() },
                    { "status", "ready" },
                    { "modelName", "Connector Test Model" },
                    { "connector", connectorName },
                    { "calcType", "IPR/VLP" },
                    { "calcConfig", "PROSPER-SC-IPR_VLP-Connector_Test_Model" }
                }
            };

            var eventResult = await cdf.EnsureEventsExistsAsync(
                new List<EventCreate> { eventCreate },
                RetryMode.None,
                SanitationMode.None,
                token);

            Assert.True(eventResult.IsAllGood, "Failed to created event required to run the test");
        }

        private async Task CreateInputTimeSeries(
            string externalId,
            CogniteDestination cdf,
            long dataSetId,
            CancellationToken token)
        {
            var inputTsResult = cdf.GetOrCreateTimeSeriesAsync(
                new[] { externalId },
                (ids) => new List<TimeSeriesCreate>
                {
                        new TimeSeriesCreate {
                            ExternalId = externalId,
                            IsString = false,
                            DataSetId = dataSetId,
                            Name = "Connector integration tests - input time series"
                        }
                },
                RetryMode.None,
                SanitationMode.None,
                token);
            Assert.True(inputTsResult.Result.IsAllGood, "Failed to created input time series required to run the test");

            var testStart = DateTime.UtcNow;
            int sampling = 60 / 5; // Sampling window of 60 min
            var datapointValues = new double[] { 1500, 1500, 1500, 1500, 1500 };
            var datapointTimes = new long[]
            {
                    testStart.ToUnixTimeMilliseconds(),
                    (testStart - TimeSpan.FromMinutes(sampling)).ToUnixTimeMilliseconds(),
                    (testStart - TimeSpan.FromMinutes(sampling*2)).ToUnixTimeMilliseconds(),
                    (testStart - TimeSpan.FromMinutes(sampling*3)).ToUnixTimeMilliseconds(),
                    (testStart - TimeSpan.FromMinutes(sampling*4)).ToUnixTimeMilliseconds(),
            };
            var datapointMap = new Dictionary<Identity, IEnumerable<Datapoint>>()
                {
                    {
                        new Identity(externalId),
                        datapointValues.Select((v, i) => new Datapoint(datapointTimes[i], v)).ToArray()
                    }
                };
            var dpResult = await cdf.InsertDataPointsAsync(
                datapointMap,
                SanitationMode.None,
                RetryMode.OnError,
                token);
            Assert.True(dpResult.IsAllGood, "Failed to created input time series data points required to run the test");
        }

        private static Dictionary<string, string> ToRowDictionary(SequenceData data)
        {
            Dictionary<string, string> result = new();
            foreach (var row in data.Rows)
            {
                var cells = row.Values.ToArray();
                var key = ((MultiValue.String)cells[0]).Value;
                var value = ((MultiValue.String)cells[1]).Value;
                result.Add(key, value);
            }
            return result;
        }
    }
}

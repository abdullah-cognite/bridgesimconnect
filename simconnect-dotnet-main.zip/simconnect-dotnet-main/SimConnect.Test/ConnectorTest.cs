using SimulatorCommon.Test;
using System.Threading.Tasks;
using Xunit;
using CogniteSdk;
using System.Linq;
using Microsoft.Extensions.DependencyInjection;
using System.Collections.Generic;

namespace SimConnect.Test
{
    [CollectionDefinition(nameof(SequentialTestCollection), DisableParallelization = true)]
    public class SequentialTestCollection
    {

    }

    [Collection(nameof(SequentialTestCollection))]
    public class ConnectorTest
    {
        [Fact]
        public async Task TestLibraryDataSetColumns()
        {
            using var tester = new CdfTester(true);
            var config = tester.Config;
            var dataSetId = tester.Config.Simulators[0].DataSetId;
            var connector = tester.Provider.GetRequiredService<Connector>();
            var sequences = tester.Destination.CogniteClient.Sequences;
            var token = tester.Source.Token;
            Sequence integrationsSeq;
            
            await connector.Init(token);

            var metadata = new Dictionary<string, string>()
                {
                    { "dataType", "Simulator Integration" },
                    { "simulator", tester.Config.Simulators[0].Name },
                    { "connector", config.Connector.GetConnectorName() }
                };
            var query = new SequenceQuery
            {
                Filter = new SequenceFilter
                {
                    Metadata = metadata
                }
            };
            var seqResult = await sequences.ListAsync(query, token);

            Assert.NotEmpty(seqResult.Items);

            integrationsSeq = seqResult.Items.First();

            Assert.Equal(2, integrationsSeq.Columns.Count());

            var configLibraryColumnIdx = integrationsSeq.Columns
                .ToList()
                .FindIndex(col => col.ExternalId == "configurations-dataset-id");
            var modelLibraryColumnIdx = integrationsSeq.Columns
                .ToList()
                .FindIndex(col => col.ExternalId == "models-dataset-id");

            var rowsResult = await sequences.ListRowsAsync(
                new SequenceRowQuery
                {
                    ExternalId = integrationsSeq.ExternalId,
                },
                token);

            var values = rowsResult.Rows.ElementAt(1).Values.ToArray();
            Assert.Equal(((MultiValue.String)values[1]).Value, dataSetId.ToString());
        }
    }
}

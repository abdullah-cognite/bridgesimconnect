﻿using Cognite.Simulator.Utils;
using CogniteSdk;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Moq;
using SimulatorCommon;
using SimulatorCommon.Test;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Xunit;

namespace SimConnect.Test
{
    [Collection(nameof(SequentialTestCollection))]
    public class ModelLibraryTest
    {
        [Fact]
        public async Task TestModelLibrary()
        {
            using var tester = new CdfTester(true);
            var token = tester.Source.Token;
            var connector = tester.Provider.GetRequiredService<Connector>();
            var modelLibrary = tester.Provider.GetRequiredService<ModelLibrary>();
            var staging = tester.Provider.GetRequiredService<StagingArea<ModelParsingLog>>();

            long newRowIndex = -1;
            const string bcMapSequence = "PROSPER-BC-Connector_Test_Model";
            const string bcTimeSeries = "PROSPER-BC-TestBc-Connector_Test_Model";
            var sequences = tester.Destination.CogniteClient.Sequences;
            var timeseries = tester.Destination.CogniteClient.TimeSeries;
            var datapoints = tester.Destination.CogniteClient.DataPoints;
            try
            {
                var rows = await sequences.ListRowsAsync(new SequenceRowQuery
                {
                    ExternalId = bcMapSequence
                }, token);
                Assert.NotEmpty(rows.Rows);
                Assert.Contains(rows.Columns, c => c.ExternalId == "boundary-condition");
                Assert.Contains(rows.Columns, c => c.ExternalId == "time-series");
                Assert.Contains(rows.Columns, c => c.ExternalId == "boundary-condition-name");
                Assert.Contains(rows.Columns, c => c.ExternalId == "boundary-condition-address");
                long maxRow = rows.Rows.Max(r => r.RowNumber);
                newRowIndex = maxRow + 1;

                await sequences.CreateRowsAsync(new List<SequenceDataCreate>()
                {
                    new SequenceDataCreate
                    {
                        ExternalId = bcMapSequence,
                        Columns = new []
                        {
                            "boundary-condition",
                            "time-series",
                            "boundary-condition-name",
                            "boundary-condition-address"
                        },
                        Rows = new List<SequenceRow>()
                        {
                            new SequenceRow
                            {
                                RowNumber = newRowIndex,
                                Values = new []
                                {
                                    MultiValue.Create("TestBc"),
                                    MultiValue.Create(bcTimeSeries),
                                    MultiValue.Create("Test Boundary Condition"),
                                    MultiValue.Create("PROSPER.TEST.Input.Test")
                                }
                            }
                        }
                    }
                }, token);
                await modelLibrary.Init(token);
                bool dirExists = Directory.Exists(tester.Config.Connector.ModelLibrary.FilesDirectory);

                Assert.True(dirExists, "Should have created a directory for the model files");
                Assert.NotEmpty(modelLibrary.State);
                var v1 = Assert.Contains(
                    "PROSPER-Connector_Test_Model-1", // This model file should exist in CDF
                    (IReadOnlyDictionary<string, ModelFileState>)modelLibrary.State);
                Assert.Equal("PROSPER", v1.Source);
                Assert.Equal("Connector Test Model", v1.ModelName);
                Assert.Equal(1, v1.Version);
                var v2 = Assert.Contains(
                    "PROSPER-Connector_Test_Model-2", // This model file should exist in CDF
                    (IReadOnlyDictionary<string, ModelFileState>)modelLibrary.State);
                Assert.Equal("PROSPER", v2.Source);
                Assert.Equal("Connector Test Model", v2.ModelName);
                Assert.Equal(2, v2.Version);

                // Start the library update loop that download and parses the files, stop after 5 secs
                var linkedTokenSource = CancellationTokenSource.CreateLinkedTokenSource(tester.Source.Token);
                var linkedToken = linkedTokenSource.Token;
                linkedTokenSource.CancelAfter(TimeSpan.FromSeconds(10)); // should be enough time to download the file from CDF and parse it
                var modelLibTasks = modelLibrary.GetRunTasks(linkedToken);
                await modelLibTasks.RunAll(linkedTokenSource);
                
                // Verify that the latest file version was downloaded
                Assert.True(System.IO.File.Exists(v2.FilePath));

                // Verify that the boundary condition time series is created
                tester.SimMock.Verify(m => m.ExtractModelInformation(It.IsAny<ModelFileSettings>()), Times.AtLeastOnce);
                var bcTs = await timeseries.RetrieveAsync(new [] { bcTimeSeries }, true, token);
                Assert.NotEmpty(bcTs);
                Assert.True(bcTs.First().Metadata.TryGetValue("dataType", out var dataType));
                Assert.Equal("Boundary Condition", dataType);
                Assert.True(bcTs.First().Metadata.TryGetValue("variableName", out var variableName));
                Assert.Equal("Test Boundary Condition", variableName);

                // Verify that the data points were created for each model version
                var bcDps = await datapoints.ListAsync(new DataPointsQuery
                {
                    IgnoreUnknownIds = true,
                    Items = new []
                    {
                        new DataPointsQueryItem
                        {
                            ExternalId = bcTimeSeries,
                            Start = v1.CreatedTime.ToString(),
                            End = (v2.CreatedTime + 1).ToString(),
                        }
                    }
                }, token);
                Assert.True(bcDps.Items.Any());
                Assert.True(bcDps.Items.First().NumericDatapoints != null && bcDps.Items.First().NumericDatapoints.Datapoints != null);
                var dpValues = bcDps.Items.First().NumericDatapoints.Datapoints;
                Assert.Contains(dpValues, p => p.Timestamp == v1.CreatedTime && p.Value == 1.0);
                Assert.Contains(dpValues, p => p.Timestamp == v2.CreatedTime && p.Value == 1.0);

                // Verify that a parsing log was created in RAW
                var log1 = await staging.GetEntry(
                    "PROSPER-Connector_Test_Model-1",
                    token);
                Assert.NotNull(log1);
                Assert.True(log1.Parsed);
                Assert.False(log1.Error);
                Assert.Equal(ParsingStatus.success, log1.Status);

                var log2 = await staging.GetEntry(
                    "PROSPER-Connector_Test_Model-2",
                    token);
                Assert.NotNull(log2);
                Assert.True(log2.Parsed);
                Assert.False(log2.Error);
                Assert.Equal(ParsingStatus.success, log2.Status);
            }
            finally
            {
                if (newRowIndex >= 0)
                {
                    await sequences.DeleteRowsAsync(new List<SequenceRowDelete>()
                    {
                        new SequenceRowDelete
                        {
                            ExternalId = bcMapSequence,
                            Rows = new [] {
                                newRowIndex
                            }
                        }
                    }, token);

                    await timeseries.DeleteAsync(new TimeSeriesDelete
                    {
                        IgnoreUnknownIds = true,
                        Items = new[] {
                            new Identity(bcTimeSeries)
                        }
                    }, token);
                }
                await tester.Destination.CogniteClient.Raw.DeleteRowsAsync(
                    tester.Config.Connector.RawStorage.Database,
                    tester.Config.Connector.RawStorage.ModelParsingLogTable,
                    new List<RawRowDelete>
                    {
                        new RawRowDelete
                        {
                            Key = "PROSPER-Connector_Test_Model-1"
                        },
                        new RawRowDelete
                        {
                            Key = "PROSPER-Connector_Test_Model-2"
                        }
                    }, token);
            }
        }
    }
}

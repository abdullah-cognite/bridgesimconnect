﻿using Cognite.Extensions;
using Cognite.Extractor.Common;
using Cognite.Simulator.Utils;
using CogniteSdk;
using Microsoft.Extensions.Logging;
using SimulatorCommon;
using SimulatorCommon.Test;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace SimConnect.Test
{
    [Collection(nameof(SequentialTestCollection))]
    public class CdfUtilsTest
    {
        [Fact]
        public void TestMergeFileMetadata()
        {
            var metadata = new Dictionary<string, string>()
            {
                { "key1", "value1" },
                { "key2", "value2"},
                { "key4", new string('*', 10)}
            };

            var newMetadata = new Dictionary<string, string>()
            {
                { "key1", "value1-changed" },
                { "key2", "value2" },
                { "key3", "value3" },
                { "key4", new string('*', 400) },
                { "key5", new string('*', 10000) }
            };

            var merged1 = metadata.MergeFileMetadata(newMetadata, out bool changed);
            Assert.True(changed);
            Assert.NotEmpty(merged1);
            Assert.Equal("value1-changed", merged1["key1"]);
            Assert.False(merged1.ContainsKey("key2"));
            Assert.Equal("value3", merged1["key3"]);
            Assert.True(CdfUtils.FilesMetadataMaxBytesPerValue >= Encoding.UTF8.GetByteCount(merged1["key4"]));
            Assert.True(CdfUtils.FilesMetadataMaxBytesPerValue >= Encoding.UTF8.GetByteCount(merged1["key5"]));

            for(int i = 0; i < CdfUtils.FilesMetadataMaxNumKeys; i++)
            {
                newMetadata.Add($"key-{i}", "*");
            }
            var merged2 = metadata.MergeFileMetadata(newMetadata, out bool changed2);
            Assert.True(changed2);
            Assert.True(merged2.Count <= CdfUtils.FilesMetadataMaxNumKeys);

            var newMetadata2 = new Dictionary<string, string>();
            for (int i = 0; i < CdfUtils.FilesMetadataMaxNumKeys; i++)
            {
                newMetadata2.Add($"key-{i}", new string('*', 100));
            }
            var merged3 = (new Dictionary<string, string>()).MergeFileMetadata(newMetadata2, out bool changed3);
            Assert.True(changed3);
            Assert.True(merged3.VerifyMetadata(
                CdfUtils.FilesMetadataMaxBytesPerKey, 
                CdfUtils.FilesMetadataMaxNumKeys,
                CdfUtils.FilesMetadataMaxBytesPerValue,
                CdfUtils.FilesMetadataMaxBytes,
                out var byteCount));
            Assert.True(byteCount <= CdfUtils.FilesMetadataMaxBytes);
        }

        [Fact]
        public async void InitConnectorRawDatabase()
        {
            using var tester = new CdfTester();
            var cdf = tester.Destination.CogniteClient;
            var config = tester.Config;
            var storageConfig = config.Connector.RawStorage;
            var logger = tester.Logger;
            var token = tester.Source.Token;

            storageConfig.Database = "CONNECTOR_INTEGRATION_TEST_DB";
            storageConfig.DeleteLogTable = "CONNECTOR_INTEGRATION_TEST_TABLE";

            try
            {
                CdfUtils.InitConnectorRawDatabase(
                    config.Connector);

                var date = DateTime.UtcNow;

                await cdf.Raw.CreateRowsAsync(
                    storageConfig.Database,
                    storageConfig.DeleteLogTable,
                    new List<RawRowCreate<DeleteLogObject>>()
                    {
                        new RawRowCreate<DeleteLogObject>()
                        {
                            Key = "TestKey",
                            Columns = new DeleteLogObject
                            {
                                Data = "Delete log integration test",
                                Error = "No errors"
                            }
                        }
                    },
                    true,
                    token: token);
                
                await Task.Delay(1000); // for eventual consistency issues
                var invalidLog = await CdfUtils.GetDeletionLog(
                    "InvalidTestKey",
                    cdf,
                    logger,
                    token);
                Assert.Null(invalidLog);

                var log = await CdfUtils.GetDeletionLog(
                    "TestKey",
                    cdf,
                    logger,
                    token);
                Assert.NotNull(log);
                Assert.NotNull(log.Key);
                Assert.Equal("TestKey", log.Key);
                Assert.NotNull(log.Columns);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Unexpected error during integration tests");
                throw;
            }
            finally
            {
                await cdf.Raw.DeleteDatabasesAsync(
                    new RawDatabaseDelete
                    {
                        Items = new List<RawDatabase>()
                        {
                            new RawDatabase
                            {
                                Name = storageConfig.Database
                            }
                        },
                        Recursive = true
                    }, token);
            }
        }
    }

    internal class DeleteLogObject
    {
        public string Data { get; set; }
        public string Error { get; set; }

    }
}

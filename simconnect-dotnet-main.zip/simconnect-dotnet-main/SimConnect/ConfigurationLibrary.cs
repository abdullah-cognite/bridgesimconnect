﻿using Cognite.Extractor.Common;
using Cognite.Extractor.StateStorage;
using Cognite.Extractor.Utils;
using Cognite.Simulator.Extensions;
using Cognite.Simulator.Utils;
using Microsoft.Extensions.Logging;
using SimulatorCommon;
using SimulatorCommon.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using File = CogniteSdk.File;

namespace SimConnect
{
    public class ConfigurationLibrary : ConfigurationLibraryBase<ConfigurationFileState, ConfigurationFileStatePoco, ConfigurationDTO>
    {

        public ConfigurationLibrary(
            FullConfig config,
            CogniteDestination cdf,
            ILogger<ConfigurationLibrary> logger,
            FileDownloadClient client,
            IExtractionStateStore store = null) :
            base(config.Connector.ConfigurationLibrary, config.Simulators, cdf, logger, client, store)
        {
        }

        protected override async Task<bool> ConfigurationFileExistsInCdf(
            ConfigurationFileState state,
            ConfigurationDTO config,
            CancellationToken token)
        {
            // Verifies that the configuration file is in CDF and it is not
            // being deleted
            var exists = await base.ConfigurationFileExistsInCdf(state, config, token);
            if (exists)
            {
                var calcDeletionLog = await CdfUtils.GetDeletionLog(state.Id, Cdf.CogniteClient, Logger, token);
                var modelLogId = $"{config.Simulator}-{config.ModelNameForIds}";
                var modelDeletionLog = await CdfUtils.GetDeletionLog(modelLogId, Cdf.CogniteClient, Logger, token);
                if (calcDeletionLog == null && modelDeletionLog == null)
                {
                    // If no RAW capability, assume the files are not being deleted
                    return true;
                }
            }
            return false;
        }

        protected override ConfigurationFileState StateFromFile(File file)
        {
            if (!file.Metadata.TryGetValue("modelName", out string modelName))
            {
                Logger.LogError("Simulation Configuration {Name} does not define a model name. Skipping", file.Name);
                return null;
            }
            if (file.MimeType != "application/json")
            {
                Logger.LogError("Simulation Configuration {Name} mime type is not JSON. Skipping", file.Name);
                return null;
            }
            // TODO: can filter by connector name as well
            var newState = new ConfigurationFileState(file.ExternalId)
            {
                UpdatedTime = file.LastUpdatedTime,
                ModelName = modelName,
                Source = file.Source,
                DataSetId = file.DataSetId,
                CreatedTime = file.CreatedTime,
                CdfId = file.Id
            };

            if (State.TryGetValue(file.ExternalId, out var existingState))
            {
                newState.RunDataSequence = existingState.RunDataSequence;
                newState.RunSequenceLastRow = existingState.RunSequenceLastRow;
                newState.ResultsSequence = existingState.ResultsSequence;
                newState.ResultsSequenceLastRow = existingState.ResultsSequenceLastRow;
                newState.CurvesSequence = existingState.CurvesSequence;
                newState.CurvesSequenceLastRow = existingState.CurvesSequenceLastRow;
            }
            return newState;
        }
    }


    /// <summary>
    /// Data type object used when deserializing the json configuration
    /// file.
    /// TODO: Add all the properties according to the data model
    /// TODO: Maybe move data used by the simulator to SimulatorCommon
    /// </summary>
    public class ConfigurationDTO : SimulationConfiguration
    {
        public UnitSystem UnitSystem { get; set; }
        
        public IEnumerable<OutputSequencesDTO> OutputSequences { get; set; }

        public string ModelNameForIds => ModelName.ReplaceSpecialCharacters("_");

    }

    public class OutputSequencesDTO
    {
        public string Name { get; set; }
        public CalculationTabularOutputType Type { get; set; }
    }
}

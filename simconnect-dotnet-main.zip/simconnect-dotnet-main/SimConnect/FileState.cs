﻿using Cognite.Extractor.StateStorage;
using Cognite.Simulator.Extensions;
using Cognite.Simulator.Utils;
using CogniteSdk;
using SimulatorCommon;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimConnect
{
    public class ModelFileState : ModelStateBase
    {
        private bool _bcExtracted = false;
        public bool BoundaryConditionsExtracted
        {
            get => _bcExtracted;
            set
            {
                if (value == _bcExtracted) return;
                LastTimeModified = DateTime.UtcNow;
                _bcExtracted = value;
            }
        }

        private UnitSystem _unitSystem;
        public UnitSystem UnitSystem
        {
            get => _unitSystem;
            set
            {
                if (value == _unitSystem) return;
                LastTimeModified = DateTime.UtcNow;
                _unitSystem = value;
            }
        }

        private ModelType _modelType;
        public ModelType ModelType
        {
            get => _modelType;
            set
            {
                if (value == _modelType) return;
                LastTimeModified = DateTime.UtcNow;
                _modelType = value;
            }
        }
        public string FileName { get; internal set; } = "";
        public Dictionary<string, string> FileMetadata { get; internal set; }

        public override bool IsExtracted => _bcExtracted;

        private bool _isVlpGenerated;
        public bool IsVLPGenerated { 
            get => _isVlpGenerated;
            set
                {
                    if (value == _isVlpGenerated) return;
                    LastTimeModified = DateTime.UtcNow;
                    _isVlpGenerated = value;
                }
          }

        public ModelFileState(string id) : base(id)
        {
        }

        public override string GetExtension()
        {
            // TODO: implement a generic way, that works for other simulators.
            if (Source == "PROSPER")
            {
                return "out";
            }
            else if (Source == "ProcessSim")
            {
                return "yml";
            }
            else if (Source == "GAP")
            {
                return "gap";
            }
            else if (Source == "MBAL")
            {
                return "mbi";
            }
            return base.GetExtension();
        }

        public override void Init(FileStatePoco poco)
        {
            base.Init(poco);
            if (poco is ModelFileStatePoco mPoco)
            {
                _bcExtracted = mPoco.BoundaryConditionsExtracted;
                _unitSystem = mPoco.UnitSystem;
                _modelType = mPoco.ModelType;
                _isVlpGenerated = mPoco.IsVLPGenerated;
            }
        }

        public override FileStatePoco GetPoco()
        {
            return new ModelFileStatePoco
            {
                Id = Id,
                ModelName = ModelName,
                Source = Source,
                DataSetId = DataSetId,
                FilePath = FilePath,
                CreatedTime = CreatedTime,
                CdfId = CdfId,
                BoundaryConditionsExtracted = BoundaryConditionsExtracted,
                Version = Version,
                UnitSystem = UnitSystem,
                UpdatedTime = UpdatedTime,
                ModelType = ModelType,
                IsVLPGenerated = IsVLPGenerated,
            };
        }

        /// <summary>
        /// Create a settings object containing the model file details.
        /// The data is initialized with values from the stored state, but the 
        /// boundary conditions is initialized to an empty dictionary that has to 
        /// be filled with data extracted from the simulator
        /// </summary>
        /// <returns></returns>
        internal ModelFileSettings CreateModelFileSetttings(IEnumerable<BoundaryConditionData> selectedBc)
        {
            var settings = new ModelFileSettings
            {
                ModelName = ModelName,
                LocalFilePath = FilePath,
                RemoteFileName = FileName,
                UnitSystem = UnitSystem,
                BoundaryConditions = selectedBc.Any() ? selectedBc.ToList() : null,
                Metadata = new OrderedDictionary(),
                ModelParsingLog = (ModelParsingLog) ParsingInfo,
                Wells = new List<ReferenceData>(),
                Tanks = new List<ReferenceData>(),
                Pipes = new List<ReferenceData>(),
                LinkedModels = new List<ReferenceData>(),
            };
            return settings;
        }
    }

    public class ConfigurationFileState : ConfigurationStateBase
    {

        private string _resultsSequence;
        public string ResultsSequence
        {
            get => _resultsSequence;
            set
            {
                if (value == _resultsSequence) return;
                LastTimeModified = DateTime.UtcNow;
                _resultsSequence = value;
            }
        }

        private long _resultsSequenceLastRow;
        public long ResultsSequenceLastRow
        {
            get => _resultsSequenceLastRow;
            set
            {
                if (value == _resultsSequenceLastRow) return;
                LastTimeModified = DateTime.UtcNow;
                _resultsSequenceLastRow = value;
            }
        }

        private string _curvesSequence;
        public string CurvesSequence
        {
            get => _curvesSequence;
            set
            {
                if (value == _curvesSequence) return;
                LastTimeModified = DateTime.UtcNow;
                _curvesSequence = value;
            }
        }

        private long _curvesSequenceLastRow;
        public long CurvesSequenceLastRow
        {
            get => _curvesSequenceLastRow;
            set
            {
                if (value == _curvesSequenceLastRow) return;
                LastTimeModified = DateTime.UtcNow;
                _curvesSequenceLastRow = value;
            }
        }

        public ConfigurationFileState(string id) : base(id)
        {
        }

        public override void Init(FileStatePoco poco)
        {
            base.Init(poco);
            if (poco is ConfigurationFileStatePoco mPoco)
            {
                _resultsSequence = mPoco.ResultsSequence;
                _resultsSequenceLastRow = mPoco.ResultsSequenceLastRow;
                _curvesSequence = mPoco.CurvesSequence;
                _curvesSequenceLastRow = mPoco.CurvesSequenceLastRow;
            }
        }

        public override FileStatePoco GetPoco()
        {
            return new ConfigurationFileStatePoco
            {
                Id = Id,
                ModelName = ModelName,
                Source = Source,
                DataSetId = DataSetId,
                FilePath = FilePath,
                CreatedTime = CreatedTime,
                CdfId = CdfId,
                LastRun = LastRun,
                UpdatedTime = UpdatedTime,
                RunDataSequence = RunDataSequence,
                RunSequenceLastRow = RunSequenceLastRow,
                ResultsSequence = ResultsSequence,
                ResultsSequenceLastRow = ResultsSequenceLastRow,
                CurvesSequence = CurvesSequence,
                CurvesSequenceLastRow = CurvesSequenceLastRow
            };
        }
    }

    public class ModelFileStatePoco : ModelStateBasePoco
    {
        [StateStoreProperty("bc-extracted")]
        public bool BoundaryConditionsExtracted { get; internal set; }
        [StateStoreProperty("unit-system")]
        public UnitSystem UnitSystem { get; internal set; }
        [StateStoreProperty("model-type")]
        public ModelType ModelType { get; internal set; }
        [StateStoreProperty("is-vlp-generated")]
        public bool IsVLPGenerated { get; internal set; }
  }

    public class ConfigurationFileStatePoco : ConfigurationStateBasePoco
    {
        [StateStoreProperty("results-sequence")]
        public string ResultsSequence { get; internal set; }
        [StateStoreProperty("results-sequence-last-row")]
        public long ResultsSequenceLastRow { get; internal set; }
        [StateStoreProperty("curves-sequence")]
        public string CurvesSequence { get; internal set; }
        [StateStoreProperty("curves-sequence-last-row")]
        public long CurvesSequenceLastRow { get; internal set; }
    }

}

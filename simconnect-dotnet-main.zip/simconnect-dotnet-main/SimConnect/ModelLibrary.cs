﻿using Cognite.Extensions;
using Cognite.Extractor.Common;
using Cognite.Extractor.StateStorage;
using Cognite.Extractor.Utils;
using Cognite.Simulator.Extensions;
using Cognite.Simulator.Utils;
using CogniteSdk;
using Microsoft.Extensions.Logging;
using OpenServer;
using SimulatorCommon;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SimConnect
{
    public class ModelLibrary : 
        ModelLibraryBase<ModelFileState, ModelFileStatePoco, ModelParsingLog>
    {
        // Injected services
        private readonly ISimulatorCollection _simulators;
        
        public ModelLibrary(
            FullConfig config,
            CogniteDestination cdf,
            ISimulatorCollection simulators,
            ILogger<ModelLibrary> logger,
            FileDownloadClient client,
            StagingArea<ModelParsingLog> staging,
            IExtractionStateStore store = null) : 
            base(config.Connector.ModelLibrary, config.Simulators, cdf, logger, client, staging, store)
        {
            _simulators = simulators;
        }

        protected override ModelFileState StateFromFile(File file)
        {
            if (!(file.Metadata.TryGetValue("version", out var fileVersion)
                && int.TryParse(fileVersion, out var intVersion)))
            {
                Logger.LogError("Model {Name} does not have version information. skipping", file.Name);
                return null;
            }
            if (!file.Metadata.TryGetValue("modelName", out var modelName))
            {
                Logger.LogError("Model {Name} does not define a model name. skipping", file.Name);
                return null;
            }
            if (!file.Metadata.TryGetValue("unitSystem", out var modelUnitSystem)) {
                // Defaults to Oil Field if the metadata is not present
                modelUnitSystem = "OilField";
            }
            if (!Enum.TryParse(modelUnitSystem, out UnitSystem unitSystemValue))
            {
                Logger.LogError("Model {Name} does not define a unit system. skipping", file.Name);
                return null;
            }
            ModelType type = ModelType.Unknown;
            if (file.Metadata.ContainsKey("modelType") &&
                Enum.TryParse(file.Metadata["modelType"], out ModelType modelType))
            {
                type = modelType;
            }
            var hasFileName = file.Metadata.TryGetValue("fileName", out var modelFileName);
            var modelState = new ModelFileState(file.ExternalId)
            {
                UpdatedTime = file.LastUpdatedTime,
                ModelName = modelName,
                Source = file.Source,
                DataSetId = file.DataSetId,
                CreatedTime = file.CreatedTime,
                CdfId = file.Id,
                BoundaryConditionsExtracted = false,
                Version = intVersion,
                UnitSystem = unitSystemValue,
                FileName = hasFileName ? modelFileName : "",
                FileMetadata = file.Metadata,
                ModelType = type,
            };
            if (file.Metadata.TryGetValue("errorMessage", out var errorMessage) &&
                !string.IsNullOrEmpty(errorMessage))
            {
                Logger.LogError("Model {Name} v{Version} cannot be opened: {Message}. skipping", 
                    file.Name,
                    intVersion,
                    errorMessage);
                modelState.CanRead = false;
            }
            return modelState;
        }

        private async Task<IEnumerable<BoundaryConditionData>> GetModelBoundaryConditions(
            SimulatorModel model,
            long? dataSetId,
            CancellationToken token)
        {
            var sequences = Cdf.CogniteClient.Sequences;
            var sequenceData = await sequences.FindModelBoundaryConditions(
                model,
                token);

            var data = await sequences.ListRowsAsync(new SequenceRowQuery
            {
                ExternalId = sequenceData.ExternalId
            }, token);
            var ids = data.Columns.Select(c => c.ExternalId).ToArray();
            int idIndex = Array.IndexOf(ids, BoundaryConditionsSequenceColumns.Id);
            int timeSeriesIndex = Array.IndexOf(ids, BoundaryConditionsSequenceColumns.TimeSeries);
            int nameIndex = Array.IndexOf(ids, BoundaryConditionsSequenceColumns.Name);
            int addressIndex = Array.IndexOf(ids, BoundaryConditionsSequenceColumns.Address);
            var boundaryConditions = sequenceData.Rows.Select(r =>
            {
                var values = r.GetStringValues();
                return new BoundaryConditionData
                {
                    Model = model,
                    DataSetId = dataSetId,
                    Key = values[idIndex],
                    TimeSeriesId = values[timeSeriesIndex],
                    Name = nameIndex >= 0 ? values[nameIndex] : SimulatorExtensions.GetBoundaryConditionName(values[idIndex]),
                    Address = addressIndex >= 0 ? values[addressIndex] : null,
                };
            }).ToList();
            return boundaryConditions;
        }
        
        protected override async Task ExtractModelInformation(
            IEnumerable<ModelFileState> group,
            CancellationToken token)
        {
            IEnumerable<BoundaryConditionData> bcs = Enumerable.Empty<BoundaryConditionData>();

            // For each model, retrieve the boundary conditions sequence from CDF.
            // The sequence maps a boundary condition type to the ID of the time series that
            // should contain the boundary condition values
            try
            {
                if (group.First().Source == SimulatorType.PROSPER.ToString())
                {
                    bcs = await GetModelBoundaryConditions(
                        group.First().Model,
                        group.First().DataSetId,
                        token);
                }
            }
            catch (BoundaryConditionsMapNotFoundException e)
            {
                // If boundary conditions map was not found, skip and try again later
                Logger.LogDebug(e.Message);
                return;
            }

            foreach (var file in group)
            {
                ModelFileSettings modelSettings = file.CreateModelFileSetttings(bcs);

                // Init the model parsing log. This creates a row in Raw indicating that
                // the model is being parsed by the connector
                file.ParsingInfo.Status = ParsingStatus.running;
                file.ParsingInfo.AddInfo("Extracting model information");

                Logger.LogDebug("Attempting to parse model {Name}, version {Version}", file.ModelName, file.Version);
                
                try
                {
                    await UpdateModelInformationInCdf(file, modelSettings, token);
                    Logger.LogInformation("Updated {Num} boundary conditions time series in CDF for model {Name}",
                        bcs.Count(),
                        file.ModelName);

                    if (file.BoundaryConditionsExtracted)
                    {
                        file.ParsingInfo.SetSuccess("Finished extracting model information");
                    }
                    else
                    {
                        file.ParsingInfo.SetRetrying();
                    }
                }
                catch (Exception e)
                {
                    var errorMessage = e.Message;
                    if (e is SimulatorException se)
                    {
                        errorMessage = se.SimulatorMessage ?? se.Message;
                        if (!se.CanRetry)
                        {
                            var fileMetadata = new Dictionary<string, string>
                            {
                                { "errorMessage", errorMessage.LimitUtf8ByteCount(512) }
                            };
                            await CdfFiles.UpdateAsync(new List<FileUpdateItem>()
                            {
                                new FileUpdateItem(file.Id)
                                {
                                    Update = new FileUpdate
                                    {
                                        Metadata = new UpdateDictionary<string>(fileMetadata, null)
                                    }
                                }
                            }, token);

                            file.ParsingInfo.SetFailure(errorMessage);
                            
                            file.CanRead = false; // This file cannot be parsed. Will not retry
                            Logger.LogError("Unable to extract model information: {Message}", e.Message);
                            continue;
                        }
                    }
                    Logger.LogWarning("Error parsing model {Name}: {Error}. Will retry", file.ModelName, errorMessage);
                    file.ParsingInfo.SetRetrying(errorMessage);
                    continue; // Retry for any other exception
                }
            }
        }

        // Santize the filename by lowercasing it and removing any leading or trailing spaces and normalizing it
        private string SanitizeFileName(string fileName)
        {
            return fileName.ToLower().Trim().Normalize();
        }

        private IEnumerable<ModelFileState> GetAllModelVersions(string simulator, string modelName, string fileName)
        {
            // Check if modelName is not empty
            if(!string.IsNullOrEmpty(modelName))
            {
                var modelVersionsByModelName = this.State.Values
                    .Where(s => s.ModelName == modelName
                        && s.Source == simulator
                        && s.Version > 0
                        && !string.IsNullOrEmpty(s.FilePath))
                    .OrderByDescending(s => s.Version);
                // Check the results length
                if(modelVersionsByModelName.Count() > 0){
                    return modelVersionsByModelName;
                }
            }

            // Search for the model by filename of the equipment
            var modelVersions = this.State.Values
                .Where(s => SanitizeFileName(s.FileName) == SanitizeFileName(fileName)
                    && s.Source == simulator
                    && s.Version > 0
                    && !string.IsNullOrEmpty(s.FilePath))
                .OrderByDescending(s => s.Version);
            return modelVersions;
        } 

        private ModelFileState GetLatestModelVersion(string simulator, string modelName, string fileName)
        {
            if(string.IsNullOrEmpty(modelName) && string.IsNullOrEmpty(fileName)){
                throw new ArgumentNullException();
            }

            var modelVersions = GetAllModelVersions(simulator, modelName,fileName);
            if (modelVersions.Any())
            {
                return modelVersions.First();
            }
            return null;
        }

        // Update the isVLPGenerated flag on the model file state
        public void UpdateModelFileState(string fileName, string Simulator)
        {
            // find the model file state by filename and simulator
            var modelFileState = this.State.Values
                .Where(s => SanitizeFileName(s.FileName) == SanitizeFileName(fileName)
                    && s.Source == Simulator
                    && s.Version > 0
                    && !string.IsNullOrEmpty(s.FilePath))
                .OrderByDescending(s => s.Version)
                .FirstOrDefault();
            if (modelFileState != null)
            {
                // Update the isVLPGenerated flag on the model file state
                modelFileState.IsVLPGenerated = true;
            }
            return;
        }

        private async Task UpdateModelInformationInCdf(
            ModelFileState file,
            ModelFileSettings modelSettings,
            CancellationToken token)
        {
            var simulator = _simulators.GetSimulator(file.Source);
            simulator.ExtractModelInformation(modelSettings);

            if (modelSettings.LinkedModels.Any() || modelSettings.Wells.Any() || modelSettings.Tanks.Any() || modelSettings.Pipes.Any())
            {
                foreach(var gapModel in modelSettings.LinkedModels)
                {
                    var model = GetLatestModelVersion("GAP", gapModel.Label, gapModel.FileName);
                    if (model != null)
                    {
                        gapModel.File = model.FilePath;
                    }
                }
                foreach(var well in modelSettings.Wells)
                {
                    var model = GetLatestModelVersion("PROSPER", well.Label, well.FileName);
                    if (model != null)
                    {
                        well.File = model.FilePath;
                        well.IsVLPGenerated = model.IsVLPGenerated;
                    }
                }
                foreach(var tank in modelSettings.Tanks)
                {
                    var model = GetLatestModelVersion("MBAL", tank.Label, tank.FileName);
                    if (model != null)
                    {
                        tank.File = model.FilePath;
                    }
                }
                foreach(var pipe in modelSettings.Pipes)
                {
                    var model = GetLatestModelVersion("PROSPER", pipe.Label, pipe.FileName);
                    if (model != null)
                    {
                        pipe.File = model.FilePath;
                        pipe.IsVLPGenerated = model.IsVLPGenerated;
                    }
                }
                simulator.ResolveModelReferences(modelSettings, UpdateModelFileState);
            }

            modelSettings.ModelParsingLog.Log.Add(
                new ParsingLog(ParsingLogLevel.INFORMATION, "Updating CDF resources"));
            await Staging.UpdateEntry(file.Id, modelSettings.ModelParsingLog, token);

            var fileMetadata = new Dictionary<string, string>();
            if (modelSettings.ModelType != ModelType.Unknown)
            {
                if (file.ModelType != ModelType.Unknown && file.ModelType != modelSettings.ModelType)
                {
                    throw new SimulatorException(
                        $"Model type '{modelSettings.ModelType}' does not match the specified type: '{file.ModelType}'")
                    {
                        CanRetry = false
                    };
                }
                // Update the model file with the extracted model type
                fileMetadata["modelType"] = modelSettings.ModelType.ToString();
            }
            if (modelSettings.Metadata.Count > 0)
            {
                // Update the model file with any extra extracted metadata
                foreach(DictionaryEntry kvp in modelSettings.Metadata)
                {
                    var key = kvp.Key.ToString();
                    var value = kvp.Value.ToString();
                    fileMetadata[key] = value;
                }
            }

            // limit the total size of the meta-data dictionary to conform with CDF limits
            var sanitizedMetadata = file.FileMetadata.MergeFileMetadata(
                fileMetadata,
                out bool hasChanged);
            if (hasChanged && sanitizedMetadata.Any())
            {
                try
                {
                    var updatedFiles = await CdfFiles.UpdateAsync(new List<FileUpdateItem>()
                    {
                        new FileUpdateItem(file.Id)
                        {
                            Update = new FileUpdate
                            {
                                Metadata = new UpdateDictionary<string>(sanitizedMetadata, null)
                            }
                        }
                    }, token);

                    // Save the updated time in the state, so that the file does not
                    // get processed again
                    file.UpdatedTime = updatedFiles.First().LastUpdatedTime;
                    file.ModelType = modelSettings.ModelType;
                }
                catch (Exception e)
                {
                    Logger.LogError("Could not update model {Model} type in CDF: {Message}", file.ModelName, e.Message);
                    modelSettings.ModelParsingLog.Log.Add(
                        new ParsingLog(ParsingLogLevel.WARNING, $"Connector error: {e.Message}"));
                    return;
                }
            }

            if (modelSettings.BoundaryConditions == null)
            {
                file.BoundaryConditionsExtracted = true;
                return;
            }
            var bcExtracted = modelSettings.BoundaryConditions
                .Where(bc => bc.Extracted == true)
                .ToList();
            if (bcExtracted.Any())
            {
                // Map time series ids to boundary conditions DTOs
                var toCreateMap = bcExtracted
                    .ToDictionary(
                        bc => bc.TimeSeriesId, // time series id
                        bc => bc as BoundaryCondition); // boundary condition object

                // Get or create the missing time series
                try
                {
                    await Cdf.CogniteClient.TimeSeries.GetOrCreateBoundaryConditions(
                        toCreateMap,
                        token);
                }
                catch (BoundaryConditionsCreationException bcEx)
                {
                    var errorMessages = string.Join(", ", bcEx.CogniteErrors.Select(e => e.Message));
                    Logger.LogError("Could not create boundary conditions time series: {Errors}", errorMessages);
                    modelSettings.ModelParsingLog.Log.Add(
                        new ParsingLog(ParsingLogLevel.WARNING, $"Connector error: {errorMessages}"));
                    return;
                }

                // Create the data points with the boundary conditions values
                var datapointMap = toCreateMap.ToDictionary(
                    kvp => new Identity(kvp.Key),
                    kvp => new List<Datapoint>
                    {
                        new Datapoint(file.CreatedTime, (kvp.Value as BoundaryConditionData).Value)
                    }.AsEnumerable());
                // Insert the data points into CDF
                var dpResult = await Cdf.InsertDataPointsAsync(datapointMap, SanitationMode.None, RetryMode.OnError, token);
                
                if (!dpResult.IsAllGood)
                {
                    var errorMessages = string.Join(", ", dpResult.Errors.Select(e => e.Message));
                    Logger.LogError("Could not upload data points to boundary conditions time series: {Error}", errorMessages);
                    modelSettings.ModelParsingLog.Log.Add(
                        new ParsingLog(ParsingLogLevel.WARNING, $"Connector error: {errorMessages}"));
                }
                else
                {
                    // In case everything succeeds, update the local state
                    file.BoundaryConditionsExtracted = true;
                }
            }
            else
            {
                // Nothing to extract
                file.BoundaryConditionsExtracted = true;
            }
        }
    }
}

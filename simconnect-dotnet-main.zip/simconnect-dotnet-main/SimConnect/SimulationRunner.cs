﻿using Cognite.Extensions;
using Cognite.Extractor.Common;
using Cognite.Extractor.Utils;
using Cognite.Simulator.Extensions;
using Cognite.Simulator.Utils;
using CogniteSdk;
using Microsoft.Extensions.Logging;
using Prometheus;
using SimulatorCommon;
using SimulatorCommon.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SimConnect
{
    public class SimulationRunner : 
        SimulationRunnerBase<ModelFileState, ConfigurationFileState, ConfigurationDTO>
    {
        private readonly FullConfig _config;
        private readonly CogniteDestination _cdf;
        private readonly ILogger<SimulationRunner> _logger;
        private readonly ISimulatorCollection _simulators;

        public SimulationRunner(
            FullConfig config, 
            CogniteDestination cdf, 
            ILogger<SimulationRunner> logger, 
            ModelLibrary modelLibrary, 
            ConfigurationLibrary configLibrary,
            ISimulatorCollection simulators): base (
                  config.Connector, 
                  config.Simulators, 
                  cdf,
                  modelLibrary, 
                  configLibrary, 
                  logger)
        {
            _config = config;
            _cdf = cdf;
            _logger = logger;
            _simulators = simulators;
        }

        protected override void InitSimulationEventMetadata(
            ModelFileState modelState,
            ConfigurationFileState configState,
            ConfigurationDTO configObj,
            Dictionary<string, string> metadata)
        {
            if (configObj.EstimateBHP != null && configObj.EstimateBHP.Enabled)
            {
                metadata.Add("estimateBhpMethod", configObj.EstimateBHP.Method.ToString());
            };
        }

        protected override async Task RunSimulation(
            Event runEvent,
            DateTime startTime,
            ModelFileState model,
            ConfigurationFileState calcState,
            ConfigurationDTO calcConfig,
            SamplingRange samplingRange,
            CancellationToken token)
        {
            _logger.LogInformation("Running {Calculation} for model {Model}", calcConfig.CalculationName, model.ModelName);

            // Prepare input values and output placeholders
            var calcSettings = await PrepareInputOutputPlaceholders(model, calcConfig, samplingRange, token);

            Exception calcError = null;
            try
            {
                // Invoke the simulator to run the calculation
                var simulator = _simulators.GetSimulator(calcConfig.Simulator);
                simulator.RunCalculation(calcConfig.CalculationType, calcSettings);
            }
            catch (Exception e)
            {
                // keep track of any exceptions thrown by the calculation
                calcError = e;
            }

            try
            {
                // Try to save inputs and outputs to CDF, if any
                _logger.LogInformation("Saving {Calculation} results for model {Model} in CDF", calcConfig.CalculationName, model.ModelName);

                // Save input and output time series
                await StoreCalcTimeSeriesInCdf(calcSettings.Inputs, calcSettings.Outputs, samplingRange, calcConfig, runEvent, model.Version, token);

                // Save output sequences
                await StoreCalcSeqsInCdf(calcSettings.TabularOutputs, calcState, runEvent, startTime, token);
            }
            catch (Exception)
            {
                if (calcError == null)
                {
                    throw;
                }
            }
            
            // If the calculation failed, throw the original exception after saving the partial results
            if (calcError != null)
            {
                throw calcError;
            }
            _logger.LogInformation("{Calculation} for model {Model} completed", calcConfig.CalculationName, model.ModelName);
        }

    private async Task<CalculationSettings> PrepareInputOutputPlaceholders(
            ModelFileState model,
            ConfigurationDTO calcConfig,
            SamplingRange samplingRange,
            CancellationToken token)
        {
            List<CalculationInput> simInputs = new();
            List<CalculationOutput> simOutputs = new();
            List<CalculationTabularOutput> simTabularOutputs = new();
            var simulator = _simulators.GetSimulator(calcConfig.Simulator);
            var calculation = calcConfig.Calculation;
            foreach (var inputTs in calcConfig.InputTimeSeries)
            {
                if(!Enum.TryParse(inputTs.UnitType.ReplaceSlashAndBackslash(""), true, out UnitType unitType))
                {
                    throw new SimulationException($"Unit type is not supported: {inputTs.UnitType}");
                }
                var internalUnit = simulator.GetUnit(model.UnitSystem, unitType);

                var dps = await _cdf.CogniteClient.DataPoints.GetSample(
                    inputTs.SensorExternalId,
                    inputTs.AggregateType.ToDataPointAggregate(),
                    calcConfig.DataSampling.Granularity,
                    samplingRange,
                    token);
                var inputDps = dps.ToTimeSeriesData(
                    calcConfig.DataSampling.Granularity,
                    inputTs.AggregateType.ToDataPointAggregate());
                if (inputDps.Count == 0)
                {
                    throw new SimulationException($"Did not find data points for input timeseries {inputTs.SensorExternalId}");
                }
                var averageValue = inputDps.GetAverage();
                var convertedValue = CalculationUtils.ConvertUnit(averageValue, unitType, inputTs.Unit, internalUnit);
                // NOTE: we assume that unit from routine config is the same as unit of the time series in CDF
                var calcInput = new CalculationInput
                {
                    Name = inputTs.Name,
                    Type = inputTs.Type.ToString(),
                    UnitType = unitType,
                    Unit = inputTs.Unit,
                    Value = new WrappedValue() {
                        Unit = internalUnit,
                        Numerical = convertedValue,
                    },
                    Calculation = calculation,
                };
                simInputs.Add(calcInput);
            }
            foreach (var output in calcConfig.OutputTimeSeries)
            {
                if (!Enum.TryParse(output.UnitType.ReplaceSlashAndBackslash(""), true, out UnitType unitType))
                {
                    throw new SimulationException($"Unit type is not supported: {output.UnitType}");
                }
                var calcOutput = new CalculationOutput
                {
                    Name = output.Name,
                    Type = output.Type.ToString(),
                    UnitType = unitType,
                    Unit = output.Unit,
                    Calculation = calculation,
                };
                simOutputs.Add(calcOutput);
            }
            if (calcConfig.OutputSequences != null && calcConfig.OutputSequences.Any())
            {
                foreach (var output in calcConfig.OutputSequences)
                {
                    var calcOutput = new CalculationTabularOutput
                    {
                        Name = output.Name,
                        Type = output.Type.ToString(),
                        OutputType = output.Type,
                        Calculation = calculation,
                    };
                    simTabularOutputs.Add(calcOutput);
                }
            }
            ChokeCurve chokeCurve = null;
            if (calcConfig.ChokeCurve != null && calcConfig.ChokeCurve.Setting != null)
            {
                double[] chokeSettings = new double[calcConfig.ChokeCurve.Setting.Length];
                var outputUnit = simulator.GetUnit(model.UnitSystem, UnitType.Diameter);
                for (int i = 0; i < calcConfig.ChokeCurve.Setting.Length; ++i)
                {
                    var convertedValue = CalculationUtils.ConvertUnit(
                        calcConfig.ChokeCurve.Setting[i],
                        ChokeCurve.UnitType, 
                        calcConfig.ChokeCurve.Unit, 
                        outputUnit);
                    chokeSettings[i] = convertedValue;
                }
                chokeCurve = new ChokeCurve{
                    Opening = calcConfig.ChokeCurve.Opening,
                    Setting = chokeSettings
                };
            }
            var settings = new CalculationSettings
            {
                Calculation = calculation,
                CalculationTime = samplingRange.Midpoint,
                ModelFilePath = model.FilePath,
                UnitSystem = model.UnitSystem,
                ModelType = model.ModelType,
                RootFindingSettings = calcConfig.RootFindingSettings,
                EstimateBHP = calcConfig.EstimateBHP,
                GaugeDepth = calcConfig.GaugeDepth,
                ChokeCurve = chokeCurve,
                Inputs = simInputs,
                Outputs = simOutputs,
                TabularOutputs = simTabularOutputs,
                Routine = calcConfig,
            };
            return settings;
        }

        private async Task StoreCalcSeqsInCdf(
            IEnumerable<CalculationTabularOutput> simTabularOutputs,
            ConfigurationFileState calcState,
            Event runEvent,
            DateTime startTime,
            CancellationToken token,
            bool forceNewSequence = false)
        {
            Dictionary<string, string> eventMetadata = new();
            var sequences = _cdf.CogniteClient.Sequences;
            foreach (var simOutput in simTabularOutputs)
            {
                if (simOutput.Columns == null || !simOutput.Columns.Any())
                {
                    continue;
                }
                var rowCount = simOutput.MaxNumOfRows();

                // Determine what is the sequence id and the row number to start inserting data
                var sequenceId = simOutput.OutputType.IsCurves() ? calcState.CurvesSequence : calcState.ResultsSequence;
                var lastRow = simOutput.OutputType.IsCurves() ? calcState.CurvesSequenceLastRow : calcState.ResultsSequenceLastRow;
                long rowStart = 0;

                if (forceNewSequence)
                {
                    sequenceId = null;
                }
                if (sequenceId != null)
                {
                    rowStart = lastRow + 1;

                    // Create a new sequence if reached the configured row limit
                    if (rowCount + rowStart > _config.Connector.MaximumNumberOfSequenceRows)
                    {
                        sequenceId = null;
                        rowStart = 0;
                    }
                }

                // Update the local state with the sequence ID and the last row number
                if (simOutput.OutputType.IsCurves())
                {
                    calcState.CurvesSequence = sequenceId;
                    calcState.CurvesSequenceLastRow = rowCount + rowStart - 1;
                }
                else
                {
                    calcState.ResultsSequence = sequenceId;
                    calcState.ResultsSequenceLastRow = rowCount + rowStart - 1;
                }
                await ConfigurationLibrary.StoreLibraryState(token);

                try
                {
                    var createdSeq = await sequences.StoreSimulationResults(
                        sequenceId,
                        rowStart,
                        runEvent.DataSetId,
                        simOutput,
                        token);

                    if (simOutput.OutputType.IsCurves())
                    {
                        eventMetadata.Add("outputCurvesSequence", createdSeq.ExternalId);
                        eventMetadata.Add("outputCurvesRowStart", rowStart.ToString());
                        eventMetadata.Add("outputCurvesRowEnd", calcState.CurvesSequenceLastRow.ToString());
                    }
                    else
                    {
                        eventMetadata.Add("outputResultsSequence", createdSeq.ExternalId);
                        eventMetadata.Add("outputResultsRowStart", rowStart.ToString());
                        eventMetadata.Add("outputResultsRowEnd", calcState.ResultsSequenceLastRow.ToString());
                    }
                }
                catch (SimulationTabularResultsException e)
                {
                    throw new ConnectorException(e.Message, e.CogniteErrors);
                }
            }

            if (eventMetadata.Any())
            {
                await _cdf.CogniteClient.Events.UpdateSimulationEvent(
                    runEvent.ExternalId, 
                    startTime, 
                    eventMetadata, 
                    token);
            }
        }

        private async Task StoreCalcTimeSeriesInCdf(
            IEnumerable<CalculationInput> simInputs,
            IEnumerable<CalculationOutput> simOutputs,
            SamplingRange samplingRange,
            ConfigurationDTO calcConfig,
            Event runEvent,
            int modelVersion,
            CancellationToken token)
        {
            var timeSeries = _cdf.CogniteClient.TimeSeries;
            IDictionary<Identity, IEnumerable<Datapoint>> dpsToCreate = new Dictionary<Identity, IEnumerable<Datapoint>>();

            // Collect sampled inputs, to store as time series and data points
            var inputTsToCreate = new List<SimulationInput>();
            foreach (var input in simInputs)
            {
                if (!input.Value.HasValue)
                {
                    continue;
                }
                inputTsToCreate.Add(input);

                // Convert the input to the correct unit
                var convertedValue = input.Value.GetNumericalInUnit(input.UnitType, input.Unit);

                dpsToCreate.Add(
                    new Identity(input.TimeSeriesExternalId),
                    new List<Datapoint> { new Datapoint(samplingRange.Midpoint, convertedValue) });
            }

            // Collect simulation results, to store as time series and data points
            var outputTsToCreate = new List<SimulationOutput>();
            foreach (var output in simOutputs)
            {
                if (!output.Value.HasValue)
                {
                    continue;
                }
                outputTsToCreate.Add(output);
                
                // Convert the output to the correct unit
                var convertedValue = output.Value.GetNumericalInUnit(output.UnitType, output.Unit);

                dpsToCreate.Add(
                    new Identity(output.TimeSeriesExternalId),
                    new List<Datapoint> { new Datapoint(samplingRange.Midpoint, convertedValue) });
            }
            try
            {
                //Store model version time series
                var mvts = await timeSeries.GetOrCreateSimulationModelVersion(calcConfig.Calculation, runEvent.DataSetId, token);
                dpsToCreate.Add(
                    new Identity(mvts.ExternalId),
                    new List<Datapoint> { new Datapoint(samplingRange.Midpoint, modelVersion) });

                // Store input time series
                await timeSeries.GetOrCreateSimulationInputs(inputTsToCreate, runEvent.DataSetId, token);

                // Store output time series
                await timeSeries.GetOrCreateSimulationOutputs(outputTsToCreate, runEvent.DataSetId, token);
            }
            catch (SimulationModelVersionCreationException e)
            {
                throw new ConnectorException(e.Message, e.CogniteErrors);
            }
            catch (SimulationTimeSeriesCreationException e)
            {
                throw new ConnectorException(e.Message, e.CogniteErrors);
            }
            
            var dpResult = await _cdf.InsertDataPointsAsync(
                dpsToCreate,
                SanitationMode.None,
                RetryMode.OnError,
                token);
            if (!dpResult.IsAllGood)
            {
                throw new ConnectorException($"Could not create data points for time series in CDF", dpResult.Errors);
            }
        }
    }
}

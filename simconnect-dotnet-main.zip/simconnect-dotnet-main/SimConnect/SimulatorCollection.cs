﻿using Cognite.Extractor.Utils;
using Cognite.Simulator.Utils;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Microsoft.Extensions.Logging;
using OpenServer;
using SimulatorCommon;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SimConnect
{
    public class SimulatorCollection : ISimulatorCollection
    {
        private readonly ISimulator _dummyProsper;
        private readonly FullConfig _config;
        public readonly ISimulator Prosper;

        public readonly ISimulator Gap;
        public readonly ISimulator Mbal;
        public readonly ISimulator SampleSimulator;

        public SimulatorCollection(
            FullConfig config,
            ProsperSimulator prosper = null,
            GapSimulator gap = null,
            MbalSimulator mbal = null,
            DummyProsperSimulator dummyProsper = null,
            SampleSimulator.SampleSimulator sampleSimulator = null)
        {
            _config = config;
            _dummyProsper = dummyProsper;
            Prosper = prosper;
            Gap = gap;
            Mbal = mbal;
            SampleSimulator = sampleSimulator;
        }

        public ISimulator GetSimulator(string simulatorName)
        {
            if (_dummyProsper != null && _dummyProsper.Id == simulatorName)
            {
                return _dummyProsper;
            }
            if (Prosper != null && Prosper.Id == simulatorName)
            {
                return Prosper;
            }
            if (Gap != null && Gap.Id == simulatorName)
            {
                return Gap;
            }
            if (Mbal != null && Mbal.Id == simulatorName)
            {
                return Mbal;
            }
            if (SampleSimulator != null && SampleSimulator.Id == simulatorName)
            {
                return SampleSimulator;
            }
            throw new ArgumentException($"Simulator {simulatorName} is not recognized by the connector");
        }
    }

    public class ConnectorExtractionPipeline : ExtractionPipeline
    {
        private readonly IEnumerable<SimulatorConfig> _config;

        public ConnectorExtractionPipeline(
            CogniteConfig cdfConfig, 
            PipelineNotificationConfig pipeConfig, 
            CogniteDestination destination,
            IEnumerable<SimulatorConfig> config,
            ILogger<ExtractionPipeline> logger) : base(cdfConfig, pipeConfig, destination, logger)
        {
            _config = config;
        }

        public async Task Init(CancellationToken token)
        {
            var simConfig = new SimulatorConfig
            {
                Name = string.Join(" and ", _config.Select(c => c.Name).ToArray()),
                DataSetId = _config.First().DataSetId // Not ideal, but extraction pipelines do not support multiple datasets
            };
            await Init(simConfig, token);
        }
    }

    public static class SimulatorCollectionExtensions
    {
        public static void AddSimulators(this IServiceCollection services, FullConfig config)
        {
            services.AddSingleton<ISimulatorCollection, SimulatorCollection>();
            if (config.Simulators.Count == 0)
            {
                return;
            }
            services.AddScoped(p =>
            {
                var exPipe = new ConnectorExtractionPipeline(
                    config.Cognite,
                    config.Connector.PipelineNotification,
                    p.GetRequiredService<CogniteDestination>(),
                    config.Simulators,
                    p.GetRequiredService<ILogger<ConnectorExtractionPipeline>>());
                return exPipe;
            });
            foreach (var simulator in config.Simulators)
            {
                if (simulator.Name == "PROSPER")
                {
                    if (config.DummySimulator)
                    {
                        services.AddSingleton<DummyProsperSimulator>();
                    }
                    else
                    {
                        services.TryAddSingleton<OpenServerApi>();
                        services.AddSingleton<ProsperSimulator>();
                    }
                }
                else if (simulator.Name == "GAP")
                {
                    services.TryAddSingleton<OpenServerApi>();
                    services.AddSingleton<GapSimulator>();
                }
                else if (simulator.Name == "MBAL")
                {
                    services.TryAddSingleton<OpenServerApi>();
                    services.AddSingleton<MbalSimulator>();
                }
                else if (simulator.Name == "ProcessSim")
                {
                    services.AddSingleton<SampleSimulator.SampleSimulator>();
                }
            }
        }

    }
}

﻿using Cognite.Extensions;
using Cognite.Extractor.Common;
using Cognite.Extractor.Utils;
using CogniteSdk;
using CogniteSdk.Resources;
using Microsoft.Extensions.Logging;
using SimulatorCommon;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

namespace SimConnect
{
    public static class CdfUtils
    {
        public const string SimulationOutputResourceType = "Simulation Output";
        public const string DataModelVersion = "1.0.2";

        // Initialized from the config file
        public static string RawDatabase;
        public static string DeleteLogRawTable;
        public static string ModelParsingRawTable;

        public const int FilesMetadataMaxBytesPerKey = 128;
        public const int FilesMetadataMaxBytesPerValue = 256; // The actual limit is 10240, but this would consume all the metadata space for one value;
        public const int FilesMetadataMaxNumKeys = 256;
        public const int FilesMetadataMaxBytes = 10240;

        public static string[] GetStringValues(this SequenceRow row)
        {
            List<string> result = new();
            foreach (var val in row.Values)
            {
                if (val != null && val.Type == MultiValueType.STRING)
                {
                    result.Add(((MultiValue.String)val).Value);
                }
                else
                {
                    result.Add(null);
                }
            }
            return result.ToArray();
        }

        /// <summary>
        /// Build a metadata dictionary with only the pairs that are new or updated.
        /// Make sure the metadata entries are valid according to CDF limits.
        /// </summary>
        public static Dictionary<string, string> MergeFileMetadata(
            this Dictionary<string, string> metadata,
            Dictionary<string, string> newData,
            out bool changed)
        {
            changed = false;
            var newDict = new Dictionary<string, string>();
            var numBytes = 0;
            var count = 0;
            foreach(var pair in metadata)
            {
                bool valChanged = false;
                var pairBytes = Encoding.UTF8.GetByteCount(pair.Key);
                if (newData.TryGetValue(pair.Key, out string value))
                {
                    // trucate values that are too big
                    value = value.LimitUtf8ByteCount(FilesMetadataMaxBytesPerValue);
                    if (pair.Value != value)
                    {
                        valChanged = true;
                    }
                }
                else
                {
                    value = pair.Value;
                }
                pairBytes += Encoding.UTF8.GetByteCount(value);
                if (valChanged)
                {
                    if (numBytes + pairBytes <= FilesMetadataMaxBytes && count + 1 <= FilesMetadataMaxNumKeys)
                    {
                        newDict[pair.Key] = value;
                        numBytes += pairBytes;
                        count++;
                    }
                }
                else
                {
                    numBytes += pairBytes;
                    count++;
                }
                changed &= valChanged;
            }
            var missingPairs = newData
                .Where(k => !metadata.ContainsKey(k.Key))
                .ToList();
            foreach(var pair in missingPairs)
            {
                var keySize = Encoding.UTF8.GetByteCount(pair.Key);
                if (keySize > FilesMetadataMaxBytesPerKey)
                {
                    // Skip keys that are too big
                    continue;
                }
                // trucate values that are too big
                var newValue = pair.Value.LimitUtf8ByteCount(FilesMetadataMaxBytesPerValue);
                var pairBytes = keySize + Encoding.UTF8.GetByteCount(newValue);
                if (numBytes + pairBytes <= FilesMetadataMaxBytes && count + 1 <= FilesMetadataMaxNumKeys)
                {
                    newDict[pair.Key] = newValue;
                    numBytes += pairBytes;
                    changed = true;
                    count++;
                }
            }
            return newDict;
        }

        public static async Task<dynamic> GetDeletionLog(
            string key,
            Client client,
            ILogger logger,
            CancellationToken token)
        {
            return await GetRawRecord(
                key,
                RawDatabase,
                DeleteLogRawTable,
                client,
                logger,
                token);
        }

        public static void InitConnectorRawDatabase(
            SimConnectConfig config)
        {
            RawDatabase = config.RawStorage.Database;
            DeleteLogRawTable = config.RawStorage.DeleteLogTable;
            ModelParsingRawTable = config.RawStorage.ModelParsingLogTable;
        }

        private static async Task<dynamic> GetRawRecord(
            string key,
            string rawDb,
            string rawTable,
            Client client,
            ILogger logger,
            CancellationToken token)
        {
            try
            {
                return await client.Raw
                    .GetRowAsync<dynamic>(rawDb, rawTable, key, token: token);
            }
            catch (ResponseException re) when (re.Code == 404)
            {
                return null;
            }
            catch (Exception e)
            {
                logger.LogError("Could not fecth data from SimConfig delete log.", e);
                return null;
            }
        }
    }
}

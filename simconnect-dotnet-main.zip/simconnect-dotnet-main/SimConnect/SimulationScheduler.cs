﻿using Cognite.Extractor.Utils;
using Cognite.Simulator.Utils;
using Microsoft.Extensions.Logging;

namespace SimConnect
{
    /// <summary>
    /// Specialized scheduler for configurations of type <see cref="ConfigurationDTO"/>.
    /// No extra implementation beyond the base scheduler offered by the utils library is needed
    /// </summary>
    public class SimulationScheduler : SimulationSchedulerBase<ConfigurationFileState, ConfigurationDTO>
    {

        public SimulationScheduler(
            FullConfig config,
            ConfigurationLibrary configLib,
            ILogger<SimulationScheduler> logger,
            CogniteDestination cdf) 
            : base(config.Connector, configLib, logger, cdf)
        {
        }
    }
}
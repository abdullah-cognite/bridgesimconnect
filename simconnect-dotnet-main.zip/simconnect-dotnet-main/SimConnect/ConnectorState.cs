﻿using Cognite.Extractor.StateStorage;
using System;

namespace SimConnect
{
    public class ConnectorState : IExtractionState
    {
        public string Id { get; }

        public DateTime? LastTimeModified { get; protected set; }

        public ConnectorState(string id)
        {
            Id = id;
        }

    }

    public class ConnectorStatePoco : BaseStorableState
    {

    }
}

using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;
using Cognite.Extractor.Common;
using Cognite.Extractor.Utils;
using Cognite.Simulator.Extensions;
using Cognite.Simulator.Utils;
using CogniteSdk;
using Microsoft.Extensions.Logging;
using SimulatorCommon;

namespace SimConnect
{
    public class Connector : ConnectorBase
    {
        private readonly FullConfig _config;
        private readonly ILogger<Connector> _logger;

        private readonly ISimulatorCollection _simulators;
        private readonly ModelLibrary _modelLibrary;
        private readonly ConfigurationLibrary _configLibrary;
        private readonly SimulationRunner _runner;
        private readonly SimulationScheduler _scheduler;
        private readonly ConnectorExtractionPipeline _pipeline;
        private readonly string _version;

        public Connector(
            FullConfig config, 
            CogniteDestination cdf, 
            ISimulatorCollection simulators,
            ModelLibrary modelLibrary, 
            ConfigurationLibrary configurationLibrary,
            SimulationRunner runner,
            SimulationScheduler scheduler,
            ConnectorExtractionPipeline pipeline,
            ILogger<Connector> logger) : base(cdf, config.Simulators, logger)
        {
            _config = config;
            _logger = logger;
            _simulators = simulators;
            _modelLibrary = modelLibrary;
            _configLibrary = configurationLibrary;
            _runner = runner;
            _scheduler = scheduler;
            _pipeline = pipeline;
            _version = Cognite.Extractor.Metrics.Version.GetVersion(
                Assembly.GetExecutingAssembly(), 
                "0.0.1");
        }

        public override async Task Init(CancellationToken token)
        {
            CdfUtils.InitConnectorRawDatabase(_config.Connector);
            var extraInfo = new Dictionary<string, string>();
            foreach (var simulatorConfig in _config.Simulators)
            {
                var simulator = _simulators.GetSimulator(simulatorConfig.Name);
                simulator.TestConnection();
                // TODO: Need to fix the library so that extra info is per simulator,
                // and not common across simulators
                extraInfo[SimulatorIntegrationSequenceRows.SimulatorVersion] = 
                    simulator.GetVersion(); 
            }
            await EnsureSimulatorIntegrationsSequencesExists(token);
            await UpdateIntegrationRows(true, extraInfo, token);
            await _modelLibrary.Init(token);
            await _configLibrary.Init(token);
            
            await _pipeline.Init(token);
        }

        public override async Task Run(CancellationToken token)
        {
            _logger.LogInformation("Connector started, sending status to CDF every {Interval} seconds",
               _config.Connector.StatusInterval);
            try
            {
                var linkedTokenSource = CancellationTokenSource.CreateLinkedTokenSource(token);
                var linkedToken = linkedTokenSource.Token;

                var taskList = new List<Task> { Heartbeat(linkedToken), _pipeline.PipelineUpdate(linkedToken) };
                var modelLibTasks = _modelLibrary.GetRunTasks(linkedToken);
                taskList.AddRange(modelLibTasks);
                var configLibTasks = _configLibrary.GetRunTasks(linkedToken);
                taskList.AddRange(configLibTasks);
                taskList.Add(_runner.Run(linkedToken));
                taskList.Add(_scheduler.Run(linkedToken));
                await taskList.RunAll(linkedTokenSource);
            }
            catch (OperationCanceledException)
            {
                _logger.LogWarning("Cancellation requested. Exiting the connector");
            }
        }

        public override string GetConnectorName()
        {
            return _config.Connector.GetConnectorName();
        }

        public override TimeSpan GetHeartbeatInterval()
        {
            return TimeSpan.FromSeconds(_config.Connector.StatusInterval);
        }

        public override string GetConnectorVersion()
        {
            return _version;
        }
  }
}

using Cognite.Extractor.Utils;
using Cognite.Simulator.Utils;
using OpenServer;
using System;
using System.Collections.Generic;

namespace SimConnect
{
    public class FullConfig : BaseConfig
    {
        public SimConnectConfig Connector { get; set; }
        public OpenServerConfig OpenServer { get; set; }

        /// <summary>
        /// List of simulators available to the connector
        /// </summary>
        public IList<SimulatorConfig> Simulators { get; set; }

        /// <summary>
        /// If set to true, creates a dummy simulator to use instead of connecting
        /// to the real simulator. Should be used for testing, not exposed in the documentation.
        /// </summary>
        public bool DummySimulator { get; set; } = false;

        public override void GenerateDefaults() {
            base.GenerateDefaults();
            if (Connector == null) Connector = new SimConnectConfig();
            if (OpenServer == null) OpenServer = new OpenServerConfig();
            OpenServer.GenerateDefaults();
            if (Simulators == null) Simulators = new List<SimulatorConfig>();
            if (Connector.ModelLibrary == null) Connector.ModelLibrary = new FileLibraryConfig();
            if (Connector.ModelLibrary.LibraryId == null) Connector.ModelLibrary.LibraryId = "ModelLibraryState";
            if (Connector.ModelLibrary.LibraryTable == null) Connector.ModelLibrary.LibraryTable = "ModelLibrary";
            if (Connector.ModelLibrary.FilesTable == null) Connector.ModelLibrary.FilesTable = "ModelLibraryFiles";
            if (Connector.ModelLibrary.FilesDirectory == null) Connector.ModelLibrary.FilesDirectory = "./files";
            
            if (Connector.ConfigurationLibrary == null) Connector.ConfigurationLibrary = new FileLibraryConfig();
            if (Connector.ConfigurationLibrary.LibraryId == null) Connector.ConfigurationLibrary.LibraryId = "ConfigurationLibraryState";
            if (Connector.ConfigurationLibrary.LibraryTable == null) Connector.ConfigurationLibrary.LibraryTable = "ConfigurationLibrary";
            if (Connector.ConfigurationLibrary.FilesTable == null) Connector.ConfigurationLibrary.FilesTable = "ConfigurationLibraryFiles";
            if (Connector.ConfigurationLibrary.FilesDirectory == null) Connector.ConfigurationLibrary.FilesDirectory = "./configurations";
            
            if (Connector.PipelineNotification == null) Connector.PipelineNotification = new PipelineNotificationConfig();
            if (Connector.RawStorage == null) Connector.RawStorage = new ConnectorRawConfig();
            if (Connector.RawStorage.Table == null) Connector.RawStorage.Table = Connector.RawStorage.ModelParsingLogTable; // for backwards compatibility
        }
    }

    public class SimConnectConfig : ConnectorConfig
    {
        public FileLibraryConfig ModelLibrary { get; set; }
        public FileLibraryConfig ConfigurationLibrary { get; set; }
        public ConnectorRawConfig RawStorage { get; set; }
    }

    public class ConnectorRawConfig : StagingConfig
    {
        public string ModelParsingLogTable { get; set; } = "simconfig_model_parsing_log";
        public string DeleteLogTable { get; set; } = "simconfig_delete_log_table";
    }
}
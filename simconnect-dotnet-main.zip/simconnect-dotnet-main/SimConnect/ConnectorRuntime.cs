﻿using System.Threading;
using System;
using Microsoft.Extensions.DependencyInjection;
using Cognite.Extractor.Configuration;
using Cognite.Extractor.Logging;
using Cognite.Extractor.Utils;
using Microsoft.Extensions.Logging;
using System.Threading.Tasks;
using System.Net.Http;
using System.Text.Json;
using Polly.Timeout;
using OpenServer;
using Cognite.Extractor.StateStorage;
using Cognite.Extractor.Metrics;
using System.Reflection;
using SimulatorCommon;
using Cognite.Extractor.Common;
using Cognite.Simulator.Utils;
using Cognite.Simulator.Utils.Automation;

namespace SimConnect
{
    public class ConnectorRuntime
    {
        public static async Task RunStandalone()
        {
            var logger = LoggingUtils.GetDefault();
            using var tokenSource = new CancellationTokenSource();

            Console.CancelKeyPress += (sender, eArgs) =>
            {
                logger.LogWarning("Ctrl-C pressed: Cancelling tasks");
                eArgs.Cancel = true;
                tokenSource.Cancel();
            };

            await Run(logger, tokenSource.Token).ConfigureAwait(false);
        }

        public static async Task Run(ILogger defaultLogger, CancellationToken token)
        {
            var assembly = Assembly.GetExecutingAssembly();
            var version = Cognite.Extractor.Metrics.Version.GetVersion(assembly, "0.0.1");
            
            var services = new ServiceCollection();
            services.AddLogger();
            services.AddCogniteClient("SimConnect", "SimConnect/v0.0.1 (Cognite)", true);
            FullConfig config;
            try
            {
                config = services.AddConfig<FullConfig>("./config.yml", 1);
                config.GenerateDefaults();
                services.AddConfig(config, typeof(OpenServerConfig), typeof(SimConnectConfig));
            }
            catch (ConfigurationException e)
            {
                defaultLogger.LogError("Failed to load configuration file: {Message}", e.Message);
                return;
            }
            services.AddStateStore();
            services.AddMetrics();
            services.AddSimulators(config);
            services.AddHttpClient<FileDownloadClient>();
            services.AddScoped<Connector>();
            services.AddScoped<ModelLibrary>();
            services.AddScoped<ConfigurationLibrary>();
            services.AddScoped<SimulationRunner>();
            services.AddScoped<SimulationScheduler>();
            services.AddStagingArea<ModelParsingLog>(config.Connector.RawStorage);

            using var provider = services.BuildServiceProvider();

            var logger = provider.GetRequiredService<ILogger<ConnectorRuntime>>();
            logger.LogInformation("Starting the simulator connector: {Version}", version);

            var metrics = provider.GetRequiredService<MetricsService>();
            metrics.Start();

            var destination = provider.GetRequiredService<CogniteDestination>();
            try
            {
                await destination.TestCogniteConfig(token);
            }
            catch (Exception e)
            {
                logger.LogError(e, "Error testing connection to CDF: {Message}", e.Message);
                return;
            }

            while (!token.IsCancellationRequested)
            {
                using var scope = provider.CreateScope();
                try
                {
                    var connector = scope.ServiceProvider.GetRequiredService<Connector>();
                    await connector.Init(token);
                    await connector.Run(token);
                }
                catch (TaskCanceledException) when (token.IsCancellationRequested)
                {
                    logger.LogWarning("Connector manually interrupted.Exiting");
                    break;
                }
                catch (Exception e)
                {
                    var pipeline = scope.ServiceProvider.GetRequiredService<ConnectorExtractionPipeline>();
                    await pipeline.NotifyError(e, token);
                    if (e is ConnectorException ce)
                    {
                        logger.LogError("Connector error: {Message}", ce.Message);
                        if (ce.InnerException != null)
                        {
                            logger.LogError("- {Message}", ce.InnerException.Message);
                        }
                        foreach (var err in ce.Errors)
                        {
                            logger.LogError("- {Message}", ce.Message);
                        }
                    }
                    else if (e is CogniteSdk.ResponseException re)
                    {
                        // CDF request failed but request id and status code are available.
                        logger.LogError("Request to CDF failed with code {Code}: {Message}. Request id: {RequestId}", re.Code, re.Message, re.RequestId);
                    }
                    else if (e is HttpRequestException he)
                    {
                        // Did not get response from server (server down or other networking errors).
                        logger.LogError("The HTTP client failed to contact CDF: {Message}", he.Message);
                    }
                    else if (e is JsonException je)
                    {
                        // Json decode exception produced by the SDK. Unlikely to happen.
                        logger.LogError("Response from CDF cannot be parsed: {Message}", je.Message);
                    }
                    else if (e is TimeoutRejectedException)
                    {
                        // Timeout from the http client policy.
                        logger.LogError("Request to CDF timeout after retry");
                    }
                    else if (e is SimulatorConnectionException sue)
                    {
                        // If the simulator is not available, log to Windows events and exit
                        defaultLogger.LogError(sue.Message);
                        logger.LogError(sue, sue.Message);
                        break;
                    }
                    else
                    {
                        logger.LogError(e, "Unhandled exception: {message}", e.Message);
                        // sourceProgram.Cancel();
                    }

                    // Most errors may be intermittent. Wait and restart.
                    if (!token.IsCancellationRequested)
                    {
                        var delay = TimeSpan.FromSeconds(5);
                        logger.LogWarning("Restarting connector in {time} seconds", delay.TotalSeconds);
                        await Task.Delay(delay, token);
                    }
                }
            }
            await metrics.Stop();
            
            logger.LogInformation("Simulator connector exiting");
        }
        
    }
}

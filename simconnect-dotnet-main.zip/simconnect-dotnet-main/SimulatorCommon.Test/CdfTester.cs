﻿using Cognite.Extractor.Logging;
using Cognite.Extractor.Utils;
using Cognite.Simulator.Utils;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using SimConnect;
using System;
using System.Collections.Generic;
using System.Threading;

namespace SimulatorCommon.Test
{
    public class CdfTester : IDisposable
    {
        public ILogger<CdfTester> Logger { get; }
        public ServiceProvider Provider { get; }
        public CogniteDestination Destination { get; }
        public CancellationTokenSource Source { get; }
        public string Project { get; private set; }
        public string Host { get; private set; }
        public FullConfig Config { get; }
        public SimulatorMock SimMock { get; }

        private static int _configIdx;
        private readonly string _configPath;
        private readonly string _modelsPath;
        private readonly string _configurationsPath;

        public CdfTester(bool addConnector = false)
        {
            // Thread safe increment and store
            var index = Interlocked.Increment(ref _configIdx);
            _configPath = $"test-config-{index}";
            _modelsPath = $"./models-{index}";
            _configurationsPath = $"./configurations-{index}";
            System.IO.File.WriteAllLines(_configPath, GetConfig(addConnector));
            var services = new ServiceCollection();
            Config = services.AddConfig<FullConfig>(_configPath, 1);
            services.AddSingleton(Config.Connector);
            services.AddLogger();
            services.AddCogniteClient("simint-integration-tests", userAgent: "SimInt-Tests/v1.0.0 (Test)");
            if (addConnector)
            {
                SimMock = new SimulatorMock();
                SimMock.SetupId();
                SimMock.SetupTestConnection();
                SimMock.SetupGetVersion();
                SimMock.SetupGetBoundaryConditions();
                SimMock.SetupGetUnit();
                SimMock.SetupRunCalculation();
                var simCollection = new SimulatorCollectionMock(SimMock.Object);
                simCollection.SetupGetSimulator();
                services.AddSingleton(simCollection.Object);
                services.AddHttpClient<FileDownloadClient>();
                services.AddSingleton<Connector>();
                services.AddSingleton<ModelLibrary>();
                services.AddSingleton<ConfigurationLibrary>();
                services.AddSingleton<SimulationRunner>();
                services.AddSingleton<SimulationScheduler>();
                services.AddSingleton<StagingConfig>(Config.Connector.RawStorage);
                services.AddSingleton<StagingArea<ModelParsingLog>>();
                services.AddSingleton<ConnectorExtractionPipeline>();
                services.AddSingleton<IEnumerable<SimulatorConfig>>(Config.Simulators);
                services.AddSingleton(Config.Connector.PipelineNotification);
            }
            Provider = services.BuildServiceProvider();
            Logger = Provider.GetRequiredService<ILogger<CdfTester>>();
            Destination = Provider.GetRequiredService<CogniteDestination>();
            Source = new CancellationTokenSource();
        }

        public string[] GetConfig(bool addConnector = false)
        {
            var config = new List<string>() {
                "version: 1",
                "logger:",
                "  console:",
                "    level: verbose",
                "cognite:",
                "  project: cognite-simulator-integration",
                "  host: https://westeurope-1.cognitedata.com",
                "  idp-authentication:",
                "    client-id: ${TEST_CLIENT_ID}",
                "    tenant: ${TEST_TENANT}",
                "    secret: ${TEST_SECRET}",
                "    scopes:",
                "    - https://westeurope-1.cognitedata.com/.default"
            };
            if (addConnector)
            {
                config.AddRange(new[]
                {
                    "simulators:",
                    "  - name: PROSPER",
                    "    data-set-id: ${TEST_DATA_SET}",
                    "connector:",
                    "  name-prefix: integration-tests-connector",
                    "  add-machine-name-suffix: false",
                    "  fetch-events-interval: 1",
                    "  model-library:",
                   $"    files-directory: {_modelsPath}",
                    "  configuration-library:",
                   $"    files-directory: {_configurationsPath}",
                    "  raw-storage:",
                    "    enabled: true",
                    "    database: INTEGRATION-TESTS",
                    "    model-parsing-log-table: model_parsing_log"
                });
            }
            return config.ToArray();
        }
        
        #region IDisposable Support
        private bool disposedValue = false; // To detect redundant calls

        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                    System.IO.File.Delete(_configPath);
                    if (System.IO.Directory.Exists(_modelsPath))
                    {
                        System.IO.Directory.Delete(_modelsPath, true);
                    }
                    if (System.IO.Directory.Exists(_configurationsPath))
                    {
                        System.IO.Directory.Delete(_configurationsPath, true);
                    }
                    Provider.Dispose();
                    Source.Dispose();
                }
                disposedValue = true;
            }
        }
        public void Dispose()
        {
            Dispose(true);
        }
        #endregion
    }
}

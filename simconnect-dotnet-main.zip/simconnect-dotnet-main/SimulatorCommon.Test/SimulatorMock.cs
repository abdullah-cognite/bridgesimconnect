﻿using Cognite.Simulator.Extensions;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimulatorCommon.Test
{
    /// <summary>
    /// This is a mock implementation of a simulator. Used to run integration
    /// tests against CDF without having to connect with an actual simulator
    /// </summary>
    public class SimulatorMock : Mock<ISimulator>
    {
        public Dictionary<string, double> BcValues;
        public Dictionary<string, string> BcUnits;

        public SimulatorMock()
            : base(MockBehavior.Strict)
        {
            BcValues = new()
            {
                { SimulatorConstants.CGR, 2.57 },
                { SimulatorConstants.N2, 5.58 },
                { SimulatorConstants.ResPerm, 235.0 },
                { SimulatorConstants.ResPress, 3125.30 },
                { SimulatorConstants.ResTemp, 213.99 },
                { SimulatorConstants.ResThick, 77.0 },
                { SimulatorConstants.Skin, 3.0 },
                { SimulatorConstants.WellLen, 2825.0 },
                { SimulatorConstants.WGR, 0.0 },
                { "TestBc", 1.0 }
            };
            BcUnits = new()
            {
                { SimulatorConstants.CGR, "STB/MMscf" },
                { SimulatorConstants.N2, "percent" },
                { SimulatorConstants.ResPerm, "md" },
                { SimulatorConstants.ResPress, "psig" },
                { SimulatorConstants.ResTemp, "deg F" },
                { SimulatorConstants.ResThick, "feet" },
                { SimulatorConstants.Skin, "" },
                { SimulatorConstants.WellLen, "feet" },
                { SimulatorConstants.WGR, "STB/MMscf" },
                { "TestBc", "t/s" }
            };

        }

        public void SetupId()
        {
            SetupGet(p => p.Id)
                .Returns(() => "PROSPER");
        }

        public void SetupTestConnection()
        {
            Setup(p => p.TestConnection())
                .Verifiable();
        }

        public void SetupGetVersion()
        {
            Setup(p => p.GetVersion())
                .Returns("1.0.0");
        }

        public void SetupGetBoundaryConditions()
        {
            Setup(p => p.ExtractModelInformation(
                It.IsNotNull<ModelFileSettings>()))
                .Callback<ModelFileSettings>((settings) =>
                {
                    foreach (var bc in settings.BoundaryConditions)
                    {
                        bc.Value = BcValues[bc.Key];
                        bc.Unit = BcUnits[bc.Key];
                        bc.Extracted = true;
                    }
                })
                .Verifiable();
        }

        public void SetupGetUnit()
        {
            Setup(p => p.GetUnit(
                It.IsAny<UnitSystem>(),
                It.IsAny<UnitType>()))
                .Returns<UnitSystem, UnitType>((unitSystem, unitType) => GetUnit(unitSystem, unitType))
                .Verifiable();
        }

        private static string GetUnit(UnitSystem unitSystem, UnitType unitType)
        {
            return unitSystem switch
            {
                UnitSystem.OilField => unitType switch
                {
                    UnitType.Pressure => "psig",
                    UnitType.LiqRateGasRate => "STB/MMscf",
                    UnitType.GasRate => "MMscf/day",
                    _ => throw new ArgumentException("Unit type not expected in the tests"),
                },
                _ => throw new ArgumentException("Unit system not expected in the tests")
            };
        }

        public void SetupRunCalculation()
        {
            Setup(p => p.RunCalculation(
                It.IsAny<string>(),
                It.IsNotNull<CalculationSettings>()))
                .Callback<string, CalculationSettings>((calcType, settings) =>
                {
                    foreach (var input in settings.Inputs)
                    {
                        input.SourceAddress = $"{input.Type}.Input.MockAddress";
                    }
                    foreach (var output in settings.Outputs)
                    {
                        output.SourceAddress = $"{output.Type}.Output.MockAddress";
                        output.Value = new WrappedValue () {
                            Numerical = 123.4567,
                            Unit = GetUnit(settings.UnitSystem, output.UnitType)
                        };
                    }
                    foreach (var output in settings.TabularOutputs)
                    {
                        if (output.Columns == null)
                        {
                            output.Columns = new Dictionary<string, SimulationResultColumn>();
                        }
                        var values = new double[] { 0.0, 1.0, 2.0, 3.0, 4.0 };
                        output.Columns.Add(
                            "Value1[Unit1]",
                            new SimulationNumericResultColumn
                            {
                                Rows = values,
                                Metadata = new Dictionary<string, string>()
                                {
                                    { "name", "Value1" },
                                    { "unit", "Unit1" },
                                    { "unitType", "N/A" },
                                    { "address", "N/A" },
                                }
                            });
                        output.Columns.Add(
                            "Value2 [Unit2]",
                            new SimulationNumericResultColumn
                            {
                                Rows = values,
                                Metadata = new Dictionary<string, string>()
                                {
                                    { "name", "Value2" },
                                    { "unit", "Unit2" },
                                    { "unitType", "N/A" },
                                    { "address", "N/A" },
                                }
                            });
                    }
                })
                .Verifiable();
        }
    }

    public class SimulatorCollectionMock : Mock<ISimulatorCollection>
    {
        private ISimulator _simulator;

        public SimulatorCollectionMock(ISimulator mockSimulator)
            : base(MockBehavior.Strict)
        {
            _simulator = mockSimulator;
        }

        public void SetupGetSimulator()
        {
            Setup(sc => sc.GetSimulator(
                It.IsAny<string>()))
                .Returns<string>(s => _simulator)
                .Verifiable();
        }
    }
}

﻿using Cognite.Simulator.Extensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace SimulatorCommon.Test
{
    public class CommonUtilsTest
    {
        internal enum TestEnum
        {
            ABCTest,
            TestABCTest
        }

        [Theory]
        [InlineData(TestEnum.ABCTest, "ABC Test")]
        [InlineData(TestEnum.TestABCTest, "Test ABC Test")]
        [InlineData(UnitType.GasRate, "Gas Rate")]
        [InlineData(UnitType.GasRateLiqRate, "Gas Rate Liq Rate")]
        [InlineData(UnitType.Pressure, "Pressure")]
        public void TestEnumToText(
            Enum inputEnum,
            string outputString)
        {
            var converted = inputEnum.EnumToText();
            Assert.Equal(outputString, converted);
        }

        [Theory]
        [InlineData("LiqRate/GasRate", UnitType.LiqRateGasRate)]
        [InlineData("GasRate/LiqRate", UnitType.GasRateLiqRate)]
        public void TestEnumParsing(string enumString, UnitType expectedEnum)
        {
            Assert.True(Enum.TryParse(enumString.ReplaceSlashAndBackslash(""), true, out UnitType unitType));
            Assert.Equal(expectedEnum, unitType);
        }

        [Fact]
        public void TestIntToEnumThrows()
        {
            Assert.Throws<ArgumentException>(() => CommonUtils.IntToEnum<UnitType>(50));
        }

    }
}

using System;
using SimulatorCommon;
using Xunit;

namespace SimulatorCommon.Test
{
    public class CalculationUtilsTest
    {
        [Theory]
        [InlineData(86d, 30d, UnitType.Temperature, "deg F", "deg C")]
        [InlineData(1469.5948d, 100d, UnitType.Pressure, "psia", "atm a")]
        public void TestUnitConvertion(
            double input, 
            double expected, 
            UnitType unitType, 
            string inputUnit, 
            string outputUnit)
        {
            var converted = CalculationUtils.ConvertUnit(input, unitType, inputUnit, outputUnit);
            Assert.Equal(expected, converted, 4);
        }
        
    }
}

﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System.CommandLine;
using System.CommandLine.Builder;
using System.CommandLine.NamingConventionBinder;
using System.CommandLine.Parsing;

namespace SimConnectService
{
    public class Program
    {
        public static int Main(string[] args)
        {
            return GetCommandLineOptions().InvokeAsync(args).Result;
        }

        private static Parser GetCommandLineOptions()
        {
            var rootCommand = new RootCommand();

            var flag = new Option<bool>("--service", "Required flag when starting the connector as a service");
            flag.AddAlias("-s");
            rootCommand.AddOption(flag);

            var dir = new Option<string>("--workdir", "Indicates the working directory to run the connector from");
            dir.AddAlias("-w");
            rootCommand.AddOption(dir);

            rootCommand.Handler = CommandHandler.Create((SimConnectParams setup) =>
            {
                if (setup.Service)
                {
                    RunService(setup);
                }
                else
                {
                    RunStandalone();
                }
            });

            return new CommandLineBuilder(rootCommand)
                .UseVersionOption()
                .UseHelp()
                .Build();
        }

        private static void RunStandalone()
        {
            SimConnect.ConnectorRuntime.RunStandalone().Wait();
        }
        
        private static void RunService(SimConnectParams setup)
        {
            var builder = Host.CreateDefaultBuilder()
                .ConfigureServices((hostContext, services) =>
                {
                    services.AddSingleton(setup);
                    services.AddHostedService<Worker>();
                });
            builder = builder.ConfigureLogging(loggerFactory => loggerFactory.AddEventLog())
                .UseWindowsService(options => options.ServiceName = "SimConnect");
            builder.Build().Run();
        }
    }
    public class SimConnectParams
    {
        public bool Service { get; set; }
        public string WorkDir { get; set; }
    }

}

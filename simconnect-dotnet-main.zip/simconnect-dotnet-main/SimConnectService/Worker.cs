﻿using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System;
using System.IO;
using System.Threading;
using System.Threading.Tasks;

namespace SimConnectService
{
    public class Worker : BackgroundService
    {
        private readonly ILogger<Worker> _eventLog;
        private readonly SimConnectParams _setup;
        private readonly IHostApplicationLifetime _hostApplicationLifetime;

        public Worker(IHostApplicationLifetime hostApplicationLifetime, ILogger<Worker> eventLog, SimConnectParams setup)
        {
            _hostApplicationLifetime = hostApplicationLifetime;
            _eventLog = eventLog;
            _setup = setup;
        }
        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            _eventLog.LogInformation("Starting SimConnect service");

            try
            {
                // Move to the connector working directory
                var path = _setup.WorkDir;
                if (path == null)
                {
                    path = Directory.GetParent(AppContext.BaseDirectory)?.Parent?.FullName;
                }
                if (string.IsNullOrEmpty(path))
                {
                    _eventLog.LogError("Invalid working directory");
                    return;
                }
                if (!Directory.Exists(path))
                {
                    _eventLog.LogError("Invalid working directory: {Message}", path);
                    return;
                }
                Directory.SetCurrentDirectory(path);

                // Start the connector loop
                await SimConnect.ConnectorRuntime
                    .Run(_eventLog, stoppingToken)
                    .ConfigureAwait(false);
            }
            finally
            {
                // On exit, finalize the host application as well
                _eventLog.LogWarning("Exiting SimConnect service");
                _hostApplicationLifetime.StopApplication();
            }
        }
    }
}

﻿using Cognite.DataProcessing;
using MathNet.Numerics;
using NumSharp;
using SimulatorCommon;
using System;
using System.Collections.Generic;
using System.Linq;

namespace SampleSimulator
{
    partial class SampleSimulator
    {
        private void RateByNodalAnalysis(CalculationSettings settings)
        {
            // Get inputs
            double thp = GetInputValue(settings, SimulationInputConstants.THP);

            // TODO: Find alternative way of storing this data
            LookupTable data = new();
            
            // Dependency on NumSharp because of 2D arrays slicing
            // TODO: Can this be done with the Standard Library if we optimize the way the data is stored?
            NDArray mainTable = np.array(data.mainResultTableValues);

            // Number of variables (minus the input)
            int n = data.mainResultTableNames.Length - 1;

            // Get all THP values
            double[] thpArray = mainTable[":,0"].ToArray<double>();

            // shift the THP array to make the demo results more interesting
            // TODO: store the data in CDF so we don't need to recompile to update the lookup table
            thpArray = thpArray.Select(x => x - 500.0).ToArray<double>();

            // Constrains the THP input to the lookup table range
            thp = TimeSeriesUtils.Constrain(thp, thpArray.Min(), thpArray.Max());

            var resultsOutput = settings.TabularOutputs
                .Where(o => o.OutputType == CalculationTabularOutputType.SystemResults);
            CalculationTabularOutput systemResults = null;
            if (resultsOutput.Any())
            {
                systemResults = resultsOutput.First();
            }

            // Calculate and store the main time series results and the system tabular results
            for (int i = 1; i <= n; i++)
            {
                double[] itemArray = mainTable[$":,{i}"].ToArray<double>();
                var itemInterpolator = Interpolate.Linear(thpArray, itemArray);

                double value = itemInterpolator.Interpolate(thp);
                string name = data.mainResultTableNames[i];
                string unit = data.mainResultTableUnits[i];

                if (name == "Gas Rate")
                {
                    SetOutput(settings, SimulationOutputConstants.GasRate, UnitType.GasRate, unit, value);
                }
                if (name == "Oil Rate")
                {
                    SetOutput(settings, SimulationOutputConstants.OilRate, UnitType.LiqRate, unit, value);
                }
                if (name == "Water Rate")
                {
                    SetOutput(settings, SimulationOutputConstants.WatRate, UnitType.LiqRate, unit, value);
                }
                if (name == "Liquid Rate")
                {
                    SetOutput(settings, SimulationOutputConstants.LiqRate, UnitType.LiqRate, unit, value);
                }
                if (name == "Bottom Hole Pressure")
                {
                    SetOutput(settings, SimulationOutputConstants.BHP, UnitType.Pressure, unit, value);
                }

                if (systemResults is not null)
                {
                    SetResultOutput(systemResults, name, unit, value);
                }
            }

            NDArray curvesTable = np.array(data.curvesTableValues);

            // Number of variables (minus the input)
            n = data.curvesVariables.Length - 1;
            int k = data.curvesTableNames.Length - 1;

            // get all THP values
            thpArray = curvesTable[":,0"].ToArray<double>();

            // shift the THP array to make the demo results more interesting
            thpArray = thpArray.Select(x => x - 500.0).ToArray<double>();

            var curevesOutput = settings.TabularOutputs
                .Where(o => o.OutputType == CalculationTabularOutputType.SystemCurves);
            CalculationTabularOutput systemCurves = null;
            if (curevesOutput.Any())
            {
                systemCurves = curevesOutput.First();
            }

            // Calculate and store the system curves
            for (int i = 1; i <= n; i++)
            {
                string name = data.curvesVariables[i];
                string unit = data.curvesVariableUnits[i];
                var unitType = data.curvesVariableUnitTypes[i];

                var itemValuesList = new List<double>();
                for (int j = 1; j <= k; j++)
                {
                    var item = data.curvesTableNames[j];
                    if (item.StartsWith(name))
                    {
                        double[] itemArray = curvesTable[$":,{j}"].ToArray<double>();
                        var itemInterpolator = Interpolate.CubicSplineMonotone(thpArray, itemArray);
                        itemValuesList.Add(itemInterpolator.Interpolate(thp));
                    }
                }

                var values = itemValuesList.ToArray();
                if (systemCurves is not null)
                {
                    SetCurveOutput(systemCurves, name, unit, values, unitType);
                }
            }
        }
    }
}

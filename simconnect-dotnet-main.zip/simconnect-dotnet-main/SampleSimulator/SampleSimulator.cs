﻿using Cognite.Simulator.Extensions;
using Microsoft.Extensions.Logging;
using OpenServer;
using SimulatorCommon;
using System;
using System.Collections.Generic;
using System.Linq;

namespace SampleSimulator
{
    /// <summary>
    /// This is an example of how to add a new simulator integration.
    /// The integration implementation needs to implement the <seealso cref="ISimulator"/>
    /// interface.
    /// </summary>
    public partial class SampleSimulator : ISimulator
    {
        private readonly ILogger<SampleSimulator> _logger;
        private readonly SampleModelParser _modelParser;

        /// <summary>
        /// Id of the simulator. Used to identify the simulator in SimConnect configuration file.
        /// If a simulator with this id is configured, the model library will fetch models for this
        /// simulator type.
        /// </summary>
        public string Id => "ProcessSim";

        /// <summary>
        /// The constructor should handle the dependencies injected in SimConnect runtime service definition.
        /// In this case, <paramref name="logger"/> is the configured logger to be used.
        /// </summary>
        /// <param name="logger"></param>
        public SampleSimulator(ILogger<SampleSimulator> logger)
        {
            _logger = logger;
            _modelParser = new SampleModelParser(_logger);
        }

        /// <summary>
        /// Returns the unit associated with the given <paramref name="unitType"/> and the given <paramref name="unitSystem"/>.
        /// Although this should be simulator agnostic, the name of the same unit can vary from simulator to simulator.
        /// For simplicity, use the PROSPER implementation here.
        /// </summary>
        /// <param name="unitSystem">Unit System</param>
        /// <param name="unitType">Unit Type</param>
        /// <returns>The unit name</returns>
        public string GetUnit(UnitSystem unitSystem, UnitType unitType)
        {
            return ProsperSimulatorExtensions.GetProsperUnit(unitSystem, unitType);
        }

        /// <summary>
        /// Verify that the connection with the actual simulator works. In case it does not,
        /// this method should throw an exception. For the sample simulator, there is no external
        /// application to connect to, so no need to test the connection.
        /// </summary>
        public void TestConnection()
        {
            _logger.LogDebug(
                "The {SimulatorName} is a sample simulator. It does not require " +
                "an actual connection to operate.", Id);
            _logger.LogInformation("{SimulatorName} ready to use.", Id);
        }

        /// <summary>
        /// This method should extract the model information and store it in the 
        /// <paramref name="modelFileSettings"/> object. Currently the extracted information
        /// consists on boundary conditions and model type;
        /// </summary>
        public void ExtractModelInformation(ModelFileSettings modelFileSettings)
        {
            _modelParser.GetModelInformation(modelFileSettings);
        }

        /// <summary>
        /// Entry point for all supported calculations. The <paramref name="calcType"/> parameter
        /// defines the type of calculation and the <paramref name="settings"/> object contains the
        /// inputs to be used in the simulation, as well as placeholders for the outputs
        /// </summary>
        public void RunCalculation(string calcType, CalculationSettings settings)
        {
            if (calcType == "IPR/VLP")
            {
                // Use Prosper's implementation to add the calculation time to the 
                // tabular outputs.
                // TODO: Extract common functionality elsewhere
                ProsperSimulator.AddCalculationTimeToResultsOutput(settings);
                RateByNodalAnalysis(settings);
                ProsperSimulator.AddCalculationTimeToCurveOutput(settings);
            }
            else
            {
                throw new SimulatorException($"Calculation type {calcType} is not supported");
            }
        }
        
        /// <summary>
        /// Get input value from the calculation settings.
        /// TODO: Avoid code duplication with the PROSPER implementation. 
        /// </summary>
        private static double GetInputValue(CalculationSettings settings, string type)
        {
            var matchingInputs = settings.Inputs.Where(i => i.Type == type);
            if (matchingInputs.Any())
            {
                var input = matchingInputs.First();
                if (input.Value.HasValue)
                {
                    return input.Value.GetNumerical();
                }
                else
                {
                    throw new SimulatorException($"Missing input value required for {settings.Calculation.Name}: {type}");
                }
            }
            throw new SimulatorException($"Input required for {settings.Calculation.Name} not found: {type}");
        }

        /// <summary>
        /// Set output value in the calculation settings.
        /// TODO: Avoid code duplication with the PROSPER implementation. 
        /// </summary>
        private static bool SetOutput(CalculationSettings settings, string type, UnitType unitType, string unit, double value)
        {
            var matchingOutputs = settings.Outputs.Where(i => i.Type == type && i.UnitType == unitType);
            if (matchingOutputs.Any())
            {
                var output = matchingOutputs.First();
                output.SourceAddress = $"ProccessSim.{type}";
                output.Value = new WrappedValue () {
                    Unit = unit,
                    Numerical = value
                };
                return true;
            }
            return false;
        }

        /// <summary>
        /// Set output tabular result value in the calculation settings.
        /// TODO: Avoid code duplication with the PROSPER implementation. 
        /// </summary>
        private static void SetResultOutput(CalculationTabularOutput output, string name, string unit, double value)
        {
            if (output.Columns == null)
            {
                output.Columns = new Dictionary<string, SimulationResultColumn>();
            }

            output.AddValueToColumn("Label", name );
            output.AddValueToColumn("Value", value );
            output.AddValueToColumn("Unit", unit );
        }

        /// <summary>
        /// Set output curve values in the calculation settings.
        /// TODO: Avoid code duplication with the PROSPER implementation. 
        /// </summary>
        private void SetCurveOutput(CalculationTabularOutput output, string name, string unit, double[] values, UnitType unitType)
        {
            if (output.Columns == null)
            {
                output.Columns = new Dictionary<string, SimulationResultColumn>();
            }
            output.Columns.Add(
                $"{name} [{unit}]",
                new SimulationNumericResultColumn
                {
                    Rows = values,
                    Metadata = new Dictionary<string, string>()
                    {
                        { "name", name },
                        { "unit", unit },
                        { "unitType", unitType.ToString() },
                        { "address", $"ProcessSim.Out.{name}" },
                    }
                }
            );
        }

        public string GetVersion()
        {
            return "1.0.0";
        }

        public void ResolveModelReferences(ModelFileSettings modelSettings, Action<string, string> UpdateModelFileState)
        {
            return;
        }
    }
}

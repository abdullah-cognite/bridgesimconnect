﻿using Cognite.Simulator.Utils;
using Microsoft.Extensions.Logging;
using SimulatorCommon;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using YamlDotNet.Serialization;
using YamlDotNet.Serialization.NamingConventions;

namespace SampleSimulator
{
    internal class SampleModelParser
    {
        private readonly ILogger _logger;
        private readonly IDeserializer _deserializer;

        public SampleModelParser(ILogger logger)
        {
            _logger = logger;
            _deserializer = new DeserializerBuilder()
                .WithNamingConvention(CamelCaseNamingConvention.Instance)
                .Build(); ;
        }

        public void GetModelInformation(ModelFileSettings modelFileSettings)
        {
            _logger.LogDebug("Parsing model {Name} ...", modelFileSettings.ModelName);
            var modelPath = modelFileSettings.LocalFilePath;

            try
            {
                modelFileSettings.ModelParsingLog.AddInfo("Reading model file and parsing YAML contents");
                var modelFileContents = File.ReadAllText(modelPath);
                var modelInfo = _deserializer.Deserialize<SampleModelDTO>(modelFileContents);

                if (modelInfo.ModelName != modelFileSettings.ModelName)
                {
                    throw new SimulatorException("Model name does not match the name extracted from the YAML contents");
                }

                modelFileSettings.ModelParsingLog.AddInfo("Extracting model meta-data");
                modelFileSettings.ModelType = modelInfo.ModelType;
                if (modelInfo.Metadata is not null)
                {
                    foreach (var metadata in modelInfo.Metadata)
                    {
                        modelFileSettings.Metadata.Add(
                                      metadata.Key,
                                      metadata.Value);
                    }
                }

                if (!modelFileSettings.BoundaryConditions.Any())
                {
                    modelFileSettings.ModelParsingLog.AddInfo("No boundary conditions configured for the model");
                }
                else
                {
                    modelFileSettings.ModelParsingLog.AddInfo("Extracting boundary conditions");
                }

                foreach (var bc in modelFileSettings.BoundaryConditions)
                {
                    var bcLog = new BoundaryConditionParsingLog
                    {
                        Key = bc.Key
                    };
                    modelFileSettings.ModelParsingLog.BoundaryConditions.Add(bcLog);
                    var extractedBC = modelInfo.BoundaryConditions
                        .Where(i => i.Type == bc.Key)
                        .ToList();
                    if (!extractedBC.Any())
                    {
                        bcLog.Error = true;
                        bcLog.Parsed = true;
                        bcLog.Message = "Boundary condition not found in this model file";
                        continue;
                    }
                    bc.Unit = extractedBC.First().Unit;
                    bc.Value = extractedBC.First().Value;
                    bc.Extracted = true;
                    bcLog.Error = false;
                    bcLog.Parsed = true;
                    bcLog.Message = "Boundary condition extracted successfully";
                }

                _logger.LogDebug("Parsed model {Name} v{Version} successfully", modelInfo.ModelName, modelInfo.ModelVersion);
            }
            catch (Exception e) when (e is not SimulatorException)
            {
                throw new SimulatorException("Could not read model file: invalid format", e)
                {
                    SimulatorMessage = e.Message,
                    CanRetry = false
                };
            }

        }
    }

    /// <summary>
    /// Data object used to deserialize the YAML contents of the model files.
    /// Example:
    /// <code>
    /// modelName: "TestModel"
    /// modelVersion: 1
    /// modelType: OilWell
    /// boundaryConditions:
    ///  - type: CGR
    ///    value: 2.56999
    ///    unit: "STB/MMscf"
    ///  
    ///  - type: WGR
    ///    value: 0.25
    ///    unit: "STB/MMscf"
    /// metadata:
    ///   - key: Company
    ///     value: Cognite
    /// </code>
    /// </summary>
    internal class SampleModelDTO
    {
        public string ModelName { get; set; }
        public int ModelVersion { get; set; }
        public ModelType ModelType { get; set; }
        public List<BoundaryConditionSchema> BoundaryConditions { get; set; }
        public List<SampleModelMetadata> Metadata { get; set; }
    }
    internal class BoundaryConditionSchema
    {
        public string Type { get; set; }
        public double Value { get; set; }
        public string Unit { get; set; }
    }

    internal class SampleModelMetadata
    {
        public string Key { get; set; }
        public string Value { get; set; }
    }
}

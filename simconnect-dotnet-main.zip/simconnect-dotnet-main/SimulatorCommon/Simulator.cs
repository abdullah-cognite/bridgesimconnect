﻿using System.Collections.Generic;
using System;
using SimulatorCommon.Configuration;
using System.Collections.Specialized;
using System.Linq;
using Cognite.Simulator.Extensions;
using Cognite.Simulator.Utils;

namespace SimulatorCommon
{
    /// <summary>
    /// Generic simulator interface
    /// </summary>
    public interface ISimulator
    {
        /// <summary>
        /// Name/identifier of the simulator
        /// </summary>
        public string Id { get; }

        /// <summary>
        /// Test if a connection to the simulator can be established
        /// </summary>
        public void TestConnection();

        /// <summary>
        /// Retrieve the relevant information from the model file, such as values of 
        /// the specified boundary conditions.
        /// The extracted values are written directly to the 
        /// <paramref name="modelFileSettings"/> settings object
        /// </summary>
        /// <param name="modelFileSettings">Object that holds the model information after extraction</param>
        public void ExtractModelInformation(ModelFileSettings modelFileSettings);

        public void RunCalculation(string calcType, CalculationSettings settings);

        public string GetUnit(UnitSystem unitSystem, UnitType unitType);
        public string GetVersion();
        public void ResolveModelReferences(ModelFileSettings modelSettings, Action<string,string> UpdateModelFileState);
    }

    /// <summary>
    /// Collection of simulators that can be used to find a configured simulator
    /// by name/id
    /// </summary>
    public interface ISimulatorCollection
    {
        /// <summary>
        /// Get a simulator by name/id, if configured
        /// </summary>
        /// <param name="simulatorName">Name/id of the simulator</param>
        /// <returns>Simulator object</returns>
        /// <exception cref="ArgumentException">Thrown if the given name is not found</exception>
        public ISimulator GetSimulator(string simulatorName);
    }

    public class SimulatorException : Exception
    {
        public bool CanRetry { get; init; } = false;
        public string SimulatorMessage { get; init; }
        public SimulatorException()
        {
        }

        public SimulatorException(string message) : base(message)
        {
        }

        public SimulatorException(string message, Exception innerException) : base(message, innerException)
        {
        }
    }

    public class ModelFileSettings
    {
        public string ModelName { get; init; }
        public string RemoteFileName { get; init; }
        public string LocalFilePath { get; init; }
        public UnitSystem UnitSystem { get; init; }
        public ModelType ModelType { get; set; } = ModelType.Unknown;
        public List<BoundaryConditionData> BoundaryConditions { get; init; }
        public OrderedDictionary Metadata { get; init; }
        public ModelParsingLog ModelParsingLog { get; init; }
        public List<ReferenceData> Wells { get; init; }
        public List<ReferenceData> Tanks { get; init; }
        public List<ReferenceData> Pipes { get; init; }
        public List<ReferenceData> LinkedModels { get; init; }
        public string GapModelType { get; set; }
        public bool ReferencesResolved => Wells.All(w => w.ReferencesResolved) 
                                            && Tanks.All(t => t.ReferencesResolved) 
                                            && Pipes.All(p => p.ReferencesResolved) 
                                            && LinkedModels.All(l => l.ReferencesResolved);
    }

    // For GAP only
    public class ReferenceData
    {
        public string Label { get; set; }
        public string FileName { get; set; }
        public string File { get; set; }
        public string Type { get; set; } = null;
        public bool ReferencesResolved { get; set; }
        public bool IsVLPGenerated {get; set;}
    }

    // For PROSPER only
    public class BoundaryConditionData : BoundaryCondition
    {
        public double Value { get; set; }
        public string Address { get; set; } = null;
        public string TimeSeriesId { get; init; }
        public bool Extracted { get; set; } = false;
    }

    public static class SimulatorConstants
    {
        public const string ResPress = "ResPress";
        public const string CGR = "CGR";
        public const string WGR = "WGR";
        public const string Skin = "Skin";
        public const string N2 = "N2";
        public const string ResTemp = "ResTemp";
        public const string WellLen = "WellLen";
        public const string ResPerm = "ResPerm";
        public const string ResThick = "ResThick";
        public const string SeparatorGOR = "SeparatorGOR";
        public const string TankGOR = "TankGOR";
        public const string SolutionGOR = "SolutionGOR";
    }

    public static class SimulationInputConstants
    {
        public const string THP = "THP";
        public const string CGR = SimulatorConstants.CGR;
        public const string WGR = SimulatorConstants.WGR;
        public const string GasRate = "GasRate";
        public const string THT = "THT";
        public const string ChokePosition = "chokePosition";
        public const string FlowlinePressure = "flowlinePressure";
        public const string BHPg = "BHPg";
        public const string BHP = "BHP";
        public const string GOR = "GOR";
        public const string WC = "WC";
        public const string OilRate = "OilRate";
        public const string GasLiftRate = "GasLiftRate";
    }

    public static class SimulationOutputConstants
    {
        public const string GasRate = SimulationInputConstants.GasRate;
        public const string OilRate = SimulationInputConstants.OilRate;
        public const string WatRate = "WatRate";
        public const string LiqRate = "LiqRate";
        public const string BHP = SimulationInputConstants.BHP;
    }

    public enum UnitSystem
    {
        OilField, 
        NorSI, 
        CanSI, 
        GerSI, 
        FreSI,
        LatSI
    }

    public enum ModelType
    {
        OilWell,
        GasWell,
        RetrogradeWell,
        PROD,
        WINJ,
        GINJ,
        GLINJ,
        Unknown
    }

    public enum UnitType
    {
        Pressure,
        Temperature,
        GasRate,
        LiqRate,
        [System.Runtime.Serialization.EnumMember(Value = "LiqRate/GasRate")]
        LiqRateGasRate,
        Diameter,
        Length,
        Percentage,
        [System.Runtime.Serialization.EnumMember(Value = "GasRate/LiqRate")]
        GasRateLiqRate,
        Time,
        HeatTransferCoefficient
    }

    public enum CalculationTabularOutputType
    {
        SystemCurves,
        SystemResults,
        LiftCurveSolutionCurves,
        LiftCurveSolutionResults,
        InflowPerformanceResults,
        InflowPerformanceCurves,
        ChokeDpResults,
        ChokeDpCurves
    }

    /// <summary>
    /// Holds a value and its unit
    /// </summary>
    public class WrappedValue
    {
        //
        // <summary>
        // Numerical value
        // </summary>
        public double? Numerical { get; init; }
        //
        // <summary>
        // A unit of measurement for the numerical value
        // </summary>
        public string Unit { get; init; }


        /// <summary>
        /// Check if the numerical value is set
        /// </summary>
        public bool HasValue
        {
            get { return Numerical.HasValue; }
        }

        /// <summary>
        /// Get the numerical value
        /// Throws an exception if the value is not set
        /// </summary>
        public double GetNumerical()
        {
            if (!HasValue) {
                throw new ArgumentException($"value is not set");
            }
            return Numerical.Value;
        }

        /// <summary>
        /// Get the numerical value in the given unit
        /// Throws an exception if the value is not set
        /// </summary>
        public double GetNumericalInUnit(UnitType unitType, string targetUnit)
        {
            if (!HasValue) {
                throw new ArgumentException($"null value cannot be converted to {targetUnit}");
            }
            return CalculationUtils.ConvertUnit(
            Numerical.Value, 
            unitType, 
            Unit, 
            targetUnit);
        }
    }

    public class CalculationInput : SimulationInput
    {
        public UnitType UnitType { get; init; }

        //
        // <summary>
        // The value converted to internal unit used by simulator
        // </summary>
        public WrappedValue Value { get; set; }
        public string SourceAddress
        {
            get
            {
                return GetMetadata("sourceAddress");
            }
            set
            {
                AddMetadata("sourceAddress", value);
            }
        }
    }

    public class CalculationOutput : SimulationOutput
    {
        public UnitType UnitType { get; init; }
        //
        // <summary>
        // The value converted to internal unit used by simulator
        // </summary>
        public WrappedValue Value { get; set; }

        public string SourceAddress
        {
            get
            {
                return GetMetadata("sourceAddress");
            }
            set
            {
                AddMetadata("sourceAddress", value);
            }
        }
    }

    public class CalculationTabularOutput : SimulationTabularResults
    {
        public CalculationTabularOutputType OutputType { get; init; }
        
        public void AddValueToColumn(string header, string value)
        {
            if (Columns.TryGetValue(header, out SimulationResultColumn column) && column is SimulationStringResultColumn strColumn)
            {
                strColumn.Add(value);
            }
            else
            {
                Columns[header] = new SimulationStringResultColumn
                {

                    Rows = new List<string>
                    {
                        value
                    }
                };
            }
        }
        public void AddValueToColumn(string header, double value)
        {
            if (Columns.TryGetValue(header, out SimulationResultColumn column) && column is SimulationNumericResultColumn numColumn)
            {
                numColumn.Add(value);
            }
            else
            {
                Columns[header] = new SimulationNumericResultColumn
                {

                    Rows = new List<double>
                    {
                        value
                    }
                };
            }
        }
    }

    public class CalculationSettings
    {
        public SimulatorCalculation Calculation { get; init; }
        public long CalculationTime { get; init; }
        public string ModelFilePath { get; init; }
        public UnitSystem UnitSystem { get; init; }
        public ModelType ModelType { get; init; }
        public RootFindingSettings RootFindingSettings { get; init; }
        public EstimateBHP EstimateBHP { get; set; }
        public GaugeDepth GaugeDepth { get; set; }
        public ChokeCurve ChokeCurve { get; init; }
        
        // Define inputs as a List. The simulator can add values other than
        // the ones specified in the calculation configuration to this list 
        // in order to save them in CDF as a time series
        public List<CalculationInput> Inputs { get; init; }
        public IEnumerable<CalculationOutput> Outputs { get; init; }
        public IEnumerable<CalculationTabularOutput> TabularOutputs { get; init; }
        public SimulationConfigurationWithRoutine Routine { get; init; }
    }

    public static class SimulatorExtensions
    {
        public static string GetBoundaryConditionName(string bcType)
        {
            return bcType switch
            {
                SimulatorConstants.ResPress => "Reservoir Pressure",
                SimulatorConstants.ResTemp => "Reservoir Temperature",
                SimulatorConstants.ResPerm => "Reservoir Permeability",
                SimulatorConstants.ResThick => "Reservoir Thickness",
                SimulatorConstants.WellLen => "Well Length",
                SimulatorConstants.Skin => "Skin",
                SimulatorConstants.CGR => "Condensate Gas Ratio",
                SimulatorConstants.WGR => "Water Gas Ratio",
                SimulatorConstants.N2 => "Nitrogen Content",
                SimulatorConstants.SeparatorGOR => "Gas to Oil Ratio at the Separator",
                SimulatorConstants.TankGOR => "Gas to Oil Ratio at the Stock Tank",
                SimulatorConstants.SolutionGOR => "Solution Gas to Oil Ratio",
                _ => throw new ArgumentException($"Boundary Condition {bcType} is not supported", nameof(bcType)),
            };
        }

        public static bool IsCurves(this CalculationTabularOutputType type)
        {
            return type == CalculationTabularOutputType.InflowPerformanceCurves ||
                type == CalculationTabularOutputType.SystemCurves ||
                type == CalculationTabularOutputType.LiftCurveSolutionCurves ||
                type == CalculationTabularOutputType.ChokeDpCurves;
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace SimulatorCommon
{
    public static class CommonUtils
    {
        public static string EnumToText(this Enum enumValue)
        {
            var enumStr = enumValue.ToString();
            return Regex.Replace(enumStr, "([a-z](?=[A-Z])|[A-Z](?=[A-Z][a-z]))", "$1 ");
        }

        public static T IntToEnum<T>(int i) where T : Enum
        {
            if (Enum.IsDefined(typeof(T), i))
            {
                return (T)(object)i;
            }
            throw new ArgumentException($"Value {i} cannot be parsed to {nameof(T)}");
        }
        
    }
}

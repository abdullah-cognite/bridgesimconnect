﻿using Cognite.DataProcessing;
using Cognite.Simulator.Extensions;
using System;
namespace SimulatorCommon
{
    public static class CalculationUtils
    {
        private static (double Multiplier, double Shift) GetUnitMultiplierAndShift(UnitType type, string unit)
        {
            return type switch
            {
                UnitType.Pressure => unit switch
                {
                    "psig" => (1.0, 0.0),
                    "psia" => (1.0, 14.696),
                    "BARg" => (0.06894757, 0.0),
                    "BARa" => (0.06894757, 14.696),
                    "kPa g" => (6.894757, 0.0),
                    "kPa a" => (6.894757, 14.696),
                    "Kg/cm2 g" => (0.07031, 0.0),
                    "Kg/cm2 a" => (0.07031, 14.696),
                    "atm a" => (0.068046, 14.696),
                    _ => throw new ArgumentException($"Invalid unit {unit} for type {type}")
                },
                UnitType.GasRate => unit switch
                {
                    "MMscf/day" => (1.0, 0.0),
                    "1000Sm3/d" => (28.17399, 0.0),
                    "1000m3/d" => (28.17399, 0.0),
                    "m3[Vn]/h" => (1112.774, 0.0),
                    "Mscf/day" => (1000.0, 0.0),
                    "scf/day" => (1000000.0, 0.0),
                    "Sm3/day" => (28173.99, 0.0),
                    _ => throw new ArgumentException($"Invalid unit {unit} for type {type}")
                },
                UnitType.LiqRate => unit switch
                {
                    "STB/day" => (1.0, 0.0),
                    "Sm3/day" => (0.1589873, 0.0),
                    "m3/day" => (0.1589873, 0.0),
                    "m3/hour" => (0.006625, 0.0),
                    "scf/day" => (5.615, 0.0),
                    _ => throw new ArgumentException($"Invalid unit {unit} for type {type}")
                },
                UnitType.Temperature => unit switch
                {
                    "deg F" => (1.0, 0.0),
                    "deg C" => (0.5555555, -32.0),
                    "deg R" => (1.0, 459.67),
                    "deg K" => (0.5555555, 459.67),
                    _ => throw new ArgumentException($"Invalid unit {unit} for type {type}")
                },
                UnitType.LiqRateGasRate => unit switch
                {
                    "STB/MMscf" => (1.0, 0.0),
                    "Sm3/Sm3" => (5.6433e-06, 0.0),
                    "m3/m3" => (5.6433e-06, 0.0),
                    "m3/m3Vn" => (5.9524e-06, 0.0),
                    "STB/Mscf" => (0.001, 0.0),
                    "Sm3/kSm3" => (0.0056433, 0.0),
                    "Sm3/MSm3" => (5.6433, 0.0),
                    _ => throw new ArgumentException($"Invalid unit {unit} for type {type}")
                },
                UnitType.Diameter or UnitType.Length => unit switch
                {
                    "inches" => (1.0, 0.0),
                    "m" => (0.0254, 0.0),
                    "feet" => (0.08333333, 0.0),
                    "cm" => (2.54, 0.0),
                    "mm" => (25.4, 0.0),
                    "km" => (2.54e-05, 0.0),
                    "miles" => (1.5782e-05, 0.0),
                    "64ths inch" => (64, 0.0),
                    _ => throw new ArgumentException($"Invalid unit {unit} for type {type}")
                },
                UnitType.Percentage => unit switch
                {
                    "percent" => (1.0, 0.0),
                    "fraction" => (0.01, 0.0),
                    _ => throw new ArgumentException($"Invalid unit {unit} for type {type}")
                },
                UnitType.GasRateLiqRate => unit switch
                {
                    "scf/STB" => (1.0, 0.0),
                    "Sm3/Sm3" => (0.1772, 0.0),
                    "m3/m3" => (0.1772, 0.0),
                    "m3Vn/m3" => (0.168, 0),
                    "Mscf/STB" => (0.001, 0),
                    "kSm3/Sm3" => (0.0001772, 0),
                    _ => throw new ArgumentException($"Invalid unit {unit} for type {type}")
                },
                _ => throw new ArgumentException($"Invalid unit type {type}")
            };
        }

        /// <summary>
        /// Convert the given value of the given unit type from the input unit to
        /// the output unit.
        /// TODO: The input/output unit strings are based on PROSPER units, and should
        /// be converted to more generic enums later
        /// </summary>
        /// <param name="value">Value to be converted</param>
        /// <param name="unitType">Type of unit</param>
        /// <param name="inputUnit">Input unit</param>
        /// <param name="outputUnit">Output unit</param>
        /// <returns>Value converted from <paramref name="inputUnit"/> to <paramref name="outputUnit"/></returns>
        public static double ConvertUnit(double value, UnitType unitType, string inputUnit, string outputUnit)
        {
            var (m_in, s_in) = GetUnitMultiplierAndShift(unitType, inputUnit);
            var (m_out, s_out) = GetUnitMultiplierAndShift(unitType, outputUnit);
            return (value / m_in - s_in + s_out) * m_out;
        }

    }
}

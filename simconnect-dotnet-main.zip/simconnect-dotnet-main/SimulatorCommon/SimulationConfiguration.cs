﻿using Cognite.Simulator.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimulatorCommon.Configuration
{
    public class SimulationConfiguration : SimulationConfigurationWithRoutine
    {
        public EstimateBHP EstimateBHP { get; set; }
        public GaugeDepth GaugeDepth { get; set; }
        public RootFindingSettings RootFindingSettings { get; set; }
        public ChokeCurve ChokeCurve { get; set; }
    }

    public class EstimateBHP
    {
        /// <summary>
        /// Whether or not to estimate BHP for this configuration
        /// </summary>
        public bool Enabled { get; set; }

        /// <summary>
        /// BHP estimation method.
        /// </summary>
        public EstimateBhpMethod Method { get; set; }

        /// <summary>
        /// The gauge depth configuration, in case of <c>BHP from Gradient Traverse</c> method
        /// </summary>
        public GaugeDepth GaugeDepth { get; set; }
    }

    public class GaugeDepth
    {
        public double Value { get; set; }
        public string Unit { get; set; }
    }

    public class RootFindingSettings
    {
        public double RootTolerance { get; set; } = 1.0;
        public RootSolutionType MainSolution { get; set; } = RootSolutionType.Max;
        public RootFindingBracket Bracket { get; set; }
    }

    public class RootFindingBracket
    {
        public double LowerBound { get; set; } = 1;
        public double UpperBound { get; set; } = 100;

        public bool IsValid => LowerBound < UpperBound;
    }

    public class ChokeCurve
    {
        public double[] Opening { get; set; }
        public double[] Setting { get; set; }
        public string Unit { get; set; }

        public static UnitType UnitType => UnitType.Diameter;
    }

    public enum RootSolutionType
    {
        Max,
        Min
    }
    
    public enum EstimateBhpMethod
    {
        LiftCurveRate,
        LiftCurveGaugeBhp,
        GradientTraverse
    }
}

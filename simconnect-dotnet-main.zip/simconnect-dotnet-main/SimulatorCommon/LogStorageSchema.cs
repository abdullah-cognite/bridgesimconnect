﻿using Cognite.Simulator.Utils;
using System.Collections.Generic;

namespace SimulatorCommon
{
    public class ModelParsingLog : ModelParsingInfo
    {
        public List<BoundaryConditionParsingLog> BoundaryConditions { get; set; } = new List<BoundaryConditionParsingLog> { };
    }

    public class BoundaryConditionParsingLog
    {
        public string Key { get; set; }
        public string Address { get; set; }
        public bool Parsed { get; set; }
        public bool Error { get; set; }
        public string Message { get; set; }
    }
}

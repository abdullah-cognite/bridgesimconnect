﻿using Cognite.Simulator.Extensions;
using Cognite.Simulator.Utils;
using Cognite.Simulator.Utils.Automation;
using Microsoft.Extensions.Logging;
using SimulatorCommon;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using CommonUtils = SimulatorCommon.CommonUtils;

namespace OpenServer
{
    public partial class ProsperSimulator : ISimulator
    {
        private readonly ILogger<ProsperSimulator> _logger;
        private readonly OpenServerConfig _config;
        protected readonly OpenServerApi _api;

        public string Id => SimulatorType.PROSPER.ToString();

        private string _version;

        public ProsperSimulator(ILogger<ProsperSimulator> logger, OpenServerApi api, OpenServerConfig config)
        {
            _logger = logger;
            _config = config;
            _api = api;
        }

        public string GetVersion()
        {
            if (_version == null)
            {
                lock (_api.SimulatorLock)
                {
                    try
                    {
                        _api.Initialize();
                        _api.DoCmd("PROSPER.START()");
                        var serverProcess = Process.GetProcessesByName("prosper");
                        var versionInfo = serverProcess[0].MainModule.FileVersionInfo;
                        _version = versionInfo.FileVersion;
                        _api.DoCmd("PROSPER.SHUTDOWN()");
                        _api.Shutdown();
                    }
                    catch (Exception e)
                    {
                        _logger.LogError("Cannot get simulator version: {Error}", e.Message);
                        return "N/A";
                    }
                }
            }
            return _version;
        }

        public void TestConnection()
        {
            _logger.LogInformation("Testing PROSPER connection...");

            lock (_api.SimulatorLock)
            {
                try
                {
                    _api.Initialize();
                    _api.Shutdown();
                }
                catch (SimulatorConnectionException)
                {
                    throw;
                }
                catch (Exception e)
                {
                    throw new SimulatorConnectionException($"{Id} is not available: {e.Message}", e);
                }
            }

            _logger.LogInformation("PROSPER instance created and removed successfully");
        }

        public void ExtractModelInformation(ModelFileSettings modelFileSettings)
        {
            lock (_api.SimulatorLock)
            {
                try
                {
                    modelFileSettings.ModelParsingLog.AddInfo("Opening model file in PROSPER");
                    OpenModelAndSetUnits(modelFileSettings.LocalFilePath, modelFileSettings.UnitSystem);

                    // Extract the fluid type and use it to determine the model type
                    var fluidType = _api.DoGet("PROSPER.SIN.SUM.FLUID");
                    modelFileSettings.ModelType = fluidType switch
                    {
                        "0" => ModelType.OilWell,
                        "1" => ModelType.GasWell,
                        "2" => ModelType.RetrogradeWell,
                        _ => ModelType.Unknown,
                    };

                    modelFileSettings.ModelParsingLog.Log.Add(
                        new ParsingLog(ParsingLogLevel.INFORMATION, "Extracting additional model meta-data"));
                    ExtractModelAdditonalInfo(modelFileSettings);

                    if (!modelFileSettings.BoundaryConditions.Any())
                    {
                        modelFileSettings.ModelParsingLog.Log.Add(
                            new ParsingLog(ParsingLogLevel.INFORMATION, "No boundary conditions configured for the model"));
                    }
                    else
                    {
                        modelFileSettings.ModelParsingLog.Log.Add(
                            new ParsingLog(ParsingLogLevel.INFORMATION, "Extracting boundary conditions"));
                    }

                    ExtractBoundaryConditions(modelFileSettings);
                }
                catch (OpenServerException e)
                {
                    throw new SimulatorException($"Failed to extract information from model {modelFileSettings.ModelName}", e)
                    {
                        CanRetry = e.CanRetry,
                        SimulatorMessage = e.InternalMessage
                    };

                }
                catch (ArgumentException ae)
                {
                    throw new SimulatorException($"Failed to extract information from model {modelFileSettings.ModelName}", ae);
                }
                finally
                {
                    CloseProsper();
                }
            }
        }

        private void ExtractBoundaryConditions(ModelFileSettings modelFileSettings)
        {
            foreach (var bc in modelFileSettings.BoundaryConditions)
            {
                var bcLog = new BoundaryConditionParsingLog
                {
                    Key = bc.Key
                };
                modelFileSettings.ModelParsingLog.BoundaryConditions.Add(bcLog);
                if (!modelFileSettings.ModelType.HasBoundaryCondition(bc))
                {
                    bcLog.Error = true;
                    bcLog.Parsed = true;
                    bcLog.Message = "Boundary condition not supported by this model";
                    return;
                }
                try
                {
                    bc.Address = bc.ToProsperVariableName();
                    bcLog.Address = bc.Address;

                    bc.Value = double.Parse(_api.DoGet(bc.Address));
                    bc.Unit = _api.DoGet($"{bc.Address}.UNITNAME");

                    bc.Extracted = true;
                    bcLog.Error = false;
                    bcLog.Parsed = true;
                    bcLog.Message = "Boundary condition extracted successfully";
                }
                catch (Exception e)
                {
                    bcLog.Error = true;
                    bcLog.Message = e.Message;
                    if (e is OpenServerException oe && oe.ErrorCode == 3004)
                    {
                        // OpenServer variable name not found. Skip without throwing
                        bcLog.Parsed = true;
                        return;
                    }
                    throw;
                }
            }
        }

        public void ExtractModelAdditonalInfo(ModelFileSettings modelFileSettings)
        {
            // Extract some of the PROSPER Options Summary Data to be
            // saved as metadata
            modelFileSettings.Metadata.Add(
                "Temperature Model",
                GetEnumValue<TempModel>("PROSPER.SIN.SUM.TEMPMODEL").EnumToText());
            modelFileSettings.Metadata.Add(
                "Lift Method",
                GetLiftMethod().EnumToText());
            modelFileSettings.Metadata.Add(
                "PVT Method",
                GetEnumValue<PvtModel>("PROSPER.SIN.SUM.PVTMODEL").EnumToText());
            modelFileSettings.Metadata.Add(
                "Flow Type",
                GetEnumValue<FlowType>("PROSPER.SIN.SUM.FLOWTYPE").EnumToText());
            modelFileSettings.Metadata.Add(
                "Well Type",
                GetEnumValue<WellType>("PROSPER.SIN.SUM.WELLTYPE").EnumToText());

            var additionalMetadataCmds = new Dictionary<string, string>()
            {
                {"Company", "PROSPER.SIN.SUM.COMPANY"},
                {"Field", "PROSPER.SIN.SUM.FIELD"},
                {"Location", "PROSPER.SIN.SUM.LOCATION"},
                {"Well", "PROSPER.SIN.SUM.WELL"},
                {"Platform", "PROSPER.SIN.SUM.PLATFORM"},
                {"Analyst", "PROSPER.SIN.SUM.ANALYST"},
                {"Date", "PROSPER.SIN.SUM.DATE"}
            };

            foreach (var metadataDetails in additionalMetadataCmds)
            {
                var modelMetadataKeyValue = _api.DoGet(metadataDetails.Value);
                if (!string.IsNullOrEmpty(modelMetadataKeyValue))
                {
                    modelFileSettings.Metadata.Add(metadataDetails.Key, modelMetadataKeyValue);
                }
            }
        }

        public void RunCalculation(string calcType, CalculationSettings settings)
        {
            lock (_api.SimulatorLock)
            {
                int retriesLeft = _config.NumRetries;
                var delay = TimeSpan.FromSeconds(_config.RetryDelay);
                bool calculationPerformed;
                do
                {
                    if (calcType == "UserDefined")
                    {
                        var inputs = settings.Inputs
                            .Where(i => i.Value.HasValue)
                            .ToDictionary(i => i.Type, i => i.Value.GetNumerical());
                        var routine = new OpenServerRoutine(settings, inputs, _api, _config.BlacklistAddresses, SimulatorType.PROSPER);
                        calculationPerformed = TryRunCalculation(routine.UserDefinedCalculation, settings);
                    }
                    else if (calcType == "IPR/VLP")
                    {
                        calculationPerformed = TryRunCalculation(RateByNodalAnalysis, settings);
                    }
                    else if (calcType == "BhpFromGradientTraverse")
                    {
                        calculationPerformed = TryRunCalculation(BhpFromGradientTraverse, settings);
                    }
                    else if (calcType == "BhpFromRate")
                    {
                        calculationPerformed = TryRunCalculation(BhpFromRate, settings);
                    }
                    else if (calcType == "BhpFromGaugeBhp")
                    {
                        calculationPerformed = TryRunCalculation(BhpFromGaugeBhp, settings);
                    }
                    else if (calcType == "VLP")
                    {
                        calculationPerformed = TryRunCalculation(RateByLiftCurve, settings);
                    }
                    else if (calcType == "IPR")
                    {
                        calculationPerformed = TryRunCalculation(RateByInflowPerformance, settings);
                    }
                    else if (calcType == "ChokeDp")
                    {
                        calculationPerformed = TryRunCalculation(RateByChokePerformance, settings);
                    }
                    else
                    {
                        throw new SimulatorException($"Calculation type {calcType} is not supported");
                    }
                    retriesLeft--;
                    if (!calculationPerformed && retriesLeft > 0)
                    {
                        _logger.LogWarning("{Calc} failed. Retrying in {Delay} seconds", calcType, _config.RetryDelay);
                        Task.Delay(delay).Wait();
                    }
                }
                while (!calculationPerformed && retriesLeft > 0);

                if (!calculationPerformed)
                {
                    throw new SimulatorException($"Calculation failed after {_config.NumRetries} attempts: No license available");
                }
            }
        }

        /// <summary>
        /// Try to perform the given calculation. If the calculation succeeds, return <c>true</c>. If it
        /// failed because an error and cannot be retried, the exception is thrown. If the error can be
        /// retried, it returns <c>false</c>, indicating a failed operation.
        /// </summary>
        /// <param name="DoCalculation">Action that performs the calculation</param>
        /// <param name="settings">Calculation settings</param>
        private bool TryRunCalculation(Action<CalculationSettings> DoCalculation, CalculationSettings settings)
        {
            try
            {
                OpenModelAndSetUnits(settings.ModelFilePath, settings.UnitSystem);

                // Add calculation time as the first row in the results sequence
                AddCalculationTimeToResultsOutput(settings);
                
                // Perform the calculation
                DoCalculation(settings);

                // Add calculation time as column in the curve sequence
                AddCalculationTimeToCurveOutput(settings);
            }
            catch (Exception e) when (e is OpenServerException ose && ose.CanRetry)
            {
                return false;
            }
            catch (Exception e) when (e is OpenServerException ose && !ose.CanRetry)
            {
                throw new SimulatorException($"OpenServer error: {e.Message}", e);
            }
            catch (ArgumentException e)
            {
                throw new SimulatorException($"Argument error: {e.Message}", e);
            }
            finally
            {
                CloseProsper();
            }
            return true;
        }

        public static void AddCalculationTimeToCurveOutput(CalculationSettings settings)
        {
            var curvesOutput = settings.TabularOutputs
                .Where(o => o.OutputType.IsCurves());
            if (curvesOutput.Any() && curvesOutput.First().Columns != null && curvesOutput.First().Columns.Any())
            {
                var output = curvesOutput.First();
                var numRows = output.MaxNumOfRows();
                output.Columns.Add(
                    $"Calculation Time [ms]",
                    new SimulationNumericResultColumn
                    {
                        Rows = Enumerable.Repeat((double) settings.CalculationTime, numRows).ToList(),
                        Metadata = new Dictionary<string, string>()
                        {
                            { "name", "Calculation Time" },
                            { "unit", "ms" },
                            { "unitType", UnitType.Time.ToString() }
                        },
                    });
            }
        }

        public static void AddCalculationTimeToResultsOutput(CalculationSettings settings)
        {
            var resultOutput = settings.TabularOutputs
                .Where(o => !o.OutputType.IsCurves());
            if (resultOutput.Any())
            {
                var output = resultOutput.First();
                SetResultOutput(output, "Calculation Time", "ms", settings.CalculationTime);
            }
        }

        private static double GetInputFromSettings(CalculationSettings settings, string type, string sourceAddress = null)
        {
            var matchingInputs = settings.Inputs.Where(i => i.Type == type);
            if (matchingInputs.Any())
            {
                var input = matchingInputs.First();
                if (sourceAddress != null)
                {
                    input.SourceAddress = sourceAddress;
                }
                if (input.Value.HasValue)
                {
                    return input.Value.GetNumerical();
                }
                else
                {
                    throw new SimulatorException($"Missing input value required for {settings.Calculation.Name}: {type}");
                }
            }
            throw new SimulatorException($"Input required for {settings.Calculation.Name} not found: {type}");
        }

        private bool SetInput(CalculationSettings settings, string type, UnitType unit, string sourceAddress)
        {
            var matchingInputs = settings.Inputs.Where(i => i.Type == type && i.UnitType == unit);
            if (matchingInputs.Any())
            {
                var input = matchingInputs.First();
                input.SourceAddress = sourceAddress;
                _api.DoSet(input.SourceAddress, input.Value.Numerical.ToString());
                return true;
            }
            return false;
        }

        private static bool SetOutput(CalculationSettings settings, string type, UnitType unitType, string sourceAddress, string unit, double value)
        {
            var matchingOutputs = settings.Outputs.Where(i => i.Type == type && i.UnitType == unitType);
            if (matchingOutputs.Any())
            {
                var output = matchingOutputs.First();
                output.SourceAddress = sourceAddress;
                output.Value = new WrappedValue () {
                    Numerical = value,
                    Unit = unit
                };
                return true;
            }
            return false;
        }

        private int? _prosperProcesses;

        /// <summary>
        /// Use the OpenServer API to open PROSPER, open the model file
        /// and set the unit system. Also stores the process id locally
        /// in case we have to remove the process later
        /// </summary>
        private void OpenModelAndSetUnits(string filePath, UnitSystem unitSystem)
        {
            var prosperProcesses = Process.GetProcessesByName("prosper").Select(p => p.Id);
            _api.DoCmd("PROSPER.START");

            // store PROSPER's process id
            var newProsperProcesses = Process.GetProcessesByName("prosper")
                .Where(p => !prosperProcesses.Contains(p.Id));
            if (newProsperProcesses.Any())
            {
                _prosperProcesses = newProsperProcesses.First().Id;
            }

            _api.DoCmd($"PROSPER.OPENFILE(\"{filePath}\")");
            _api.DoCmd(unitSystem.ToProsperUnitName());
        }
        
        /// <summary>
        /// Use OpenServer API to close PROSPER, then deactivate OpenServer to
        /// release the license. If this fails and PROSPER is still running,
        /// use the sored process id to kill it.
        /// </summary>
        private void CloseProsper()
        {
            try
            {
                _api.DoCmd("PROSPER.SHUTDOWN");
            }
            catch (OpenServerException e)
            {
                // Just ignore exceptions here and clean resources in the finally block
                _logger.LogWarning("Cannot close PROSPER: {Message}", e.Message);
            }
            finally
            {
                _api.Shutdown();

                // This is assurance that we close Prosper even when
                // OpenServer fail to do so
                if (_prosperProcesses.HasValue)
                {
                    var existingProsperProcesses = Process.GetProcessesByName("prosper")
                        .Where(p => p.Id == _prosperProcesses);
                    if (existingProsperProcesses.Any())
                    {
                        existingProsperProcesses.First().Kill(true);
                    }
                    _prosperProcesses = null;
                }
            }
        }

        private void GetCurveOutput(
            CalculationTabularOutput output, 
            string name, 
            string address, 
            UnitType unitType)
        {
            var variableStr = _api.DoGet(address);
            var variableArray = OpenServerApi.ParseArrayString(variableStr);
            AssignCurveOutputValues(output, name, address, variableArray, unitType);
        }

        private void AssignCurveOutputValues(
            CalculationTabularOutput output, 
            string name, 
            string address, 
            double?[] values,
            UnitType unitType)
        {
            var unit = _api.DoGet($"{address}.UNITNAME");
            if (output.Columns == null)
            {
                output.Columns = new Dictionary<string, SimulationResultColumn>();
            }
            output.Columns.Add(
                $"{name} [{unit}]",
                new SimulationNumericResultColumn
            {
                Rows = values.Select(v => v ?? double.NaN).ToList(),
                Metadata = new Dictionary<string, string>()
                {
                    { "name", name },
                    { "unit", unit },
                    { "unitType", unitType.ToString() },
                    { "address", address },
                }
            });
        }

        private void GetResultOutput(CalculationTabularOutput output, string name, string address, bool skipOnError = true)
        {
            try
            {
                var unit = _api.DoGet($"{address}.UNITNAME");
                var value = double.Parse(_api.DoGet(address));
                SetResultOutput(output, name, unit, value);
            }
            catch (Exception e)
            {
                _logger.LogWarning($"Could not read {name} ({address})");
                if (!skipOnError)
                {
                    throw;
                }
            }
        }

        private static void SetResultOutput(CalculationTabularOutput output, string name, string unit, double value)
        {
            if (output.Columns == null)
            {
                output.Columns = new Dictionary<string, SimulationResultColumn>();
            }
            output.AddValueToColumn("Label", name );
            output.AddValueToColumn("Value", value );
            output.AddValueToColumn("Unit", unit );
        }

        public string GetUnit(UnitSystem unitSystem, UnitType unitType)
        {
            return ProsperSimulatorExtensions.GetProsperUnit(unitSystem, unitType);
        }

        internal LiftMethod GetLiftMethod()
        {
            return GetEnumValue<LiftMethod>("PROSPER.SIN.SUM.LIFTMETHOD");
        }

        internal T GetEnumValue<T>(string address) where T : Enum
        {
            var intValue = int.Parse(_api.DoGet(address));
            try
            {
                return CommonUtils.IntToEnum<T>(intValue);
            }
            catch(ArgumentException e)
            {
                _logger.LogError("Failed to convert Open Server value: {Message}", e.Message);
                throw new SimulatorException($"Could not parse {address}");
            }
        }

        public void ResolveModelReferences(ModelFileSettings modelSettings, Action<string, string> UpdateModelFileState)
        {
            return;
        }
    }

    internal enum LiftMethod
    {
        None = 0,
        GasLiftContinuous = 1,
        ElectricSubmersiblePump = 2,
        HydraulicDriveDownholePump = 3,
        ProgressiveCavityPump = 4,
        CoilTubingGasLift = 5,
        DiluentInjection = 6,
        JetPump = 7,
        MultiphasePump = 8,
        SuckerRodPump = 9,
        GasLiftIntermittent = 10,
    }

    internal enum PvtModel
    {
        BlackOil = 0,
        EOS = 2
    }

    internal enum FlowType
    {
        Tubing = 0,
        Annular = 1,
        TubingAndAnnular = 2
    }

    internal enum WellType
    {
        Producer = 0,
        Injector = 1,
        WaterInjector = 2,
        CBMProducer = 3
    }

    internal enum TempModel
    {
        RoughApproximation = 0,
        EnthapyBalance = 1,
        ImprovedApproximation = 2
    }

    public class ProsperVar : ProsperVarBase
    {
        public double Value { get; set; }
    }
    public class ProsperList : ProsperVarBase
    {
        public List<double> Values { get; set; }
    }

    public class ProsperVarBase
    {
        public string Unit { get; set; }
        public string Address { get; set; }
    }


    public static class ProsperSimulatorExtensions
    {
        /// <summary>
        /// Returns true if the boundary condition <paramref name="bc"/> can be
        /// extracted from models of type <paramref name="modelType"/>
        /// </summary>
        public static bool HasBoundaryCondition(this ModelType modelType, BoundaryCondition bc)
        {
            return modelType switch
            {
                ModelType.GasWell => bc.Key switch
                {
                    SimulatorConstants.SeparatorGOR => false,
                    SimulatorConstants.TankGOR => false,
                    SimulatorConstants.SolutionGOR => false,
                    _ => true,
                },
                ModelType.OilWell => bc.Key switch
                {
                    SimulatorConstants.CGR => false,
                    SimulatorConstants.WGR => false,
                    _ => true,
                },
                ModelType.RetrogradeWell => bc.Key switch
                {
                    SimulatorConstants.CGR => false,
                    SimulatorConstants.SolutionGOR => false,
                    _ => true,
                },
                _ => true
            };
        }

        public static string ToProsperVariableName(this BoundaryConditionData bc)
        {
            if (!string.IsNullOrEmpty(bc.Address))
            {
                return bc.Address;
            }

            // For compatibility with connector versions <= 1.0.2
            return bc.Key switch
            {
                SimulatorConstants.ResPress => "PROSPER.SIN.IPR.Single.Pres",
                SimulatorConstants.ResTemp => "PROSPER.SIN.IPR.Single.Tres",
                SimulatorConstants.ResPerm => "PROSPER.SIN.IPR.Single.ResPerm",
                SimulatorConstants.ResThick => "PROSPER.SIN.IPR.Single.Thickness",
                SimulatorConstants.WellLen => "PROSPER.SIN.IPR.Single.WellLen",
                SimulatorConstants.Skin => "PROSPER.SIN.IPR.Single.Skin",
                SimulatorConstants.CGR => "PROSPER.PVT.Input.Cgr",
                SimulatorConstants.WGR => "PROSPER.PVT.Input.Wgr",
                SimulatorConstants.N2 => "PROSPER.PVT.Input.N2",
                SimulatorConstants.SeparatorGOR => "PROSPER.PVT.Input.Gorsep",
                SimulatorConstants.TankGOR => "PROSPER.PVT.Input.Gortnk",
                SimulatorConstants.SolutionGOR => "PROSPER.PVT.Input.Solgor",
                _ => throw new ArgumentException($"Boundary Condition {bc} is not valid for PROSPER", nameof(bc)),
            };
        }

        public static string ToProsperUnitName(this UnitSystem us)
        {
            return us switch
            {
                UnitSystem.OilField => "PROSPER.MENU.UNITS.OILFIELD",
                UnitSystem.NorSI => "PROSPER.MENU.UNITS.NORSI",
                UnitSystem.CanSI => "PROSPER.MENU.UNITS.CANSI",
                UnitSystem.GerSI => "PROSPER.MENU.UNITS.GERSI",
                UnitSystem.FreSI => "PROSPER.MENU.UNITS.FRESI",
                UnitSystem.LatSI => "PROSPER.MENU.UNITS.LATSI",
                _ => throw new ArgumentException($"Unit system {us} is not valid for PROSPER", nameof(us)),
            };
        }

        public static string GetProsperUnit(UnitSystem unitSystem, UnitType unitType)
        {
            return unitSystem switch
            {
                UnitSystem.OilField => unitType switch
                {
                    UnitType.Pressure => "psig",
                    UnitType.Temperature => "deg F",
                    UnitType.GasRate => "MMscf/day",
                    UnitType.LiqRate => "STB/day",
                    UnitType.LiqRateGasRate => "STB/MMscf",
                    UnitType.Diameter => "inches",
                    UnitType.Length => "feet",
                    UnitType.Percentage => "percent",
                    UnitType.GasRateLiqRate => "scf/STB",
                    _ => throw new ArgumentException("Invalid Unit type"),
                },
                UnitSystem.NorSI => unitType switch
                {
                    UnitType.Pressure => "BARa",
                    UnitType.Temperature => "deg C",
                    UnitType.GasRate => "1000Sm3/d",
                    UnitType.LiqRate => "Sm3/day",
                    UnitType.LiqRateGasRate => "Sm3/Sm3",
                    UnitType.Diameter => "m",
                    UnitType.Length => "m",
                    UnitType.Percentage => "percent",
                    UnitType.GasRateLiqRate => "Sm3/Sm3",
                    _ => throw new ArgumentException("Invalid Unit type"),
                },
                UnitSystem.CanSI => unitType switch
                {
                    UnitType.Pressure => "KPa a",
                    UnitType.Temperature => "deg C",
                    UnitType.GasRate => "1000m3/d",
                    UnitType.LiqRate => "m3/day",
                    UnitType.LiqRateGasRate => "m3/m3",
                    UnitType.Diameter => "m",
                    UnitType.Length => "m",
                    UnitType.Percentage => "percent",
                    UnitType.GasRateLiqRate => "m3/m3",
                    _ => throw new ArgumentException("Invalid Unit type"),
                },
                UnitSystem.GerSI => unitType switch
                {
                    UnitType.Pressure => "BARa",
                    UnitType.Temperature => "deg C",
                    UnitType.GasRate => "m3[Vn]/h",
                    UnitType.LiqRate => "m3/hour",
                    UnitType.LiqRateGasRate => "m3/m3Vn",
                    UnitType.Diameter => "m",
                    UnitType.Length => "m",
                    UnitType.Percentage => "percent",
                    UnitType.GasRateLiqRate => "m3Vn/m3",
                    _ => throw new ArgumentException("Invalid Unit type"),
                },
                UnitSystem.FreSI => unitType switch
                {
                    UnitType.Pressure => "BARa",
                    UnitType.Temperature => "deg C",
                    UnitType.GasRate => "1000m3/d",
                    UnitType.LiqRate => "Sm3/day",
                    UnitType.LiqRateGasRate => "m3/m3",
                    UnitType.Diameter => "m",
                    UnitType.Length => "m",
                    UnitType.Percentage => "percent",
                    UnitType.GasRateLiqRate => "m3/m3",
                    _ => throw new ArgumentException("Invalid Unit type"),
                },
                UnitSystem.LatSI => unitType switch
                {
                    UnitType.Pressure => "Kg/cm2 g",
                    UnitType.Temperature => "deg C",
                    UnitType.GasRate => "1000m3/d",
                    UnitType.LiqRate => "Sm3/day",
                    UnitType.LiqRateGasRate => "m3/m3",
                    UnitType.Diameter => "m",
                    UnitType.Length => "m",
                    UnitType.Percentage => "percent",
                    UnitType.GasRateLiqRate => "m3/m3",
                    _ => throw new ArgumentException("Invalid Unit type"),
                },
                _ => throw new ArgumentException("Invalid Unit system")
            };
        }

        public static (double, double) GetRateMultipliers(CalculationSettings settings)
        {
            // multipliers to account for different units when computing rates using CGR/GOR/WGR
            double orMultiplier = 0;
            double grMultiplier = 0;
            switch (settings.UnitSystem)
            {
                case UnitSystem.OilField:
                    orMultiplier = 1e6;
                    grMultiplier = 1;
                    break;
                        
                case UnitSystem.NorSI or UnitSystem.CanSI or UnitSystem.FreSI or UnitSystem.LatSI:
                    orMultiplier = 1e3;
                    grMultiplier = 1e-3;
                    break;
                        
                case UnitSystem.GerSI:
                    orMultiplier = 1;
                    grMultiplier = 1;
                    break;
            }
            return (orMultiplier, grMultiplier);
        }

        public static string GetRateName(this ModelType modelType)
        {
            return modelType switch
            {
                ModelType.GasWell or ModelType.RetrogradeWell => "Gas Rate",
                ModelType.OilWell => "Oil Rate",
                _ => throw new SimulatorException("Unknown fluid type"),
            };
        }
     }
}

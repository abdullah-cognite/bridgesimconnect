using System;
using System.Diagnostics;
using Cognite.Simulator.Utils;
using Cognite.Simulator.Utils.Automation;
using Microsoft.Extensions.Logging;
using SimulatorCommon;

namespace OpenServer;

public class MbalSimulator : ISimulator
{
    public string Id => SimulatorType.MBAL.ToString();

    private readonly OpenServerApi _api;
    private readonly OpenServerConfig _config;
    private readonly ILogger<MbalSimulator> _logger;

    private string _version;

    public MbalSimulator(
        OpenServerApi api, 
        OpenServerConfig config, 
        ILogger<MbalSimulator> logger)
    {
        _api = api;
        _config = config;
        _logger = logger;
    }

    public void ExtractModelInformation(ModelFileSettings modelFileSettings)
    {
        modelFileSettings.ModelParsingLog.AddInfo("Parsing model file in MBAL");
        // TODO: Try to open model and extract information
    }

    public string GetUnit(UnitSystem unitSystem, UnitType unitType)
    {
        throw new System.NotImplementedException();
    }

    public string GetVersion()
    {
        if (_version == null)
        {
            _logger.LogError("Could not obtain MBAL version");
            return "N/A";
        }
        return _version;
    }

    public void ResolveModelReferences(ModelFileSettings modelSettings, Action<string, string> UpdateModelFileState)
    {
        // Nothing to do here;
    }

    public void RunCalculation(string calcType, CalculationSettings settings)
    {
        throw new System.NotImplementedException();
    }

    public void TestConnection()
    {
        _logger.LogInformation("Testing MBAL connection...");

        lock (_api.SimulatorLock)
        {
            try
            {
                _api.Initialize();
                _api.DoCmd("MBAL.START()");
                var serverProcess = Process.GetProcessesByName("mbal");
                var versionInfo = serverProcess[0].MainModule.FileVersionInfo;
                _version = versionInfo.FileVersion;
                _api.DoCmd("MBAL.SHUTDOWN()");
                _api.Shutdown();
            }
            catch (OpenServerException oe) when (oe.CanRetry == true)
            {
                _logger.LogWarning("Cannot open MBAL, but possible to retry: {Error}", oe.Message);
            }
            catch (Exception e)
            {
                throw new SimulatorConnectionException($"{Id} is not available: {e.Message}", e);
            }
        }

        _logger.LogInformation("MBAL instance created and removed successfully");
    }
}
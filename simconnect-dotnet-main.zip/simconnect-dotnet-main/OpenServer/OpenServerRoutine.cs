﻿using Cognite.Simulator.Utils;
using SimulatorCommon;
using SimulatorCommon.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;

namespace OpenServer
{
    public class OpenServerRoutine : RoutineImplementationBase
    {
        protected readonly OpenServerApi _api;
        private readonly SimulatorType _type;
        private CalculationSettings _settings;
        private List<string> _addressesNotSupported;

        public OpenServerRoutine(
            CalculationSettings settings,
            Dictionary<string, double> inputData,
            OpenServerApi api,
            List<string> addressesNotSupported,
            SimulatorType type) : base(settings.Routine, inputData)
        {
            _api = api;
            _type = type;
            _settings = settings;
            _addressesNotSupported = addressesNotSupported;
            
            //TODO: fix in Utils: Command does not need to have a type
            foreach (var procedure in settings.Routine.Routine)
            {
                foreach (var step in procedure.Steps)
                {
                    if (step.Type == "Command")
                    {
                        step.Arguments["type"] = "command";
                    }
                }
            }
        }

        public override void SetTimeSeriesInput(InputTimeSeriesConfiguration inputConfig, double value, Dictionary<string, string> arguments)
        {
            string address = GetAddress(arguments);
            SetInput(_settings, inputConfig.Type, address);
        }

        public override void SetManualInput(string value, Dictionary<string, string> arguments)
        {
            string address = GetAddress(arguments);
            _api.DoSet(address, value);
        }

        public override double GetTimeSeriesOutput(OutputTimeSeriesConfiguration outputConfig, Dictionary<string, string> arguments)
        {
            string address = GetAddress(arguments);
            return SetOutput(_settings, outputConfig.Type, address);
        }

        public override void RunCommand(string command, Dictionary<string, string> arguments)
        {
            string address = GetAddress(arguments);
            _api.DoCmd(address);
        }

        private string GetAddress(Dictionary<string, string> arguments)
        {
            if (!arguments.TryGetValue("address", out string address))
            {
                throw new SimulatorException($"Routine error: Address not defined");
            }
            if (!ValidateAddress(address))
            {
                throw new SimulatorException($"Routine error: Invalid address: {address}");
            }

            return address;
        }

        private bool ValidateAddress(string address)
        {
            var addressComponents = address.ToLower().Split('.').ToList();
            if (addressComponents.Count <= 1)
            {
                return false;
            }
            if (addressComponents[0] != _type.ToString().ToLower())
            {
                return false;
            }
            bool isInvalid = _addressesNotSupported.Any(a => addressComponents[1].Contains(a));
            if (isInvalid)
            {
                return false;
            }
            return true;
        }

        protected void SetInput(CalculationSettings settings, string type, string sourceAddress)
        {
            var matchingInputs = settings.Inputs.Where(i => i.Type == type);
            if (matchingInputs.Any())
            {
                var input = matchingInputs.First();
                input.SourceAddress = sourceAddress;
                _api.DoSet(input.SourceAddress, input.Value.Numerical.ToString());
                return;
            }
            throw new SimulatorException($"Set error: Output definition not found: {type}");
        }

        protected double SetOutput(CalculationSettings settings, string type, string sourceAddress)
        {
            var matchingOutputs = settings.Outputs.Where(i => i.Type.ToString() == type);
            if (matchingOutputs.Any())
            {
                var output = matchingOutputs.First();
                var value = _api.DoGet(sourceAddress);
                output.SourceAddress = sourceAddress;
                output.Value = new WrappedValue () {
                    Numerical = double.Parse(value),
                    Unit = _api.DoGet($"{sourceAddress}.UNITNAME")
                };
                return output.Value.GetNumerical();
            }
            throw new SimulatorException($"Get error: Output definition not found: {type}");
        }

        internal void UserDefinedCalculation(CalculationSettings _)
        {
            PerformSimulation();
        }
    }
}

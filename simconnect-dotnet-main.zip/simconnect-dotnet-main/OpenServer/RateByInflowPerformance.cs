﻿using MathNet.Numerics;
using Microsoft.Extensions.Logging;
using SimulatorCommon;
using System;
using System.Linq;

namespace OpenServer
{
    partial class ProsperSimulator
    {
        private (ProsperVar GasRate, ProsperVar OilRate, ProsperVar WaterRate, ProsperVar LiquidRate) FindRatesIpr(CalculationSettings settings, double BHP)
        {
            // Reset sensitivities database
            _api.DoSet("PROSPER.ANL.SYS.Sens.SensDB.Clear", "1");

            // Set inputs
            bool allSet = true;
            switch (settings.ModelType)
            {
                case ModelType.GasWell:
                    allSet &= SetInput(settings, SimulationInputConstants.CGR, UnitType.LiqRateGasRate, "PROSPER.ANL.INF.CGR");
                    allSet &= SetInput(settings, SimulationInputConstants.WGR, UnitType.LiqRateGasRate, "PROSPER.ANL.INF.WGR");
                    break;
                
                case ModelType.RetrogradeWell:
                    allSet &= SetInput(settings, SimulationInputConstants.GOR, UnitType.GasRateLiqRate, "PROSPER.ANL.INF.SGR");
                    allSet &= SetInput(settings, SimulationInputConstants.WGR, UnitType.LiqRateGasRate, "PROSPER.ANL.INF.WGR");
                    break;
                
                case ModelType.OilWell:
                    allSet &= SetInput(settings, SimulationInputConstants.GOR, UnitType.GasRateLiqRate, "PROSPER.ANL.INF.GOR");
                    allSet &= SetInput(settings, SimulationInputConstants.WC, UnitType.Percentage, "PROSPER.ANL.INF.WC");
                    break;
                
                case ModelType.Unknown:
                    throw new SimulatorException("Unknown fluid type");
            }
            if (!allSet)
            {
                throw new SimulatorException("Missing required input for calculation");
            }

            var gasRate = new ProsperVar { Address = "PROSPER.OUT.INF.Results[0].GasRate[$]" };
            var oilRate = new ProsperVar { Address = "PROSPER.OUT.INF.Results[0].OilRate[$]" };
            var waterRate = new ProsperVar { Address = "PROSPER.OUT.INF.Results[0].WatRate[$]" };
            var liquidRate = new ProsperVar { Address = "PROSPER.OUT.INF.Results[0].LiqRate[$]" };

            // Trigger IPR calculation
            _api.DoCmd("PROSPER.ANL.INF.CALC");

            var pressuresString = _api.DoGet("PROSPER.OUT.INF.Results[0].IPRpres[$]");
            var pressures = OpenServerApi.TryParseArrayString(pressuresString);

            // check if BHP is in the IPR range
            if ((BHP < pressures.Min()) || (BHP > pressures.Max()))
            {
                throw new SimulatorException("BHP is outside of the IPR range from PROSPER");
            }

            var gasRatesString = _api.DoGet(gasRate.Address);
            gasRate.Unit = _api.DoGet($"{gasRate.Address}.UNITNAME");
            var gasRates = OpenServerApi.TryParseArrayString(gasRatesString);

            var oilRatesString = _api.DoGet(oilRate.Address);
            oilRate.Unit = _api.DoGet($"{oilRate.Address}.UNITNAME");
            var oilRates = OpenServerApi.TryParseArrayString(oilRatesString);

            var waterRatesString = _api.DoGet(waterRate.Address);
            waterRate.Unit = _api.DoGet($"{waterRate.Address}.UNITNAME");
            var waterRates = OpenServerApi.TryParseArrayString(waterRatesString);

            var liquidRatesString = _api.DoGet(liquidRate.Address);
            liquidRate.Unit = _api.DoGet($"{liquidRate.Address}.UNITNAME");
            var liquidRates = OpenServerApi.TryParseArrayString(liquidRatesString);

            try
            {
                var fgas = Interpolate.Linear(pressures, gasRates);
                var foil = Interpolate.Linear(pressures, oilRates);
                var fwat = Interpolate.Linear(pressures, waterRates);
                var fliq = Interpolate.Linear(pressures, liquidRates);

                gasRate.Value = fgas.Interpolate(BHP);
                oilRate.Value = foil.Interpolate(BHP);
                waterRate.Value = fwat.Interpolate(BHP);
                liquidRate.Value = fliq.Interpolate(BHP);
                return (gasRate, oilRate, waterRate, liquidRate);
            }
            catch (Exception e)
            {
                _logger.LogError("No solution found: {Message}", e.Message);
                throw new SimulatorException($"No solution was found for the Inflow Performance rate calculation: {e.Message}");
            }
        }

        private void RateByInflowPerformance(CalculationSettings settings)
        {
            // evaluate if the BHP is available or needs to be estimated
            ProsperVar BHP = EstimateBhpInternal(settings).Bhp;
            bool estimateBhp = settings.EstimateBHP.Enabled;

            // Calculate gas rate
            var (GasRate, OilRate, WaterRate, LiquidRate) = FindRatesIpr(
                settings, BHP.Value);

            // Extract output time series
            SetOutput(settings, SimulationOutputConstants.GasRate, UnitType.GasRate, GasRate.Address, GasRate.Unit, GasRate.Value);
            SetOutput(settings, SimulationOutputConstants.OilRate, UnitType.LiqRate, OilRate.Address, OilRate.Unit, OilRate.Value);
            SetOutput(settings, SimulationOutputConstants.WatRate, UnitType.LiqRate, WaterRate.Address, WaterRate.Unit, WaterRate.Value);
            SetOutput(settings, SimulationOutputConstants.LiqRate, UnitType.LiqRate, LiquidRate.Address, LiquidRate.Unit, LiquidRate.Value);
            // if the BHP is estimated we save it as an output as well
            if (estimateBhp)
            {
                SetOutput(settings, SimulationOutputConstants.BHP, UnitType.Pressure, BHP.Address, BHP.Unit, BHP.Value);
            }

            // Extract result outputs
            var resultsOutput = settings.TabularOutputs
                .Where(o => o.OutputType == CalculationTabularOutputType.InflowPerformanceResults);
            if (resultsOutput.Any())
            {
                var output = resultsOutput.First();
                SetResultOutput(output, "Gas Rate", GasRate.Unit, GasRate.Value);
                SetResultOutput(output, "Oil Rate", OilRate.Unit, OilRate.Value);
                SetResultOutput(output, "Water Rate", WaterRate.Unit, WaterRate.Value);
                SetResultOutput(output, "Liquid Rate", LiquidRate.Unit, LiquidRate.Value);
                if (estimateBhp)
                {
                    SetResultOutput(output, "Bottom Hole Pressure", BHP.Unit, BHP.Value);
                }
            }

            // Extract curve outputs
            var curvesOutput = settings.TabularOutputs
                .Where(o => o.OutputType == CalculationTabularOutputType.InflowPerformanceCurves);
            if (curvesOutput.Any())
            {
                var output = curvesOutput.First();
                GetCurveOutput(output, "Gas Rate", GasRate.Address, UnitType.GasRate);
                GetCurveOutput(output, "Oil Rate", OilRate.Address, UnitType.LiqRate);
                GetCurveOutput(output, "Water Rate", WaterRate.Address, UnitType.LiqRate);
                GetCurveOutput(output, "Liquid Rate", LiquidRate.Address, UnitType.LiqRate);
                GetCurveOutput(output, "IPR Pressure", "PROSPER.OUT.INF.Results[0].IPRpres[$]", UnitType.Pressure);
                GetCurveOutput(output, "IPR Temperature", "PROSPER.OUT.INF.Results[0].IPRtemp[$]", UnitType.Temperature);
            }
        }
    }
}

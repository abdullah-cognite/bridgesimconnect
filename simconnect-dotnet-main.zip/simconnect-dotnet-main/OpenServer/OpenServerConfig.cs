using Cognite.Simulator.Utils.Automation;
using System.Collections.Generic;

namespace OpenServer
{
    public class OpenServerConfig : AutomationConfig
    {
        /// <summary>
        /// If any calculation failed because of unavailable licenses,
        /// retry the calculation this many times
        /// </summary>
        public int NumRetries { get; set; } = 3;

        /// <summary>
        /// Delay between consecutive tries (in seconds)
        /// </summary>
        public int RetryDelay { get; set; } = 30;

        public List<string> BlacklistAddresses { get; set; } = new List<string>()
        {
            "start",
            "shutdown",
            "openfile",
            "savefile",
            "newfile",
            "setunitsys"
        };

        public void GenerateDefaults()
        {
            ProgramId = "PX32.OpenServer.1";
            ProcessId = "pxserver";
            TerminateProcess = true;
        }
    }
}

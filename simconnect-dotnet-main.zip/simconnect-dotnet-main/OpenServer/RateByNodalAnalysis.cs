﻿using Microsoft.Extensions.Logging;
using SimulatorCommon;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OpenServer
{
    partial class ProsperSimulator
    {
        private void RateByNodalAnalysis(CalculationSettings settings)
        {

            // set rate method to Automatic - Geometric (2)
            // forces PROSPER to automatically generate a list of rates
            _api.DoSet("PROSPER.ANL.SYS.RateMethod", (2).ToString());

            // set inputs
            bool allSet = SetInput(settings, SimulationInputConstants.THP, UnitType.Pressure, "PROSPER.ANL.SYS.Pres");
            switch (settings.ModelType)
            {
                case ModelType.GasWell:
                    allSet &= SetInput(settings, SimulationInputConstants.CGR, UnitType.LiqRateGasRate, "PROSPER.ANL.SYS.CGR");
                    allSet &= SetInput(settings, SimulationInputConstants.WGR, UnitType.LiqRateGasRate, "PROSPER.ANL.SYS.WGR");
                    break;

                case ModelType.RetrogradeWell:
                    allSet &= SetInput(settings, SimulationInputConstants.GOR, UnitType.GasRateLiqRate, "PROSPER.ANL.SYS.SGR");
                    allSet &= SetInput(settings, SimulationInputConstants.WGR, UnitType.LiqRateGasRate, "PROSPER.ANL.SYS.WGR");
                    break;

                case ModelType.OilWell:
                    allSet &= SetInput(settings, SimulationInputConstants.GOR, UnitType.GasRateLiqRate, "PROSPER.ANL.SYS.GOR");
                    allSet &= SetInput(settings, SimulationInputConstants.WC, UnitType.Percentage, "PROSPER.ANL.SYS.WC");
                    var liftMethod = GetLiftMethod();
                    if (liftMethod == LiftMethod.GasLiftContinuous)
                    {
                        // If method is Gas Lift (Continuous), then set the injected gas rate input
                        _api.DoSet("PROSPER.SIN.GLF.Entry", "1"); //0: Use GLR injected, 1: Use injected gas rate
                        allSet &= SetInput(
                            settings, SimulationInputConstants.GasLiftRate, UnitType.GasRate,
                            "PROSPER.SIN.GLF.GLRate");
                    }
                    break;

                case ModelType.Unknown:
                    throw new SimulatorException("Unknown fluid type");
            }

            if (!allSet)
            {
                throw new SimulatorException("Missing required input for calculation");
            }

            _api.DoSet("PROSPER.ANL.SYS.Sens.SensDB.Clear", (1).ToString());

            // run analysis calculation
            _api.DoCmd("PROSPER.ANL.SYS.CALC");

            // read outputs
            var noSolution = true;
            foreach (var output in settings.Outputs)
            {
                if (output.Type == SimulationOutputConstants.GasRate && output.UnitType == UnitType.GasRate)
                {
                    output.SourceAddress = "PROSPER.OUT.SYS.Results[0].Sol.GasRate";
                }
                else if (output.Type == SimulationOutputConstants.OilRate && output.UnitType == UnitType.LiqRate)
                {
                    output.SourceAddress = "PROSPER.OUT.SYS.Results[0].Sol.OilRate";
                }
                else if (output.Type == SimulationOutputConstants.WatRate && output.UnitType == UnitType.LiqRate)
                {
                    output.SourceAddress = "PROSPER.OUT.SYS.Results[0].Sol.WatRate";
                }
                else if (output.Type == SimulationOutputConstants.LiqRate && output.UnitType == UnitType.LiqRate)
                {
                    output.SourceAddress = "PROSPER.OUT.SYS.Results[0].Sol.LiqRate";
                }
                else if (output.Type == SimulationOutputConstants.BHP && output.UnitType == UnitType.Pressure)
                {
                    output.SourceAddress = "PROSPER.OUT.SYS.Results[0].Sol.BHP";
                }
                else
                {
                    continue; //skip anything else
                }
                var valueFromSimulator = _api.DoGet(output.SourceAddress);
                output.Value = new WrappedValue () {
                    Unit = _api.DoGet($"{output.SourceAddress}.UNITNAME"),
                    Numerical = double.Parse(valueFromSimulator)
                };
                if (output.Value.Numerical != 0.0d)
                {
                    noSolution = false;
                }
            }

            // Throw error if no solution was found (all output values are zero)
            if (noSolution)
            {
                // Do not save output time series if no solution was found
                foreach (var output in settings.Outputs)
                {
                    output.Value = null;
                }

                AddSystemCurvesToOutput(settings);
                AddCalculationTimeToCurveOutput(settings);

                throw new SimulatorException("No solution was found for the Nodal Analysis");
            }

            AddSystemCurvesToOutput(settings);

            var resultsOutput = settings.TabularOutputs
                .Where(o => o.OutputType == CalculationTabularOutputType.SystemResults);
            if (resultsOutput.Any())
            {
                var output = resultsOutput.First();
                GetResultOutput(output, "Gas Rate", "PROSPER.OUT.SYS.Results[0].Sol.GasRate");
                GetResultOutput(output, "Oil Rate", "PROSPER.OUT.SYS.Results[0].Sol.OilRate");
                GetResultOutput(output, "Water Rate", "PROSPER.OUT.SYS.Results[0].Sol.WatRate");
                GetResultOutput(output, "Liquid Rate", "PROSPER.OUT.SYS.Results[0].Sol.LiqRate");
                GetResultOutput(output, "Solution Node Pressure", "PROSPER.OUT.SYS.Results[0].Sol.BHP");
                GetResultOutput(output, "dP Friction", "PROSPER.OUT.SYS.Results[0].Sol.PRFRIC");
                GetResultOutput(output, "dP Gravity", "PROSPER.OUT.SYS.Results[0].Sol.PRSTAT");
                GetResultOutput(output, "dP Total Skin", "PROSPER.OUT.SYS.Results[0].Sol.dPTotalSkin");
                GetResultOutput(output, "dP Perforation", "PROSPER.OUT.SYS.Results[0].Sol.dPPerforation");
                GetResultOutput(output, "dP Damage", "PROSPER.OUT.SYS.Results[0].Sol.dPDamage");
                GetResultOutput(output, "dP Completion", "PROSPER.OUT.SYS.Results[0].Sol.dPCompletion");
                GetResultOutput(output, "Completion Skin", "PROSPER.OUT.SYS.Results[0].Sol.CompletionSkin");
                GetResultOutput(output, "Total Skin", "PROSPER.OUT.SYS.Results[0].Sol.TotalSkin");
                GetResultOutput(output, "Wellhead Liquid Density", "PROSPER.OUT.SYS.Results[0].Sol.WHDenLiquid");
                GetResultOutput(output, "Wellhead Gas Density", "PROSPER.OUT.SYS.Results[0].Sol.WHDenGas");
                GetResultOutput(output, "Wellhead Liquid Viscosity", "PROSPER.OUT.SYS.Results[0].Sol.WHVisLiquid");
                GetResultOutput(output, "Wellhead Gas Viscosity", "PROSPER.OUT.SYS.Results[0].Sol.WHVisGas");
                GetResultOutput(output, "Wellhead Superficial Liquid Velocity", "PROSPER.OUT.SYS.Results[0].Sol.WHVelLiquid");
                GetResultOutput(output, "Wellhead Superficial Gas Velocity", "PROSPER.OUT.SYS.Results[0].Sol.WHVelGas");
                GetResultOutput(output, "Wellhead Z Factor", "PROSPER.OUT.SYS.Results[0].Sol.WHZFactor");
                GetResultOutput(output, "Wellhead Interfacial Tension", "PROSPER.OUT.SYS.Results[0].Sol.WHSurfaceTension");
                GetResultOutput(output, "Wellhead Pressure", "PROSPER.OUT.SYS.Results[0].Sol.WHPressure");
                GetResultOutput(output, "Wellhead Temperature", "PROSPER.OUT.SYS.Results[0].Sol.WHTemperature");
                GetResultOutput(output, "First Node Liquid Density", "PROSPER.OUT.SYS.Results[0].Sol.FNDenLiquid");
                GetResultOutput(output, "First Node Gas Density", "PROSPER.OUT.SYS.Results[0].Sol.FNDenGas");
                GetResultOutput(output, "First Node Liquid Viscosity", "PROSPER.OUT.SYS.Results[0].Sol.FNVisLiquid");
                GetResultOutput(output, "First Node Gas Viscosity", "PROSPER.OUT.SYS.Results[0].Sol.FNVisGas");
                GetResultOutput(output, "First Node Superficial Liquid Velocity", "PROSPER.OUT.SYS.Results[0].Sol.FNVelLiquid");
                GetResultOutput(output, "First Node Superficial Gas Velocity", "PROSPER.OUT.SYS.Results[0].Sol.FNVelGas");
                GetResultOutput(output, "First Node Z Factor", "PROSPER.OUT.SYS.Results[0].Sol.FNZFactor");
                GetResultOutput(output, "First Node Interfacial Tension", "PROSPER.OUT.SYS.Results[0].Sol.FNSurfaceTension");
                GetResultOutput(output, "First Node Pressure", "PROSPER.OUT.SYS.Results[0].Sol.FNPressure");
                GetResultOutput(output, "First Node Temperature", "PROSPER.OUT.SYS.Results[0].Sol.FNTemperature");
            }
        }

        private void AddSystemCurvesToOutput(CalculationSettings settings)
        {
            var curvesOutput = settings.TabularOutputs
                .Where(o => o.OutputType == CalculationTabularOutputType.SystemCurves);
            if (curvesOutput.Any())
            {
                var output = curvesOutput.First();
                GetCurveOutput(output, "Gas Rate", "PROSPER.OUT.SYS.Results[0].GasRate[$]", UnitType.GasRate);
                GetCurveOutput(output, "Oil Rate", "PROSPER.OUT.SYS.Results[0].OilRate[$]", UnitType.LiqRate);
                GetCurveOutput(output, "Water Rate", "PROSPER.OUT.SYS.Results[0].WatRate[$]", UnitType.LiqRate);
                GetCurveOutput(output, "Liquid Rate", "PROSPER.OUT.SYS.Results[0].LiqRate[$]", UnitType.LiqRate);
                GetCurveOutput(output, "VLP Pressure", "PROSPER.OUT.SYS.Results[0].VLPpres[$]", UnitType.Pressure);
                GetCurveOutput(output, "IPR Pressure", "PROSPER.OUT.SYS.Results[0].IPRpres[$]", UnitType.Pressure);
            }
        }
    }
}

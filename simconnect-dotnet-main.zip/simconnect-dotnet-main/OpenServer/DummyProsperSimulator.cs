﻿using Cognite.Simulator.Extensions;
using Microsoft.Extensions.Logging;
using SimulatorCommon;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OpenServer
{
    public class DummyProsperSimulator : ISimulator
    {
        private readonly ILogger<DummyProsperSimulator> _logger;

        public string Id => SimulatorType.PROSPER.ToString();
        private readonly Dictionary<string, string> BcUnits = new()
        {
                { SimulatorConstants.CGR, "STB/MMscf" },
                { SimulatorConstants.N2, "percent" },
                { SimulatorConstants.ResPerm, "md" },
                { SimulatorConstants.ResPress, "psig" },
                { SimulatorConstants.ResTemp, "deg F" },
                { SimulatorConstants.ResThick, "feet" },
                { SimulatorConstants.Skin, "" },
                { SimulatorConstants.WellLen, "feet" },
                { SimulatorConstants.WGR, "STB/MMscf" },
                { SimulatorConstants.SeparatorGOR, "scf/STB" },
                { SimulatorConstants.TankGOR, "scf/STB" },
                { SimulatorConstants.SolutionGOR, "scf/STB" }
        };

        public DummyProsperSimulator(ILogger<DummyProsperSimulator> logger)
        {
            _logger = logger;
        }

        public void ExtractModelInformation(
            ModelFileSettings modelFileSettings)
        {
            var rand = new Random();
            var s = TimeSpan.FromSeconds(rand.Next(3, 10)); // Will take up to 10 secs
            Task.Delay(s).Wait();

            if (modelFileSettings.RemoteFileName.ToLower().Contains("invalid"))
            {
                throw new SimulatorException("Failed to get boundary conditions from PROSPER")
                {
                    CanRetry = false,
                    SimulatorMessage = "Cannot open model file: Invalid format"
                };
            }
            if (modelFileSettings.RemoteFileName.ToLower().Contains("oilwell"))
            {
                modelFileSettings.ModelType = ModelType.OilWell;
            }
            else if (modelFileSettings.RemoteFileName.ToLower().Contains("gaswell"))
            {
                modelFileSettings.ModelType = ModelType.GasWell;
            }
            else if (modelFileSettings.RemoteFileName.ToLower().Contains("retrogradewell"))
            {
                modelFileSettings.ModelType = ModelType.RetrogradeWell;
            }

            // Extra metadata
            modelFileSettings.Metadata.Add(
                "Lift Method",
                CommonUtils.IntToEnum<LiftMethod>(rand.Next(2)).EnumToText());
            modelFileSettings.Metadata.Add(
                "Temperature Model",
                CommonUtils.IntToEnum<TempModel>(rand.Next(2)).EnumToText());
            modelFileSettings.Metadata.Add(
                "PVT Method",
                PvtModel.BlackOil.EnumToText());
            modelFileSettings.Metadata.Add(
                "Flow Type",
                CommonUtils.IntToEnum<FlowType>(rand.Next(2)).EnumToText());
            modelFileSettings.Metadata.Add(
                "Well Type",
                CommonUtils.IntToEnum<WellType>(rand.Next(3)).EnumToText());

            foreach (var bc in modelFileSettings.BoundaryConditions)
            {
                if (!modelFileSettings.ModelType.HasBoundaryCondition(bc))
                {
                    continue;
                }
                bc.Value = rand.NextDouble() * 1000;
                bc.Unit = BcUnits.ContainsKey(bc.Key) ? BcUnits[bc.Key] : "N/A";
                bc.Extracted = true;
            }
        }

        public string GetUnit(UnitSystem unitSystem, UnitType unitType)
        {
            return ProsperSimulatorExtensions.GetProsperUnit(unitSystem, unitType);
        }

        public void RunCalculation(string calcType, CalculationSettings settings)
        {
            if (calcType != "IPR/VLP" && 
                calcType != "VLP" &&
                calcType != "ChokeDp" &&
                calcType != "IPR" &&
                calcType != "BhpFromRate" &&
                calcType != "UserDefined")
            {
                throw new SimulatorException($"Calculation type {calcType} is not supported");
            }
            var rand = new Random();

            var s = TimeSpan.FromSeconds(rand.Next(5, 120)); // Will take up to 2 min
            Task.Delay(s).Wait();
            
            var fail = rand.NextDouble() <= 0.1; // fail 10% of the time
            if (fail)
            {
                throw new SimulatorException($"Failed to run {calcType}: Bad Luck");
            }
            foreach (var input in settings.Inputs)
            {
                input.SourceAddress = $"{input.Type}.Input.DummyAddress";
            }
            foreach (var output in settings.Outputs)
            {
                output.SourceAddress = $"{output.Type}.Output.DummyAddress";
                output.Value = new WrappedValue
                {
                    Numerical = 123.4567,
                    Unit = GetUnit(settings.UnitSystem, output.UnitType)
                };
            }

            foreach (var output in settings.TabularOutputs)
            {
                if (output.Columns == null)
                {
                    output.Columns = new Dictionary<string, SimulationResultColumn>();
                }
                if (calcCurves.ContainsKey(output.OutputType))
                {
                    foreach (var key in calcCurves[output.OutputType].Keys)
                    {
                        (string unit, UnitType unitType, string address, double[] curve) = calcCurves[output.OutputType][key];
                        
                        output.Columns.Add(
                            $"{key} [{unit}]",
                            new SimulationNumericResultColumn
                            {
                                Metadata = new Dictionary<string, string>()
                                {
                                    { "name", key },
                                    { "unit", unit },
                                    { "unitType", unitType.ToString() },
                                    { "address", address },
                                },
                                Rows = curve
                            });

                    }
                    continue;
                }
                var values = new double[] { 0.0, 1.0, 2.0, 3.0, 4.0 };
                output.Columns.Add(
                    "Value1[Unit1]",
                    new SimulationNumericResultColumn
                    {
                        Metadata = new Dictionary<string, string>()
                        {
                            { "name", "Value1" },
                            { "unit", "Unit1" },
                            { "unitType", "N/A" },
                            { "address", "N/A" },
                        },
                        Rows = values
                    });
                output.Columns.Add(
                    "Value2 [Unit2]",
                    new SimulationNumericResultColumn
                    {
                        Metadata = new Dictionary<string, string>()
                        {
                            { "name", "Value2" },
                            { "unit", "Unit2" },
                            { "unitType", "N/A" },
                            { "address", "N/A" },
                        },
                        Rows = values
                    });
            }
        }

        private readonly Dictionary<CalculationTabularOutputType, Dictionary<string, (string unit, UnitType type, string address, double[] values)>> calcCurves = new()
        {
            {
                CalculationTabularOutputType.LiftCurveSolutionCurves, new Dictionary<string, (string unit, UnitType type, string address, double[] values)>() {
                    { "Gas Rate", ("MMscf/day", UnitType.GasRate, "PROSPER.ANL.WHP.Data[0].RATE", new[] { 1, 6.21, 11.42, 16.63, 21.84, 27.05, 32.26, 37.47, 42.68, 47.89, 53.10, 58.31, 63.52, 68.73, 73.94, 79.15, 84.36, 89.57, 94.78, 100 }) },
                    { "Bottom Hole Pressure", ("psig", UnitType.Pressure, "PROSPER.ANL.WHP.Data[0].BHP", new[] { 2042.89, 1265.16, 1298.13, 1371.78, 1547.07, 1692.80, 1858.71, 2116.62, 2465.91, 2648.28, 2831.87, 3016.37, 3201.52, 3387.39, 3574.03, 3761.38, 3950.15, 4140.60, 4331.92, 4524.08 }) },
                    { "Bottom Hole Pressure Gauge", ("psig", UnitType.Pressure, "PROSPER.ANL.WHP.Data[0].GPRSC[0]", new[] { 1647.57, 1156.79, 1154.98, 1175.50, 1286.63, 1360.40, 1449.65, 1567.55, 1660.70, 1747.57, 1836.12, 1926.01, 2016.99, 2108.83, 2201.39, 2294.53, 2388.13, 2482.13, 2576.46, 2671.06 }) }
                }
            },
            {
                CalculationTabularOutputType.ChokeDpCurves, new Dictionary<string, (string unit, UnitType type, string address, double[] values)>() {
                    { "Gas Rate", ("MMscf/day", UnitType.GasRate, "PROSPER.ANL.CHK.DATA[6]", new[] { 156.62, 156.62, 156.62, 156.62, 156.62, 156.62, 156.62, 156.62, 156.62, 156.62, 156.62, 156.38, 154.40, 150.30, 143.78, 134.39, 121.32, 103.04, 75.64, 0.19 }) },
                    { "Outlet Pressure", ("psig", UnitType.Pressure, "PROSPER.ANL.CHK.DATA[2]", new[] { 7.89, 49.04, 90.19, 131.33, 172.48, 213.63, 254.77, 295.92, 337.07, 378.21, 419.36, 460.51, 501.65, 542.80, 583.95, 625.09, 666.24, 707.39, 748.53, 789.68 }) }
                }
            },
            {
                CalculationTabularOutputType.InflowPerformanceCurves,
                new Dictionary<string, (string unit, UnitType type, string address, double[] values)>() {
                    { "Gas Rate", ("MMscf/day", UnitType.GasRate, "PROSPER.OUT.INF.Results[0].GasRate[$]", new[] { 0.0, 2.92, 5.84, 8.76, 11.68, 14.60, 17.52, 20.44, 23.36, 26.28, 29.21, 32.13, 35.05, 37.97, 40.89, 43.81, 46.73, 49.65, 52.57, 55.49 }) },
                    { "IPR Pressure", ("psig", UnitType.Pressure, "PROSPER.OUT.INF.Results[0].IPRpres[$]", new[] { 2175.58, 2180.56, 2178.19, 2168.46, 2151.28, 2126.52, 2094, 2053.42, 2004.4, 1946.43, 1878.86, 1800.78, 1710.98, 1607.73, 1488.49, 1349.38, 1183.77, 978.67, 700.77, 29.45 }) }
                }
            }
        };

        public void TestConnection()
        {
            _logger.LogInformation("Using Dummy OpenServer connection...");
        }

        public string GetVersion()
        {
            return "1.0.0";
        }

        public void ResolveModelReferences(ModelFileSettings modelSettings, Action<string, string> UpdateModelFileState)
        {
            return;
        }
    }
}

﻿using Cognite.DataProcessing;
using MathNet.Numerics;
using SimulatorCommon;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OpenServer
{
    partial class ProsperSimulator
    {

        private void RateByChokePerformance(CalculationSettings settings)
        {
            const string outletPressureAddress = "PROSPER.ANL.CHK.DATA[2]";
            const string outletTemperatureAddress = "PROSPER.ANL.CHK.DATA[3]";

            // Make sure choke curve settings are available
            if (settings.ChokeCurve == null ||
                settings.ChokeCurve.Opening == null ||
                settings.ChokeCurve.Setting == null)
            {
                throw new SimulatorException("Choke curves configuration missing");
            }

            // Collect inputs
            // TODO: Make this into a utils function
            double cgr = 0;
            double wgr = 0;
            double gor = 0;
            double wc = 0;
            switch (settings.ModelType)
            {
                case ModelType.GasWell:
                    cgr = GetInputFromSettings(settings, SimulationInputConstants.CGR);
                    wgr = GetInputFromSettings(settings, SimulationInputConstants.WGR);
                    break;
                
                case ModelType.RetrogradeWell:
                    gor = GetInputFromSettings(settings, SimulationInputConstants.GOR);
                    wgr = GetInputFromSettings(settings, SimulationInputConstants.WGR);
                    break;
                
                case ModelType.OilWell:
                    gor = GetInputFromSettings(settings, SimulationInputConstants.GOR);
                    wc = GetInputFromSettings(settings, SimulationInputConstants.WC);
                    break;
                
                case ModelType.Unknown:
                    throw new SimulatorException("Unknown fluid type");
            }
            var thp = GetInputFromSettings(settings, SimulationInputConstants.THP);

            (double rate, string rateUnit, string rateAddress) = ChokePerformance(settings);

            // multipliers to account for different units when computing rates using CGR/GOR/WGR
            var (orMultiplier, grMultiplier) = ProsperSimulatorExtensions.GetRateMultipliers(settings);
            
            // Set time series output values
            switch (settings.ModelType)
            {
                case ModelType.GasWell:
                    SetOutput(settings, SimulationOutputConstants.GasRate, UnitType.GasRate,
                        rateAddress,
                        rateUnit,
                        rate);
                    SetOutput(settings, SimulationOutputConstants.OilRate, UnitType.LiqRate,
                        $"Value calculated from {rateAddress}",
                        GetUnit(settings.UnitSystem, UnitType.LiqRate),
                        rate * cgr * grMultiplier);
                    SetOutput(settings, SimulationOutputConstants.WatRate, UnitType.LiqRate,
                        $"Value calculated from {rateAddress}",
                        GetUnit(settings.UnitSystem, UnitType.LiqRate),
                        rate * wgr * grMultiplier);
                    SetOutput(settings, SimulationOutputConstants.LiqRate, UnitType.LiqRate,
                        $"Value calculated from {rateAddress}",
                        GetUnit(settings.UnitSystem, UnitType.LiqRate),
                        (rate * cgr * grMultiplier) + (rate * wgr * grMultiplier));
                    break;
                
                case ModelType.RetrogradeWell:
                    SetOutput(settings, SimulationOutputConstants.GasRate, UnitType.GasRate,
                        rateAddress,
                        rateUnit,
                        rate);
                    SetOutput(settings, SimulationOutputConstants.OilRate, UnitType.LiqRate,
                        $"Value calculated from {rateAddress}",
                        GetUnit(settings.UnitSystem, UnitType.LiqRate),
                        rate * orMultiplier / gor);
                    SetOutput(settings, SimulationOutputConstants.WatRate, UnitType.LiqRate,
                        $"Value calculated from {rateAddress}",
                        GetUnit(settings.UnitSystem, UnitType.LiqRate),
                        rate * wgr * grMultiplier);
                    SetOutput(settings, SimulationOutputConstants.LiqRate, UnitType.LiqRate,
                        $"Value calculated from {rateAddress}",
                        GetUnit(settings.UnitSystem, UnitType.LiqRate),
                        (rate * orMultiplier / gor) + (rate * wgr * grMultiplier));
                    break;
                
                case ModelType.OilWell:
                    SetOutput(settings, SimulationOutputConstants.LiqRate, UnitType.LiqRate,
                        rateAddress,
                        rateUnit,
                        rate);
                    SetOutput(settings, SimulationOutputConstants.OilRate, UnitType.LiqRate,
                        $"Value calculated from {rateAddress}",
                        GetUnit(settings.UnitSystem, UnitType.LiqRate),
                        rate * (100 - wc)/100);
                    SetOutput(settings, SimulationOutputConstants.WatRate, UnitType.LiqRate,
                        $"Value calculated from {rateAddress}",
                        GetUnit(settings.UnitSystem, UnitType.LiqRate),
                        rate * wc/100);
                    SetOutput(settings, SimulationOutputConstants.GasRate, UnitType.GasRate,
                        $"Value calculated from {rateAddress}",
                        GetUnit(settings.UnitSystem, UnitType.GasRate),
                        rate * gor * orMultiplier * (100 - wc)/100);
                    break;
                
                case ModelType.Unknown:
                    throw new SimulatorException("Unknown fluid type");
            }

            // Extract result outputs
            var resultsOutput = settings.TabularOutputs
                .Where(o => o.OutputType == CalculationTabularOutputType.ChokeDpResults);
            if (resultsOutput.Any())
            {
                var output = resultsOutput.First();
                string rateName = settings.ModelType.GetRateName();
                GetResultOutput(output, rateName, rateAddress);
                GetResultOutput(output, "Mass Flowrate", "PROSPER.ANL.CHK.DATA[21]");
                GetResultOutput(output, "Outlet Temperature", outletTemperatureAddress);
                GetResultOutput(output, "Critical Pressure", "PROSPER.ANL.CHK.DATA[22]");
                GetResultOutput(output, "Critical Rate", "PROSPER.ANL.CHK.DATA[23]");
                GetResultOutput(output, "Critical Temperature", "PROSPER.ANL.CHK.DATA[24]");
            }

            // Extract curve outputs
            var curvesOutput = settings.TabularOutputs
                .Where(o => o.OutputType == CalculationTabularOutputType.ChokeDpCurves);
            if (curvesOutput.Any())
            {
                var output = curvesOutput.First();
                var nPoints = 20;

                double[] outletP = Generate.LinearSpaced(nPoints, thp/100, thp);
                var outletT = new double?[outletP.Length];
                var gasRates = new double?[outletP.Length];

                for (int i = 0; i < outletP.Length; ++i)
                {
                    // Set the pressure and calculate
                    _api.DoSet(outletPressureAddress, outletP[i].ToString());
                    _api.DoCmd("PROSPER.ANL.CHK.CALC");
                    
                    // Read outlet temperature and gas rate
                    outletT[i] = double.Parse(_api.DoGet(outletTemperatureAddress));
                    gasRates[i] = double.Parse(_api.DoGet(rateAddress));
                }
                var nullableOutletP = outletP.Select(r =>
                {
                    double? value = r;
                    return value;
                }).ToArray();
                
                // Assign the output curves
                AssignCurveOutputValues(output, "Outlet Pressure", outletPressureAddress, nullableOutletP, UnitType.Pressure);
                AssignCurveOutputValues(output, "Outlet Temperature", outletTemperatureAddress, outletT, UnitType.Temperature);
                switch (settings.ModelType)
                {
                    case ModelType.GasWell or ModelType.RetrogradeWell:
                        AssignCurveOutputValues(output, "Gas Rate", rateAddress, gasRates, UnitType.GasRate);
                        break;
                    
                    case ModelType.OilWell:
                        AssignCurveOutputValues(output, "Liquid Rate", rateAddress, gasRates, UnitType.LiqRate);
                        break;
                    
                    case ModelType.Unknown:
                        throw new SimulatorException("Unknown fluid type");
                }
            }
        }

        (double rate, string rateUnit, string rateAddress) ChokePerformance(
            CalculationSettings settings)
        {
            // Get the choke position input. This is used to interpolate the choke setting and not
            // to set a PROSPER variable. therefore the sourceAddress in the input time series will not be set
            var chokePosition = GetInputFromSettings(settings, SimulationInputConstants.ChokePosition, "");
            
            // Find the choke setting based on the position and curves
            double chokeSetting = ChokeSettingInterpolation(
                chokePosition,
                settings.ChokeCurve.Opening,
                settings.ChokeCurve.Setting);

            // Set calculation configuration
            _api.DoSet("PROSPER.ANL.CHK.Method", "0"); // predict mass flowrate
            _api.DoSet("PROSPER.ANL.CHK.Choke", "4"); // ELF choke model

            // Set inputs
            bool allSet = SetInput(settings, SimulationInputConstants.THP, UnitType.Pressure, "PROSPER.ANL.CHK.DATA[0]");
            allSet &= SetInput(settings, SimulationInputConstants.THT, UnitType.Temperature, "PROSPER.ANL.CHK.DATA[1]");
            allSet &= SetInput(settings, SimulationInputConstants.FlowlinePressure, UnitType.Pressure, "PROSPER.ANL.CHK.DATA[2]");
            SetChokeSettingInput(settings, "PROSPER.ANL.CHK.DATA[4]", chokeSetting);

            switch (settings.ModelType)
            {
                case ModelType.GasWell:
                    allSet &= SetInput(settings, SimulationInputConstants.CGR, UnitType.LiqRateGasRate, "PROSPER.ANL.CHK.DATA[18]");
                    allSet &= SetInput(settings, SimulationInputConstants.WGR, UnitType.LiqRateGasRate, "PROSPER.ANL.CHK.DATA[19]");
                    break;
                
                case ModelType.RetrogradeWell:
                    allSet &= SetInput(settings, SimulationInputConstants.GOR, UnitType.GasRateLiqRate, "PROSPER.ANL.CHK.DATA[20]");
                    allSet &= SetInput(settings, SimulationInputConstants.WGR, UnitType.LiqRateGasRate, "PROSPER.ANL.CHK.DATA[19]");
                    break;
                
                case ModelType.OilWell:
                    allSet &= SetInput(settings, SimulationInputConstants.GOR, UnitType.GasRateLiqRate, "PROSPER.ANL.CHK.DATA[16]");
                    allSet &= SetInput(settings, SimulationInputConstants.WC, UnitType.Percentage, "PROSPER.ANL.CHK.DATA[17]");
                    break;
                
                case ModelType.Unknown:
                    throw new SimulatorException("Unknown fluid type");
            }
            
            if (!allSet)
            {
                throw new SimulatorException("Missing required input for calculation");
            }

            // Execute Choke Performance calculation
            _api.DoCmd("PROSPER.ANL.CHK.CALC");

            // get results
            string rateAddress = "";
            switch (settings.ModelType)
            {
                case ModelType.GasWell or ModelType.RetrogradeWell:
                    rateAddress = "PROSPER.ANL.CHK.DATA[6]";
                    break;
                
                case ModelType.OilWell:
                    rateAddress = "PROSPER.ANL.CHK.Data[5]";
                    break;
                
                case ModelType.Unknown:
                    throw new SimulatorException("Unknown fluid type");
            }
            double rate = double.Parse(_api.DoGet(rateAddress));
            string unit = _api.DoGet($"{rateAddress}.UNITNAME");
            
            return (rate, unit, rateAddress);
        }

        public static double ChokeSettingInterpolation(double opening, double[] openingArray, double[] settingArray)
        {
            var interpolator = Interpolate.Linear(points: openingArray, values: settingArray);

            // make sure that the opening is within the bounds of the opening domain
            opening = TimeSeriesUtils.Constrain(opening, openingArray.Min(), openingArray.Max());

            return interpolator.Interpolate(opening);
        }

        /// <summary>
        /// The choke setting is calculated, and not part of the calculation inputs. The value is 
        /// assigned here to the PROSPER variable and also to the list of inputs to be saved as time series
        /// </summary>
        private void SetChokeSettingInput(
            CalculationSettings settings, 
            string sourceAddress,
            double chokeSetting)
        {
            CalculationInput input = new()
            {
                Type ="ChokeSetting",
                Name = "Choke Setting",
                SourceAddress = sourceAddress,
                UnitType = UnitType.Diameter,
                Value = new WrappedValue() {
                    Numerical = chokeSetting,
                    Unit = GetUnit(settings.UnitSystem, UnitType.Diameter),
                },
                Calculation = settings.Calculation,
            };
            settings.Inputs.Add(input);
            _api.DoSet(input.SourceAddress, input.Value.Numerical.ToString());
        }

    }
}

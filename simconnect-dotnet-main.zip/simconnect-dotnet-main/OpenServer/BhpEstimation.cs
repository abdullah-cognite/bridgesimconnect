﻿using System;
using SimulatorCommon;
using System.Linq;
using MathNet.Numerics;
using SimulatorCommon.Configuration;

namespace OpenServer
{
    public partial class ProsperSimulator
    {
        private (ProsperVar Bhp, ProsperList Rates) EstimateBhpInternal(
            CalculationSettings settings,
            bool estimateRates = false)
        {
            ProsperVar bhp = new();
            ProsperList rates = new();
            switch (settings.EstimateBHP)
            {
                case {Enabled: true, Method: EstimateBhpMethod.LiftCurveRate}:
                {
                    InitializeVlpTable(settings);
                    double rate = settings.ModelType switch
                    {
                        ModelType.GasWell or ModelType.RetrogradeWell =>
                            // get the gas rate from the inputs
                            GetInputFromSettings(settings, SimulationInputConstants.GasRate),
                        ModelType.OilWell =>
                            // get the oil rate from the inputs
                            GetInputFromSettings(settings, SimulationInputConstants.OilRate),
                        _ => throw new SimulatorException("Unknown fluid type"),
                    };
                    
                    // Use the gas or oil rate to estimate the BHP
                    bhp = EstimateBhpFromRate(rate, isGauge: false);
                    break;
                }
                case {Enabled: true, Method: EstimateBhpMethod.LiftCurveGaugeBhp}:
                {
                    InitializeVlpTable(settings);
                    
                    // get the gauge BHP from the inputs
                    var bhpInput = GetInputFromSettings(
                        settings, SimulationInputConstants.BHPg, "PROSPER.ANL.WHP.Data[0].GPRSC[0]");
                    
                    // use the gauge BHP to estimate the gas rate
                    rates = EstimateRateFromPressure(settings, bhpInput, isGauge: true);
                    
                    // since we have not estimated the BHP yet, we do it now for the main gas rate
                    var mainSolution = settings.RootFindingSettings.MainSolution;
                    var rate = mainSolution == RootSolutionType.Max ?
                            rates.Values.Max() :
                            rates.Values.Min();
                
                    // use the gas rate to estimate the BHP
                    bhp = EstimateBhpFromRate(rate, isGauge: false);
                    estimateRates = false;
                    break;
                }
                case {Enabled: true, Method: EstimateBhpMethod.GradientTraverse}:
                {
                    if (estimateRates)
                    {
                        InitializeVlpTable(settings);
                    }
                    bhp = EstimateBhpFromGradientTraverse(settings);
                    break;
                }
                case {Enabled: false}:
                {
                    if (estimateRates)
                    {
                        InitializeVlpTable(settings);
                    }
                    bhp.Value = GetInputFromSettings(settings, SimulationInputConstants.BHP);
                    break;
                }
                default:
                    throw new SimulatorException("BHP estimation method not implemented");
            }
            if (estimateRates)
            {
                rates = EstimateRateFromPressure(settings, bhp.Value, isGauge: false);
            }
            return (bhp, rates);
        }
        
        private ProsperVar EstimateBhpFromGradientTraverse(CalculationSettings settings)
        {
            // read the Gauge depth from the configuration
            GaugeDepth gp = null;
            if (settings.EstimateBHP != null && settings.EstimateBHP.GaugeDepth != null)
            {
                // If the BHP estimation is part of other calculations
                gp = settings.EstimateBHP.GaugeDepth;
            }
            else if (settings.GaugeDepth != null)
            {
                // If this is a standalone BHP estimation calculation
                gp = settings.GaugeDepth;
            }
            if (gp == null)
            {
                throw new SimulatorException("Gauge depth not set");
            }
            double gaugeDepth = gp.Value;
            string gaugeDepthUnit = gp.Unit;
            string outputUnit = GetUnit(settings.UnitSystem, UnitType.Length);
            gaugeDepth = CalculationUtils.ConvertUnit(gaugeDepth, UnitType.Length, gaugeDepthUnit, outputUnit);
            
            // read the gaugeBHP from settings
            double gaugeBHP = GetInputFromSettings(settings, SimulationInputConstants.BHPg);
            
            // read the gradient traverse from PROSPER
            string measDepthString = _api.DoGet("PROSPER.OUT.GRD.Results[0][0][0].MSD[$]");
            double[] measDepth = OpenServerApi.TryParseArrayString(measDepthString);
            string pressuresStringAddress = "PROSPER.OUT.GRD.Results[0][0][0].Pres[$]";
            string pressuresString = _api.DoGet(pressuresStringAddress);
            double[] pressures = OpenServerApi.TryParseArrayString(pressuresString);
            
            // interpolate the measured depth vs pressure
            var gradient = Interpolate.Linear(measDepth, pressures);
            // calculate the gauge BHP in the original curve
            double estimatedGaugeBHP = gradient.Interpolate(gaugeDepth);
            // calculate the delta gauge BHP
            double deltaGaugeBHP = gaugeBHP - estimatedGaugeBHP;

            // estimate the BHP and return
            return new ProsperVar
            {
                Address = pressuresStringAddress,
                Unit = _api.DoGet($"{pressuresStringAddress}.UNITNAME"),
                Value = pressures.Max() + deltaGaugeBHP
            };
        }

        private void EstimateBhpStandalone(CalculationSettings settings, EstimateBhpMethod method)
        {
            if (settings.EstimateBHP == null)
            {
                settings.EstimateBHP = new EstimateBHP
                {
                    Enabled = true,
                    Method = method
                };
            }
            ProsperVar bhp = EstimateBhpInternal(settings).Bhp;

            bool outputSet = SetOutput(settings, SimulationOutputConstants.BHP, UnitType.Pressure,
                bhp.Address,
                bhp.Unit,
                bhp.Value);

            if (!outputSet)
            {
                throw new SimulatorException("Missing output configuration");
            }
        }
        
        private void BhpFromGradientTraverse(CalculationSettings settings)
        {
            EstimateBhpStandalone(settings, EstimateBhpMethod.GradientTraverse);
        }
        
        private void BhpFromRate(CalculationSettings settings)
        {
            EstimateBhpStandalone(settings, EstimateBhpMethod.LiftCurveRate);
        }
        
        private void BhpFromGaugeBhp(CalculationSettings settings)
        {
            EstimateBhpStandalone(settings, EstimateBhpMethod.LiftCurveGaugeBhp);
        }
    }
}

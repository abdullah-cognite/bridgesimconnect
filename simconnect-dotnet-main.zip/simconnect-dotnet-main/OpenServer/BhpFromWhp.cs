using System;
using System.Collections.Generic;
using SimulatorCommon;
using Cognite.DataProcessing;
using MathNet.Numerics;
using Microsoft.Extensions.Logging;

namespace OpenServer
{
    public partial class ProsperSimulator
    {
        /// <summary>
        /// Method used to initialize the table in the <b>BHP from WHP</b> section in PROSPER
        /// </summary>
        /// <param name="settings">CalculationSettings object</param>
        private void InitializeVlpTable(CalculationSettings settings)
        {
            var tempModel = int.Parse(_api.DoGet("PROSPER.SIN.SUM.TEMPMODEL"));
            if (tempModel != 0)
            {
                _logger.LogWarning("Rough Approximation temperature model required for BHP from WHP. Results may not be accurate");
            }
            
            double? rateGuess = GetRateGuess(settings);
            // check the number of entries in the table
            var n = int.Parse(_api.DoGet("PROSPER.ANL.WHP.DATA.COUNT"));

            // delete all rows
            if (n > 0)
            {
                _api.DoSet("PROSPER.ANL.WHP.DATA[$].DELETE", " ");
            }

            // configure all settings for the table
            _api.DoSet("PROSPER.ANL.WHP.FNode", "0"); // 0: Wellhead, 1: Manifold
            // TODO: if we want to support using rates as input, we need to include the GFlag option in SimConfig
            _api.DoSet("PROSPER.ANL.WHP.GFlag", "0"); // 0: Total GOR or CGR, 1: Oil Rate or Condensate Rate
            // TODO: if we want to support using rates as input, we need ti include the WFLag option in SimConfig
            _api.DoSet("PROSPER.ANL.WHP.WFlag", "0"); // 0: Water Gas Ratio or Water Cut, 1: Water Rate
            _api.DoSet("PROSPER.ANL.WHP.USEHTC", "1"); // enable to match the U value
            _api.DoSet("PROSPER.ANL.WHP.SHWGA", "0"); // disable the gauge pressure flag
            TryRefresh();

            // add data in the first row
            _api.DoSet("PROSPER.ANL.WHP.DATA[0].TIME", "1");

            // checks if the gas or oil rates are included in the inputs
            bool rateSet = settings.ModelType switch
            {
                ModelType.GasWell or ModelType.RetrogradeWell => SetInput(
                        settings, SimulationInputConstants.GasRate, UnitType.GasRate,
                        "PROSPER.ANL.WHP.DATA[0].RATE"),
                ModelType.OilWell => SetInput(
                        settings, SimulationInputConstants.OilRate, UnitType.LiqRate,
                        "PROSPER.ANL.WHP.DATA[0].RATE"),
                _ => throw new SimulatorException("Unknown fluid type"),
            };

            // otherwise sets the rate to the middle value of the root finding bracket
            if (!rateSet && rateGuess.HasValue)
            {
                _api.DoSet("PROSPER.ANL.WHP.DATA[0].RATE", rateGuess.Value.ToString());
                rateSet = true;
            }
            bool allSet = rateSet;
            allSet &= SetInput(
                settings, SimulationInputConstants.THP, UnitType.Pressure,
                "PROSPER.ANL.WHP.DATA[0].WHP");
            allSet &= SetInput(
                settings, SimulationInputConstants.THT, UnitType.Temperature,
                "PROSPER.ANL.WHP.DATA[0].WHT");
            switch (settings.ModelType)
            {
                case ModelType.GasWell:
                    allSet &= SetInput(
                        settings, SimulationInputConstants.CGR, UnitType.LiqRateGasRate,
                        "PROSPER.ANL.WHP.DATA[0].GASF");
                    break;
                case ModelType.OilWell or ModelType.RetrogradeWell:
                    allSet &= SetInput(
                        settings, SimulationInputConstants.GOR, UnitType.GasRateLiqRate,
                        "PROSPER.ANL.WHP.DATA[0].GASF");
                    break;
                case ModelType.Unknown:
                    throw new SimulatorException("Unknown fluid type");
            }
            switch (settings.ModelType)
            {
                case ModelType.GasWell or ModelType.RetrogradeWell:
                    allSet &= SetInput(
                        settings, SimulationInputConstants.WGR, UnitType.LiqRateGasRate,
                        "PROSPER.ANL.WHP.DATA[0].WATF");
                    break;
                case ModelType.OilWell:
                    allSet &= SetInput(
                        settings, SimulationInputConstants.WC, UnitType.Percentage,
                        "PROSPER.ANL.WHP.DATA[0].WATF");

                    var liftMethod = GetLiftMethod();
                    if (liftMethod == LiftMethod.GasLiftContinuous)
                    {
                        // If method is Gas Lift (Continuous), then set the gas lift rate input
                        allSet &= SetInput(
                            settings, SimulationInputConstants.GasLiftRate, UnitType.GasRate,
                            "PROSPER.ANL.WHP.DATA[0].GLIFT");
                    }
                    break;
                case ModelType.Unknown:
                    throw new SimulatorException("Unknown fluid type");
            }

            if (!allSet)
            {
                throw new SimulatorException("Missing required input for calculation");
            }
            // refresh the table
            TryRefresh();
        }

        /// <summary>
        /// Tries to calculate a rate guess from the calculation settings
        /// </summary>
        /// <param name="settings">CalculationSettings object</param>
        private static double? GetRateGuess(CalculationSettings settings)
        {
            // check if the RootFindingSettings configuration exists
            if (settings.RootFindingSettings == null)
                return null;
            var lowerBound = settings.RootFindingSettings.Bracket.LowerBound;
            var upperBound = settings.RootFindingSettings.Bracket.UpperBound;
            return (lowerBound + upperBound) / 2;
        }

        /// <summary>
        /// Calculates the Rate from BHP or gauge BHP using a numeric method
        /// </summary>
        /// <param name="settings">CalculationSettings object</param>
        /// <param name="bhp">Value of the BHP or gauge BHP</param>
        /// <param name="isGauge">True if the provided value is a gauge BHP, False otherwise</param>
        /// <returns>Tuple with a list of rate results, the rate unit and the sourceAddress</returns>
        ProsperList EstimateRateFromPressure(
            CalculationSettings settings, double bhp, bool isGauge)
        {
            string sourceAddress = "PROSPER.ANL.WHP.Data[0].RATE";
            string unit = _api.DoGet($"{sourceAddress}.UNITNAME");
            var rate = new ProsperList
            {
                Address = sourceAddress,
                Unit = unit
            };

            if (isGauge)
            {
                // check if the gauge information is available
                bool gaugeConfigured = false;
                // fist we check if there are any rows filled in the table
                int gaugeCount = int.Parse(_api.DoGet("PROSPER.SIN.EQP.Gauge.Data.COUNT"));
                if (gaugeCount >= 1)
                {
                    // check if the first row is enabled (calculations are configured using the first gauge)
                    string gaugeEnabled = _api.DoGet("PROSPER.SIN.EQP.Gauge.Data[0].Enable");
                    if (gaugeEnabled != "0")
                    {
                        gaugeConfigured = true;
                    }
                }
                if (!gaugeConfigured)
                {
                    throw new Exception("Gauge information is not available");
                }

                // enable the Gauge Pressure Flag
                _api.DoSet("PROSPER.ANL.WHP.SHWGA", "1");
                TryRefresh();
            }

            // get the required configuration values
            var rootTolerance = settings.RootFindingSettings.RootTolerance;
            var upperBound = settings.RootFindingSettings.Bracket.UpperBound;
            var lowerBound = settings.RootFindingSettings.Bracket.LowerBound;
            // make sure the lowerBound is not 0.0
            if (lowerBound == 0.0)
                lowerBound = 1.0e-6;

            // extract the VLP curve from PROSPER (with 100 points) - takes around 30s
            var (ratesArray, pressuresArray) = GetLiftCurve(lowerBound, upperBound, isGauge, 100);

            // interpolate the VLP curve
            var vlp = Interpolate.Linear(ratesArray, pressuresArray);
            double InterpolatePressure(double r) => vlp.Interpolate(r);

            // auxiliary method to find the inflection point of the VLP curve
            Optimizers.OptimizeResult FindInflectionPoint(double lb, double ub)
            {
                return Optimizers.MinimizeScalarBounded(InterpolatePressure, lb, ub);
            }

            // auxiliary method to find the root of the VLP curve minus the given pressure
            Optimizers.OptimizeResult FindRoot(double pressure, double lb, double ub)
            {
                double f(double r) => Math.Abs(InterpolatePressure(r) - pressure);
                return Optimizers.MinimizeScalarBounded(f, lb, ub);
            }

            // find the inflection point (or minimum) of the VLP curve
            var minimum = FindInflectionPoint(lowerBound, upperBound);
            // save the rate and pressure associated with the minimum
            double rateMinimum = minimum.X;
            double pressureMinimum = minimum.Fun;

            if (pressureMinimum > bhp)
            {
                // if the minimum is above the given pressure, no solution exists
                // adjust the error message depending on the type of BHP measurement being used
                if (isGauge)
                    throw new NoSolutionException("No solution found. Minimum VLP gauge pressure is above the BHPg");
                else
                    throw new NoSolutionException("No solution found. Minimum VLP pressure is above the BHP");
            }
            else if (Math.Abs(pressureMinimum - bhp) < rootTolerance)
            {
                // if the minimum is equal to the given pressure, the solution is located at the inflection point
                rate.Values = new List<double>() { rateMinimum };
            }
            else if (Math.Abs(rateMinimum - lowerBound) < rootTolerance)
            {
                // if the minimum is equal to the lower bound, only one solution should exist
                var root = FindRoot(bhp, rateMinimum, upperBound);
                // check if the root is within the given tolerance
                if (root.Fun <= rootTolerance)
                {
                    rate.Values = new List<double>() { root.X };
                }
                throw new NoSolutionException("No solution found inside the given bounds.");
            }
            else if (Math.Abs(rateMinimum - upperBound) < rootTolerance)
            {
                // if the minimum is equal to the upper bound, only one solution should exist
                var root = FindRoot(bhp, lowerBound, rateMinimum);
                // check if the root is within the given tolerance
                if (root.Fun <= rootTolerance)
                {
                    rate.Values = new List<double>() { root.X };
                }
                throw new NoSolutionException("No solution found inside the given bounds.");
            }
            else
            {
                // if the minimum is between the lower and upper bound, two solutions exist
                List<double> solutions = new();
                var root1 = FindRoot(bhp, lowerBound, rateMinimum);
                // check if the root is within the given tolerance
                if (root1.Fun <= rootTolerance)
                {
                    solutions.Add(root1.X);
                }
                var root2 = FindRoot(bhp, rateMinimum, upperBound);
                // check if the root is within the given tolerance
                if (root2.Fun <= rootTolerance)
                {
                    solutions.Add(root2.X);
                }
                // if no solution was found, throw an exception
                if (solutions.Count == 0)
                {
                    throw new NoSolutionException("No solution found inside the given bounds.");
                }
                rate.Values = solutions;
            }
            return rate;
        }

        private (double[] rates, double[] pressures) GetLiftCurve(
            double lowerBound, double upperBound, bool isGauge, int nPoints)
        {
            var rates = Generate.LinearSpaced(nPoints, lowerBound, upperBound);
            var pressures = new double[rates.Length];
            for (int i = 0; i < rates.Length; ++i)
            {
                var bhp = EstimateBhpFromRate(rates[i], isGauge);
                pressures[i] = bhp.Value;
            }
            return (rates, pressures);
        }

        private ProsperVar EstimateBhpFromRate(double rate, bool isGauge)
        {
            _api.DoSet("PROSPER.ANL.WHP.DATA[0].RATE", rate.ToString());
            _api.DoCmd("PROSPER.ANL.WHP.CALC");
            string address = isGauge ? "PROSPER.ANL.WHP.Data[0].GPRSC[0]" : "PROSPER.ANL.WHP.Data[0].BHP";
            return new ProsperVar
            {
                Address = address,
                Unit = _api.DoGet(address + ".UNITNAME"),
                Value = double.Parse(_api.DoGet(address))
            };
        }

        private void TryRefresh()
        {
            try
            {
                // Try to refresh but ignore any errors
                _api.DoCmd("PROSPER.REFRESH");
            }
            catch (OpenServerException e)
            {
                _logger.LogWarning("PROSPER refresh failed: {Error}. Skipping.", e.ErrorCode);
            }
        }
    }

    [Serializable]
    public class NoSolutionException : SimulatorException
    {
        public NoSolutionException()
        {
        }

        public NoSolutionException(string message) : base(message)
        {
        }

        public NoSolutionException(string message, Exception innerException) : base(message, innerException)
        {
        }
    }
}
﻿using Cognite.Simulator.Utils;
using Cognite.Simulator.Utils.Automation;
using Microsoft.Extensions.Logging;
using SimulatorCommon;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

namespace OpenServer
{
    public class GapSimulator : ISimulator
    {
        private readonly OpenServerApi _api;
        private readonly OpenServerConfig _config;
        private readonly ILogger<GapSimulator> _logger;

        public string Id => SimulatorType.GAP.ToString();

        private string _version;

        public GapSimulator(
            OpenServerApi api, 
            OpenServerConfig config,
            ILogger<GapSimulator> logger)
        {
            _api = api;
            _config = config;
            _logger = logger;
        }

        public void ExtractModelInformation(ModelFileSettings modelFileSettings)
        {
            lock(_api.SimulatorLock)
            {
                try
                {
                    modelFileSettings.ModelParsingLog.AddInfo("Opening model file in GAP");
                    OpenModelAndSetUnits(modelFileSettings.LocalFilePath, modelFileSettings.UnitSystem);

                    // Find the type of the model and find the associated models
                    var modelType = _api.DoGet("GAP.MOD");
                    // Find the model type string between the curly braces example {PROD}
                    string pattern = @"\{([^}]+)\}";
                    Match match = Regex.Match(modelType, pattern);
                    if (match.Success == false)
                    {
                       throw new SimulatorException("Cannot match GAP type {PROD}, {WINJ}, {GINJ}, {GLINJ}");
                    }
                    string matchedModelType = match.Value;
                    modelFileSettings.GapModelType = matchedModelType;
                    // TODO - Check for ModelType from modelFileSettings and verify if it matches with the matchedModelType

                    // Check if matchedModel is either {PROD}, {WINJ}, {GINJ}, {GLINJ}
                    if(matchedModelType != "{PROD}" && matchedModelType != "{WINJ}" && matchedModelType != "{GINJ}" && matchedModelType != "{GLINJ}")
                    {
                        throw new SimulatorException("Cannot match GAP type {PROD}, {WINJ}, {GINJ}, {GLINJ}");
                    }

                    if(matchedModelType == "{PROD}")
                    {
                        // List of possible network models associated with the PROD model
                        List<string> listOfNetworks = new List<string> {"WINJNAME", "GINJNAME", "GLINJNAME"};

                        foreach(string networkFileName in listOfNetworks)
                        {
                            string networkName = _api.DoGet($"GAP.MOD[{{PROD}}].{networkFileName}");
                            if(networkName != "")
                            {
                                // Find the file name from the path
                                string patternFileName = @"([^\\]+)$";
                                Match matchFileName = Regex.Match(networkName, patternFileName);
                                if (matchFileName.Success == false)
                                {
                                    throw new SimulatorException($"Could not extract file name from the path for the linked {networkFileName} GAP model");
                                }
                                modelFileSettings.LinkedModels.Add(
                                    new ReferenceData{
                                        Label = Regex.Replace(matchFileName.Value, ".gap", "", RegexOptions.IgnoreCase),
                                        FileName = matchFileName.Value,
                                        Type = networkFileName
                                    });
                            }
                        }

                    }

                    var numWells = _api.DoGet($"GAP.MOD[{matchedModelType}].WELL.COUNT");
                    var numWellsInt = int.Parse(numWells);
                    _logger.LogDebug("There are {Num} wells in the {Name} model", numWells, modelFileSettings.ModelName);

                    for(int i = 0; i < numWellsInt; ++i)
                    {
                        // Find file name of the well
                        var wellFilePath = _api.DoGet($"GAP.MOD[{matchedModelType}].WELL[{i}].FILE");
                        // Find the file name from the path
                        string patternFileName = @"([^\\]+)$";
                        Match matchFileName = Regex.Match(wellFilePath, patternFileName);

                        if (matchFileName.Success == false)
                        {
                            throw new SimulatorException($"Could not extract file name from the path for the linked {i} WELL");
                        }

                        var wellLabel = _api.DoGet($"GAP.MOD[{matchedModelType}].WELL[{i}].LABEL");
                        modelFileSettings.Wells.Add(
                        new ReferenceData{
                            Label = wellLabel,
                            FileName = matchFileName.Value
                        });
                    }

                    var numTanks = _api.DoGet($"GAP.MOD[{matchedModelType}].TANK.COUNT");
                    var numTanksInt = int.Parse(numTanks);
                    _logger.LogDebug("There are {Num} tanks in the {Name} model", numTanks, modelFileSettings.ModelName);
                    for(int i = 0; i < numTanksInt; ++i)
                    {
                        // Fnd the tank file path
                        var tankFilePath = _api.DoGet($"GAP.MOD[{matchedModelType}].TANK[{i}].FILE");
                        // Find the file name from the path
                        string patternFileName = @"([^\\]+)$";
                        Match matchFileName = Regex.Match(tankFilePath, patternFileName);

                        if (matchFileName.Success == false)
                        {
                            throw new SimulatorException($"Could not extract file name from the path for the linked {i} TANK");
                        }

                        var tankLabel = _api.DoGet($"GAP.MOD[{matchedModelType}].TANK[{i}].LABEL");
                        modelFileSettings.Tanks.Add(
                        new ReferenceData{
                            Label = tankLabel,
                            FileName = matchFileName.Value
                        });
                    }

                    var numPipes = _api.DoGet($"GAP.MOD[{matchedModelType}].PIPE.COUNT");
                    var numPipesInt = int.Parse(numPipes);
                    _logger.LogDebug("There are {Num} pipes in the {Name} model", numPipes, modelFileSettings.ModelName);
                    for(int i = 0; i < numPipesInt; ++i)
                    {
                        // Check if pipe type is lift curves
                        var pipeModel = _api.DoGet($"GAP.MOD[{matchedModelType}].PIPE[{i}].PipeModel");
                        
                        var pipeLabel = _api.DoGet($"GAP.MOD[{matchedModelType}].PIPE[{i}].LABEL");

                        if(pipeModel != "LiftCurves")
                        {
                            continue;
                        }

                        // Also check for the underlying model type
                        var pipeUnderLyingModel = _api.DoGet($"GAP.MOD[{matchedModelType}].PIPE[{i}].UnderModel");

                        if(pipeUnderLyingModel !=  "GAPInternal"){
                            continue;
                        }

                         // Check for PROSPER file reference
                        var prosperFilePath = _api.DoGet($"GAP.MOD[{matchedModelType}].PIPE[{i}].FILE");

                        // Find the file name from the path
                        string patternFileName = @"([^\\]+)$";
                        Match matchFileName = Regex.Match(prosperFilePath, patternFileName);
                        if (matchFileName.Success == false)
                        {
                            throw new SimulatorException($"Could not extract PROSPER file name for the linked {pipeLabel} PIPE");
                        }

                        modelFileSettings.Pipes.Add(
                        new ReferenceData{
                            Label = pipeLabel,
                            FileName = matchFileName.Value,
                            Type = "LiftCurves"
                        });
                    }

                    modelFileSettings.ModelParsingLog.Log.Add(
                        new ParsingLog(ParsingLogLevel.INFORMATION, "Extracting additional model meta-data"));

                    modelFileSettings.Metadata.Add(
                        "System Type",
                        _api.DoGet($"GAP.MOD[{matchedModelType}].SysType"));
                    modelFileSettings.Metadata.Add(
                        "Optimisation Method",
                        _api.DoGet($"GAP.MOD[{matchedModelType}].OptMethod"));
                    modelFileSettings.Metadata.Add(
                        "PVT Model",
                        _api.DoGet($"GAP.MOD[{matchedModelType}].PVTMODEL"));
                }
                catch (OpenServerException e)
                {
                    throw new SimulatorException("Failed to extract model information from GAP", e)
                    {
                        CanRetry = e.CanRetry,
                        SimulatorMessage = e.InternalMessage
                    };

                }
                catch (ArgumentException ae)
                {
                    throw new SimulatorException("Failed to extract model information from GAP", ae);
                }
                finally
                {
                    CloseGap();
                }                
            }
        }


        public void ResolveModelReferences(ModelFileSettings modelSettings, Action<string,string> UpdateModelFileState)
        {
            lock(_api.SimulatorLock)
            {
                try
                {
                    modelSettings.ModelParsingLog.AddInfo("Attempting to resolve model references");
                    OpenModelAndSetUnits(modelSettings.LocalFilePath, modelSettings.UnitSystem);

                    foreach(var gapModel in modelSettings.LinkedModels)
                    {
                        if (string.IsNullOrEmpty(gapModel.File))
                        {
                            modelSettings.ModelParsingLog.Log.Add(
                                new ParsingLog(ParsingLogLevel.ERROR, $"Gap Model {gapModel.Label} has no GAP file reference, filename : {gapModel.FileName}"));
                            continue;
                        }
                        var filePath = _api.DoGet($"GAP.MOD[{{PROD}}].{gapModel.Type}");
                        if (filePath != gapModel.File)
                        {
                            _api.DoSet($"GAP.MOD[{{PROD}}].{gapModel.Type}", gapModel.File);
                            gapModel.ReferencesResolved = true;
                        }
                    }

                    foreach(var well in modelSettings.Wells)
                    {
                        if (string.IsNullOrEmpty(well.File))
                        {
                            modelSettings.ModelParsingLog.Log.Add(
                                new ParsingLog(ParsingLogLevel.ERROR, $"Well {well.Label} has no PROSPER file reference, filename : {well.FileName}"));
                            continue;
                        }
                        var filePath = _api.DoGet($"GAP.MOD[{modelSettings.GapModelType}].WELL[{{{well.Label}}}].File");
                        if (filePath != well.File)
                        {
                            _api.DoSet($"GAP.MOD[{modelSettings.GapModelType}].WELL[{{{well.Label}}}].File", well.File);
                            // Check for VLP file already exists and associate the vlp file before 
                            if (well.IsVLPGenerated == false)
                            {
                                // Generate VLP with PROSPER file
                                _api.DoCmd($"GAP.MOD[{modelSettings.GapModelType}].WELL[{{{well.Label}}}].GENVLPWITHPROSPER(0)");
                                well.IsVLPGenerated = true;
                                UpdateModelFileState(well.FileName, "PROSPER");
                            }
                            else
                            {
                                // Replace .out(non case sensitive) with .vlp using Regex
                                string vlpFilePath = Regex.Replace(well.File, ".out", ".vlp", RegexOptions.IgnoreCase);
                                _api.DoSet($"GAP.MOD[{modelSettings.GapModelType}].WELL[{{{well.Label}}}].VLPFILE", vlpFilePath);
                            }
                            well.ReferencesResolved = true;
                        }
                    }
                    foreach (var tank in modelSettings.Tanks)
                    {
                        if (string.IsNullOrEmpty(tank.File))
                        {
                            modelSettings.ModelParsingLog.Log.Add(
                                new ParsingLog(ParsingLogLevel.ERROR, $"Tank {tank.Label} has no MBAL file reference, filename : {tank.FileName}"));
                            continue;
                        }
                        var filePath = _api.DoGet($"GAP.MOD[{modelSettings.GapModelType}].TANK[{{{tank.Label}}}].File");
                        if (filePath != tank.File)
                        {
                            _api.DoSet($"GAP.MOD[{modelSettings.GapModelType}].TANK[{{{tank.Label}}}].File", tank.File);
                            tank.ReferencesResolved = true;
                        }
                    }

                    foreach (var pipe in modelSettings.Pipes)
                    {
                        if (string.IsNullOrEmpty(pipe.File))
                        {
                            modelSettings.ModelParsingLog.Log.Add(
                                new ParsingLog(ParsingLogLevel.ERROR, $"Pipe {pipe.Label} has no PROSPER file reference,  filename : {pipe.FileName}"));
                            continue;
                        }
                        // Generate VLP with PROSPER

                        var filePath = _api.DoGet($"GAP.MOD[{modelSettings.GapModelType}].PIPE[{{{pipe.Label}}}].FILE");
                        if (filePath != pipe.File)
                        {
                            _api.DoSet($"GAP.MOD[{modelSettings.GapModelType}].PIPE[{{{pipe.Label}}}].File", pipe.File);
                            if(pipe.IsVLPGenerated == false)
                            {
                                // Generate VLP with PROSPER file
                                _api.DoCmd($"GAP.MOD[{modelSettings.GapModelType}].PIPE[{{{pipe.Label}}}].GENVLP()");
                                UpdateModelFileState(pipe.FileName,"PROSPER");
                            }
                            else
                            {
                                string vlpFilePath = Regex.Replace(pipe.FileName, ".out", ".vlp", RegexOptions.IgnoreCase);
                                _api.DoSet($"GAP.MOD[{modelSettings.GapModelType}].PIPE[{{{pipe.Label}}}].VLPFILE", vlpFilePath);
                            }
                            pipe.ReferencesResolved = true;
                        }

                    }

                    _api.DoCmd($"GAP.SAVEFILE(\"{modelSettings.LocalFilePath}\")");

                    if(modelSettings.ReferencesResolved == true)
                    {
                        modelSettings.ModelParsingLog.AddInfo("References resolved and model saved");
                    }
                    else
                    {
                        throw new SimulatorException("Failed to resolve model references");
                    }
                }
                catch (OpenServerException e)
                {
                    throw new SimulatorException("Failed to resolve model references", e)
                    {
                        CanRetry = e.CanRetry,
                        SimulatorMessage = e.InternalMessage
                    };

                }
                catch (ArgumentException ae)
                {
                    throw new SimulatorException("Failed to resolve model references", ae);
                }
                finally
                {
                    CloseGap();
                }
            }
        }

        public string GetUnit(UnitSystem unitSystem, UnitType unitType)
        {
            throw new NotImplementedException();
        }

        public string GetVersion()
        {
            if (_version == null)
            {
                _logger.LogError("Could not obtain GAP version");
                return "N/A";
            }
            return _version;
        }

        public void RunCalculation(string calcType, CalculationSettings settings)
        {
            throw new NotImplementedException();
        }

        public void TestConnection()
        {
            _logger.LogInformation("Testing GAP connection...");

            lock (_api.SimulatorLock)
            {
                try
                {
                    _api.Initialize();
                    _api.DoCmd("GAP.START()");
                    var serverProcess = Process.GetProcessesByName("gap");
                    var versionInfo = serverProcess[0].MainModule.FileVersionInfo;
                    _version = versionInfo.FileVersion;
                    _api.DoCmd("GAP.SHUTDOWN()");
                    _api.Shutdown();
                }
                catch (OpenServerException oe) when (oe.CanRetry == true)
                {
                    _logger.LogWarning("Cannot open GAP, but possible to retry: {Error}", oe.Message);
                }
                catch (Exception e)
                {
                    throw new SimulatorConnectionException($"{Id} is not available: {e.Message}", e);
                }
            }

            _logger.LogInformation("GAP instance created and removed successfully");
        }

        private int? _gapProcesses;

        private void OpenModelAndSetUnits(string filePath, UnitSystem unitSystem)
        {
            var gapProcesses = Process.GetProcessesByName("gap").Select(p => p.Id);
            _api.DoCmd("GAP.START");

            var newGapProcesses = Process.GetProcessesByName("gap")
                .Where(p => !gapProcesses.Contains(p.Id));
            if (newGapProcesses.Any())
            {
                _gapProcesses = newGapProcesses.First().Id;
            }

            _api.DoCmd($"GAP.OPENFILE(\"{filePath}\")");
            _api.DoSet("GAP.InputUnitSystem", unitSystem.ToGapUnitName());
            _api.DoSet("GAP.OutputUnitSystem", unitSystem.ToGapUnitName());
        }
        
        private void CloseGap()
        {
            try
            {
                _api.DoCmd("GAP.SHUTDOWN");
            }
            catch (OpenServerException e)
            {
                // Just ignore exceptions here and clean resources in the finally block
                _logger.LogWarning("Cannot close GAP: {Message}", e.Message);
            }
            finally
            {
                _api.Shutdown();

                if (_gapProcesses.HasValue)
                {
                    var existingGapProcesses = Process.GetProcessesByName("gap")
                        .Where(p => p.Id == _gapProcesses);
                    if (existingGapProcesses.Any())
                    {
                        existingGapProcesses.First().Kill(true);
                    }
                    _gapProcesses = null;
                }
            }
        }
    }
    public static class GapSimulatorExtensions
    {        
        public static string ToGapUnitName(this UnitSystem us)
        {
            return us switch
            {
                UnitSystem.OilField => "OilField",
                UnitSystem.NorSI => "NorwegianSI",
                UnitSystem.CanSI => "CanadianSI",
                UnitSystem.GerSI => "GermanSI",
                UnitSystem.FreSI => "FrenchSI",
                UnitSystem.LatSI => "LatinSI",
                _ => throw new ArgumentException($"Unit system {us} is not valid for GAP", nameof(us)),
            };
        }

    }
}

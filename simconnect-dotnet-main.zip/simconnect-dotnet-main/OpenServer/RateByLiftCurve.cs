﻿using MathNet.Numerics;
using SimulatorCommon;
using SimulatorCommon.Configuration;
using System.Linq;

namespace OpenServer
{
    partial class ProsperSimulator
    {
        private void RateByLiftCurve(CalculationSettings settings)
        {
            if (settings.RootFindingSettings == null)
            {
                throw new SimulatorException("Root finding configuration missing");
            }
            if (settings.EstimateBHP == null)
            {
                throw new SimulatorException("BHP estimation configuration missing");
            }
            if (settings.RootFindingSettings.Bracket == null || !settings.RootFindingSettings.Bracket.IsValid)
            {
                throw new SimulatorException("Invalid root finding bracket");
            }
            var outputBhpg = settings.EstimateBHP.Enabled && 
                settings.EstimateBHP.Method == EstimateBhpMethod.LiftCurveGaugeBhp;

            ProsperVar bhp; 
            ProsperList rates;
            try
            {
                (bhp, rates) = EstimateBhpInternal(settings, true);
            }
            catch (NoSolutionException)
            {
                AddVlpCurvesToOutput(settings, outputBhpg);
                AddCalculationTimeToCurveOutput(settings);
                throw;
            }
            
            var rateValue = rates.Values.Max();
            if (settings.RootFindingSettings.MainSolution == RootSolutionType.Min)
            {
                rateValue = rates.Values.Min();
            }

            // Collect inputs
            // TODO: Make this into a utils function
            double cgr = 0;
            double wgr = 0;
            double gor = 0;
            double wc = 0;
            switch (settings.ModelType)
            {
                case ModelType.GasWell:
                    cgr = GetInputFromSettings(settings, SimulationInputConstants.CGR);
                    wgr = GetInputFromSettings(settings, SimulationInputConstants.WGR);
                    break;
                
                case ModelType.RetrogradeWell:
                    gor = GetInputFromSettings(settings, SimulationInputConstants.GOR);
                    wgr = GetInputFromSettings(settings, SimulationInputConstants.WGR);
                    break;
                
                case ModelType.OilWell:
                    gor = GetInputFromSettings(settings, SimulationInputConstants.GOR);
                    wc = GetInputFromSettings(settings, SimulationInputConstants.WC);
                    break;
                
                case ModelType.Unknown:
                    throw new SimulatorException("Unknown fluid type");
            }
            
            // multipliers to account for different units when computing rates using CGR/GOR/WGR
            var (orMultiplier, grMultiplier) = ProsperSimulatorExtensions.GetRateMultipliers(settings);

            // Extract output time series
            switch (settings.ModelType)
            {
                case ModelType.GasWell:
                    SetOutput(settings, SimulationOutputConstants.GasRate, UnitType.GasRate,
                        rates.Address,
                        rates.Unit,
                        rateValue);
                    SetOutput(settings, SimulationOutputConstants.OilRate, UnitType.LiqRate,
                        $"Value calculated from {rates.Address}",
                        GetUnit(settings.UnitSystem, UnitType.LiqRate),
                        rateValue * cgr * grMultiplier);
                    SetOutput(settings, SimulationOutputConstants.WatRate, UnitType.LiqRate,
                        $"Value calculated from {rates.Address}",
                        GetUnit(settings.UnitSystem, UnitType.LiqRate),
                        rateValue * wgr * grMultiplier);
                    SetOutput(settings, SimulationOutputConstants.LiqRate, UnitType.LiqRate,
                        $"Value calculated from {rates.Address}",
                        GetUnit(settings.UnitSystem, UnitType.LiqRate),
                        (rateValue * cgr * grMultiplier) + (rateValue * wgr * grMultiplier));
                    break;
                
                case ModelType.RetrogradeWell:
                    SetOutput(settings, SimulationOutputConstants.GasRate, UnitType.GasRate,
                        rates.Address,
                        rates.Unit,
                        rateValue);
                    SetOutput(settings, SimulationOutputConstants.OilRate, UnitType.LiqRate,
                        $"Value calculated from {rates.Address}",
                        GetUnit(settings.UnitSystem, UnitType.LiqRate),
                        rateValue * orMultiplier / gor);
                    SetOutput(settings, SimulationOutputConstants.WatRate, UnitType.LiqRate,
                        $"Value calculated from {rates.Address}",
                        GetUnit(settings.UnitSystem, UnitType.LiqRate),
                        rateValue * wgr * grMultiplier);
                    SetOutput(settings, SimulationOutputConstants.LiqRate, UnitType.LiqRate,
                        $"Value calculated from {rates.Address}",
                        GetUnit(settings.UnitSystem, UnitType.LiqRate),
                        (rateValue * orMultiplier / gor) + (rateValue * wgr * grMultiplier));
                    break;
                
                case ModelType.OilWell:
                    SetOutput(settings, SimulationOutputConstants.LiqRate, UnitType.LiqRate,
                        rates.Address,
                        rates.Unit,
                        rateValue);
                    SetOutput(settings, SimulationOutputConstants.OilRate, UnitType.LiqRate,
                        $"Value calculated from {rates.Address}",
                        GetUnit(settings.UnitSystem, UnitType.LiqRate),
                        rateValue * (100 - wc)/100);
                    SetOutput(settings, SimulationOutputConstants.WatRate, UnitType.LiqRate,
                        $"Value calculated from {rates.Address}",
                        GetUnit(settings.UnitSystem, UnitType.LiqRate),
                        rateValue * wc/100);
                    SetOutput(settings, SimulationOutputConstants.GasRate, UnitType.GasRate,
                        $"Value calculated from {rates.Address}",
                        GetUnit(settings.UnitSystem, UnitType.GasRate),
                        rateValue * gor * orMultiplier * (100 - wc)/100);
                    break;
                
                case ModelType.Unknown:
                    throw new SimulatorException("Unknown fluid type");
            }
            
            // if the BHP is estimated we save it as an output as well
            if (settings.EstimateBHP.Enabled)
            {
                SetOutput(settings, SimulationOutputConstants.BHP, UnitType.Pressure,
                    bhp.Address,
                    bhp.Unit,
                    bhp.Value);
            }

            var resultsOutput = settings.TabularOutputs
                .Where(o => o.OutputType == CalculationTabularOutputType.LiftCurveSolutionResults);
            if (resultsOutput.Any())
            {
                var output = resultsOutput.First();
                for (int i = 0; i < rates.Values.Count; ++i)
                {
                    string rateName = settings.ModelType.GetRateName();
                    SetResultOutput(output, $"{rateName} - Solution {i + 1}", rates.Unit, rates.Values[i]);
                    var outBhp = EstimateBhpFromRate(rates.Values[i], isGauge: false);
                    SetResultOutput(output, $"Bottom Hole Pressure - Solution {i + 1}", outBhp.Unit, outBhp.Value);
                    GetResultOutput(
                        output,
                        $"Matched Heat Transfer Coefficient - Solution {i + 1}",
                        "PROSPER.ANL.WHP.Data[0].HTC");
                }
            }

            AddVlpCurvesToOutput(settings, outputBhpg);
        }

        private void AddVlpCurvesToOutput(CalculationSettings settings, bool outputBhpg = false)
        {
            var curvesOutput = settings.TabularOutputs
                .Where(o => o.OutputType == CalculationTabularOutputType.LiftCurveSolutionCurves);
            if (curvesOutput.Any())
            {
                var output = curvesOutput.First();
                var rateArray = Generate.LinearSpaced(
                    20,
                    settings.RootFindingSettings.Bracket.LowerBound,
                    settings.RootFindingSettings.Bracket.UpperBound);

                var bhps = new double?[rateArray.Length];
                var htcs = new double?[rateArray.Length];
                var bhpgs = new double?[rateArray.Length];
                for (int i = 0; i < rateArray.Length; ++i)
                {
                    var (bhpCalc, htcCalc, bhpgCalc) = CalculateVlp(rateArray[i], outputBhpg);
                    bhps[i] = bhpCalc;
                    htcs[i] = htcCalc;
                    bhpgs[i] = bhpgCalc.HasValue ? bhpgCalc : 0.0;
                }
                var nullableGasRates = rateArray.Select(r =>
                {
                    double? value = r;
                    return value;
                }).ToArray();
                // TODO: this can also be turned into a generic method
                string rateName = "";
                UnitType rateUnitType = UnitType.GasRate;
                switch (settings.ModelType)
                {
                    case ModelType.GasWell or ModelType.RetrogradeWell:
                        rateName = "Gas Rate";
                        break;
                        
                    case ModelType.OilWell:
                        rateName = "Oil Rate";
                        rateUnitType = UnitType.LiqRate;
                        break;
                        
                    case ModelType.Unknown:
                        throw new SimulatorException("Unknown fluid type");
                }
                AssignCurveOutputValues(output, rateName, "PROSPER.ANL.WHP.Data[0].RATE", nullableGasRates, rateUnitType);
                AssignCurveOutputValues(output, "Bottom Hole Pressure", "PROSPER.ANL.WHP.Data[0].BHP", bhps, UnitType.Pressure);
                AssignCurveOutputValues(output, "Heat Transfer Coefficient", "PROSPER.ANL.WHP.Data[0].HTC", htcs, UnitType.HeatTransferCoefficient);
                AssignCurveOutputValues(output, "Bottom Hole Pressure Gauge", "PROSPER.ANL.WHP.Data[0].GPRSC[0]", bhpgs, UnitType.Pressure);
            }
        }

        private (double BHP, double HTC, double? BHPg) CalculateVlp(double rate, bool outputBhpg = false)
        {
            _api.DoSet("PROSPER.ANL.WHP.Data[0].Rate", rate.ToString());
            _api.DoCmd("PROSPER.ANL.WHP.CALC");
            var bhp = double.Parse(_api.DoGet("PROSPER.ANL.WHP.Data[0].BHP"));
            var htc = double.Parse(_api.DoGet("PROSPER.ANL.WHP.Data[0].HTC"));
            double? bhpg = null;
            if (outputBhpg)
            {
                bhpg = double.Parse(_api.DoGet("PROSPER.ANL.WHP.Data[0].GPRSC[0]"));
            }
            return (bhp, htc, bhpg);
        }
    }
}

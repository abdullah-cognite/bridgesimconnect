﻿using System.Linq;
using System;
using Microsoft.Extensions.Logging;
using System.Diagnostics;
using System.Collections.Generic;
using System.Runtime.Versioning;
using SimulatorCommon;
using Cognite.Simulator.Utils.Automation;

namespace OpenServer
{
    public class OpenServerApi : AutomationClient
    {
        private readonly ILogger<OpenServerApi> _logger;
        private readonly OpenServerConfig _config;
        internal readonly object SimulatorLock = new object();

        public OpenServerApi(ILogger<OpenServerApi> logger, OpenServerConfig config)
            :base(logger, config)
        {
            _logger = logger;
            _config = config;
        }


        protected override void PreShutdown()
        {
            // No action needed
        }

        /// <summary>
        /// Invoke a OpenServer command
        /// </summary>
        /// <param name="command">Command. Example: "PROSPER.START"</param>
        internal void DoCmd(string command)
        {
            Initialize();
            long err = Server.DoCommand(command);
            if (err > 0)
            {
                string msg = Convert.ToString(Server.GetErrorDescription(err));
                _logger.LogError("OpenServer DoCommand failed: {Cmd} - {Message} ({Code})", command, msg, err);
                throw new OpenServerException($"{command} failed: {msg}", err){
                    InternalMessage = msg
                };
            }
        }

        /// <summary>
        /// Invoke OpenServer to set the value of a given variable
        /// </summary>
        /// <param name="variable">Variable name. Example: "PROSPER.PVT.Input.Cgr"</param>
        /// <param name="value">Value in string format. Numeric values should be converted to string</param>
        internal void DoSet(string variable, string value)
        {
            if (Server == null)
            {
                Initialize();
            }
            Server.SetValue(variable, value);
            long err = Server.GetLastError(GetAppName(variable));
            if (err > 0)
            {
                string msg = Convert.ToString(Server.GetErrorDescription(err));
                _logger.LogError("OpenServer SetValue failed: {Cmd} - {Message} ({Code})", variable, msg, err);
                throw new OpenServerException($"Set {variable} failed: {msg}", err);
            }
        }

        /// <summary>
        /// Invoke OpenServer to get the value of a given variable
        /// </summary>
        /// <param name="variable">Variable name. Example: "PROSPER.PVT.Input.Cgr"</param>
        /// <returns>String representation of the value. Should be converted to numeric, if needed</returns>
        internal string DoGet(string variable)
        {
            if (Server == null)
            {
                Initialize();
            }
            var value = Server.GetValue(variable);
            long err = Server.GetLastError(GetAppName(variable));
            if (err > 0)
            {
                string msg = Convert.ToString(Server.GetErrorDescription(err));
                _logger.LogError("OpenServer GetValue failed: {Cmd} - {Message} ({Code})", variable, msg, err);
                throw new OpenServerException($"Get {variable} failed: {msg}", err);
            }
            return Convert.ToString(value);
        }

        internal static double?[] ParseArrayString(string osArray)
        {
            var values = osArray.Split('|').ToList();
            if (string.IsNullOrWhiteSpace(values.Last()))
            {
                values.RemoveAt(values.Count - 1);
            }
            var doubleValues = values.Select(v => 
                {
                    double? val = null;
                    if (double.TryParse(v, out var dValue))
                    {
                        val = dValue;
                    }
                    return val;
                }
            );
            return doubleValues.ToArray();
        }

        internal static double[] TryParseArrayString(string osArray)
        {
            var values = osArray.Split('|').ToList();
            if (string.IsNullOrWhiteSpace(values.Last()))
            {
                values.RemoveAt(values.Count - 1);
            }
            var doubleValues = values.Select(v =>
            {
                if (double.TryParse(v, out var dValue))
                {
                    return dValue;
                }
                throw new OpenServerException("Failed to parse Open Server variable to double array");
            }
            );
            return doubleValues.ToArray();
        }

        private static string GetAppName(string command)
        {
            var name = command.Split('.').First();
            return name;
        }

    }

    /// <summary>
    /// Exception thrown when OpenServer fails to call a command, get a value or set a value.
    /// TODO: Extend with error type. e.g. license errors most probably can be retried
    /// </summary>
    public class OpenServerException : Exception
    {
        public long ErrorCode { get; }
        public string InternalMessage { get; init; }
        
        /// <summary>
        /// Indicates if the operation that caused this exception can be retried.
        /// Errors related to missing licenses can be retried, in case a license
        /// becomes available later
        /// </summary>
        public bool CanRetry => ErrorCode == 22 
            || Message.Contains("No OpenServer license available")
            || Message.Contains("could not locate a free license");

        public OpenServerException(string message) : base(message)
        {
            ErrorCode = -1;
        }

        public OpenServerException(string message, long err) : base(message)
        {
            ErrorCode = err;
        }
    }

    public enum SimulatorType
    {
        PROSPER,
        GAP,
        MBAL
    }
}

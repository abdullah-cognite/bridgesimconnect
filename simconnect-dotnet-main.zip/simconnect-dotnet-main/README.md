<a href="https://cognite.com/">
    <img src="https://images.squarespace-cdn.com/content/5bd167cf65a707203855d3c0/1540463676940-6USHZRRF36KCAZLUPM2P/Logo-H.jpg?format=300w&content-type=image%2Fjpeg" alt="Cognite logo" title="Cognite" align="right" height="40" />
</a>

SimConnect
=======================
[![.NET build and test](https://github.com/cognitedata/simconnect-dotnet/actions/workflows/build-and-test.yml/badge.svg)](https://github.com/cognitedata/simconnect-dotnet/actions/workflows/build-and-test.yml)
[![codecov](https://codecov.io/gh/cognitedata/simconnect-dotnet/branch/main/graph/badge.svg?token=hayRm45Ptb)](https://codecov.io/gh/cognitedata/simconnect-dotnet)

_**Alpha**, use only in colaboration with the product team: @cognitedata/simulator-integration_

**SimConnect** is a connector that integrates selected **process simulators** with Cognite Data Fusion (CDF). The current version supports only the **PROSPER** simulator. Once installed at a host machine with access to PROSPER, the connector reads **model files** and **calculation configurations** defined in the SimConfig application and uses them to run PROSPER simulations on schedule. The simulation results are saved in CDF as **time series** and **sequences**.
